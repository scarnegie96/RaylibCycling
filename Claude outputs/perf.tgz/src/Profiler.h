#pragma once
// Frame profiler for the in-ride performance panel.
//
// GPU time per category comes from GL timestamp queries (GL 3.3 core / ARB_timer_query,
// fetched through GLFW since raylib doesn't expose them): a timestamp at every section
// boundary, read back three frames later so nothing ever stalls. raylib batches immediate
// draws, so every mark flushes the batch first and the work lands in the right section.
// Where timer queries aren't available it falls back to CPU wall time per section.
// It costs nothing while the panel is hidden (no queries, no flushes).
#include <cstdint>

namespace prof {

enum Section {
    Update,       // CPU: world streaming, grass, wildlife, particles, lights (before any drawing)
    Shadows,      // sun shadow cascades + cloud shadow map
    Sky,
    Terrain,
    Road,
    Foliage,      // trees, rocks
    Grass,
    Props,        // posts, arches, bridges, lamps, wildlife, rider, birds
    Water,
    Volumetrics,  // clouds, fog, light cones, rain shafts (march + resolve + upsample)
    Particles,    // rain, snow, splashes, lamp glare
    Post,         // bloom, composite, FXAA
    Hud,
    COUNT
};
const char* name(Section s);

void setEnabled(bool on);
bool enabled();
void beginFrame();          // start of the frame (CPU clock + first timestamp)
void mark(Section s);       // everything since the previous mark belongs to `s`
void endFrame();            // after the HUD: closes the frame, harvests old results

struct Stats {
    float ms[COUNT] = {};   // smoothed per section (GPU where available)
    float frameMs = 0;      // smoothed CPU frame time
    float gpuMs = 0;        // smoothed sum of the GPU sections
    bool gpu = false;       // timings are GPU timestamps (else CPU)
};
const Stats& stats();

}  // namespace prof
