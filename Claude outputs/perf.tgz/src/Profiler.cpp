#include "Profiler.h"

#include <chrono>
#include <cstring>

#include "raylib.h"
#include "rlgl.h"

extern "C" void* glfwGetProcAddress(const char* name);   // raylib links GLFW statically

namespace prof {
namespace {

using GLuint = unsigned int;
using GLint = int;
using GLenum = unsigned int;
using GLsizei = int;
using GLuint64 = uint64_t;
#if defined(_WIN32)
#define PROF_APIENTRY __stdcall
#else
#define PROF_APIENTRY
#endif
constexpr GLenum GL_TIMESTAMP_ = 0x8E28, GL_QUERY_RESULT_ = 0x8866, GL_QUERY_RESULT_AVAILABLE_ = 0x8867;
typedef void(PROF_APIENTRY* PGenQueries)(GLsizei, GLuint*);
typedef void(PROF_APIENTRY* PQueryCounter)(GLuint, GLenum);
typedef void(PROF_APIENTRY* PGetQueryObjectiv)(GLuint, GLenum, GLint*);
typedef void(PROF_APIENTRY* PGetQueryObjectui64v)(GLuint, GLenum, GLuint64*);
PGenQueries genQueries = nullptr;
PQueryCounter queryCounter = nullptr;
PGetQueryObjectiv getQueryiv = nullptr;
PGetQueryObjectui64v getQueryui64v = nullptr;

constexpr int FRAMES = 4;            // in flight; results read FRAMES-1 frames later
constexpr int MAXMARKS = COUNT + 2;  // begin + one per mark

struct Frame {
    GLuint q[MAXMARKS] = {};
    int sec[MAXMARKS] = {};          // section each timestamp closes (-1 = the start)
    int n = 0;
    bool pending = false;
    double cpu[COUNT] = {};          // CPU fallback per section (ms)
};

bool on = false, inited = false, gpuOk = false, inFrame = false;
Frame frames[FRAMES];
int cur = 0;
Stats st;
std::chrono::steady_clock::time_point tFrame, tMark;

void init() {
    inited = true;
    genQueries = (PGenQueries)glfwGetProcAddress("glGenQueries");
    queryCounter = (PQueryCounter)glfwGetProcAddress("glQueryCounter");
    getQueryiv = (PGetQueryObjectiv)glfwGetProcAddress("glGetQueryObjectiv");
    getQueryui64v = (PGetQueryObjectui64v)glfwGetProcAddress("glGetQueryObjectui64v");
    gpuOk = genQueries && queryCounter && getQueryiv && getQueryui64v;
    if (gpuOk)
        for (auto& f : frames) genQueries(MAXMARKS, f.q);
}

double msSince(std::chrono::steady_clock::time_point t) {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t).count();
}

void smooth(float& v, double x) { v += float(x - v) * 0.08f; }

// read a finished frame's timestamps into the smoothed stats
void harvest(Frame& f) {
    if (!f.pending) return;
    if (gpuOk) {
        GLint ready = 0;
        getQueryiv(f.q[f.n - 1], GL_QUERY_RESULT_AVAILABLE_, &ready);
        if (!ready) return;   // try again next frame
        double ms[COUNT] = {};
        GLuint64 prev = 0;
        for (int i = 0; i < f.n; ++i) {
            GLuint64 t = 0;
            getQueryui64v(f.q[i], GL_QUERY_RESULT_, &t);
            if (i > 0 && f.sec[i] >= 0) ms[f.sec[i]] += double(t - prev) * 1e-6;
            prev = t;
        }
        double sum = 0;
        for (int s = 1; s < COUNT; ++s) { smooth(st.ms[s], ms[s]); sum += ms[s]; }   // (Update is CPU-timed in mark())
        smooth(st.gpuMs, sum);
    } else {
        double sum = 0;
        for (int s = 1; s < COUNT; ++s) { smooth(st.ms[s], f.cpu[s]); sum += f.cpu[s]; }
        smooth(st.gpuMs, sum);
    }
    f.pending = false;
}

void stamp(int section) {
    Frame& f = frames[cur];
    if (f.n >= MAXMARKS) return;
    rlDrawRenderBatchActive();   // raylib's batched draws belong to the section just ending
    if (gpuOk) queryCounter(f.q[f.n], GL_TIMESTAMP_);
    f.sec[f.n++] = section;
}

}  // namespace

const char* name(Section s) {
    static const char* n[COUNT] = {"Update (CPU)", "Shadows", "Sky", "Terrain", "Road", "Foliage", "Grass", "Props & rider",
                                   "Water", "Clouds & fog", "Particles", "Post", "HUD"};
    return n[s];
}

void setEnabled(bool v) { on = v; }
bool enabled() { return on; }

void beginFrame() {
    if (!on) return;
    if (!inited) init();
    st.gpu = gpuOk;
    // the slot we're about to reuse was issued FRAMES frames ago: take its results now
    harvest(frames[cur]);
    Frame& f = frames[cur];
    if (f.pending) f.pending = false;   // still not ready: drop it rather than stall
    f.n = 0;
    std::memset(f.cpu, 0, sizeof f.cpu);
    inFrame = true;
    tFrame = tMark = std::chrono::steady_clock::now();
    stamp(-1);
}

void mark(Section s) {
    if (!on || !inFrame) return;
    Frame& f = frames[cur];
    if (s == Update) {
        // CPU-only section: no GPU work happens in it, time it on the CPU clock
        double ms = msSince(tMark);
        f.cpu[s] += ms;
        smooth(st.ms[s], ms);
        tMark = std::chrono::steady_clock::now();
        stamp(-1);   // restart the GPU clock here
        return;
    }
    f.cpu[s] += msSince(tMark);
    tMark = std::chrono::steady_clock::now();
    stamp(s);
}

void endFrame() {
    if (!on || !inFrame) return;
    inFrame = false;
    Frame& f = frames[cur];
    f.pending = true;
    if (!gpuOk) harvest(f);
    smooth(st.frameMs, msSince(tFrame));
    cur = (cur + 1) % FRAMES;
}

const Stats& stats() { return st; }

}  // namespace prof
