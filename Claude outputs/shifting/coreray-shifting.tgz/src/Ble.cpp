#include "Ble.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <deque>
#include <functional>
#include <map>
#include <tuple>
#include <mutex>
#include <stdexcept>
#include <thread>

#include "Protocol.h"

#ifdef CORERAY_BLE
#include <simpleble/SimpleBLE.h>
#endif

double appClock() {
    static const auto t0 = std::chrono::steady_clock::now();
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
}

namespace {
void sleepMs(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
std::string lowerStr(std::string s) { for (auto& c : s) c = char(std::tolower((unsigned char)c)); return s; }
}  // namespace

struct BleManager::Impl {
    mutable std::mutex m;
    bool hasAdapter = false;
    std::string adapterMsg = "Bluetooth support not compiled in";
    std::atomic<bool> scanning{false};
    double scanUntil = 0;
    std::map<std::string, DeviceInfo> found;
    Link trainer, hrm, shifter;
    std::string autoTrainer, autoHr, autoShifter;
    int shifts = 0;   // queued gear presses
    std::deque<std::string> logLines;

    // telemetry
    double power = 0, cadence = 0, lastTrainer = -1, hr = 0, lastHr = -1;
    // per-field freshness: some trainers stop sending a field (e.g. cadence when you
    // stop pedalling) rather than sending 0, so each value expires on its own
    double lastPowerT = -1, lastCadT = -1;
    double ibdPowerT = -1, ibdCadT = -1;  // when FTMS last supplied each field (CPS defers to it)
    std::optional<double> speed, trainerHr;
    void clearTelemetry() {
        lastTrainer = -1; power = 0; cadence = 0;
        lastPowerT = lastCadT = ibdPowerT = ibdCadT = -1;
        speed.reset(); trainerHr.reset();
    }

    // trainer command channel (coalesced: only the newest target matters)
    std::optional<TrainerCommand> pendingCmd;
    std::atomic<bool> trainerCancel{true}, hrCancel{true}, shifterCancel{true};
    std::thread trainerThread, hrThread, scanThread, shifterThread;
    std::atomic<bool> quit{false};
    std::mutex ctl;  // serialises start/stop of the supervisors

    void addLog(const std::string& s) {
        std::lock_guard<std::mutex> lk(m);
        char ts[16];
        std::snprintf(ts, sizeof ts, "%7.1f ", appClock());
        logLines.push_back(ts + s);
        while (logLines.size() > 80) logLines.pop_front();
        std::fprintf(stderr, "[ble] %s\n", s.c_str());
    }
    void setLink(bool isTrainer, LinkState st, const std::string& detail) {
        std::lock_guard<std::mutex> lk(m);
        Link& l = isTrainer ? trainer : hrm;
        l.state = st;
        l.detail = detail;
    }
    void setShifterLink(LinkState st, const std::string& detail) {
        std::lock_guard<std::mutex> lk(m);
        Link& l = shifter;
        l.state = st;
        l.detail = detail;
    }

#ifdef CORERAY_BLE
    std::unique_ptr<SimpleBLE::Adapter> adapter;
    std::map<std::string, SimpleBLE::Peripheral> peripherals;

    void initAdapter() {
        try {
            if (!SimpleBLE::Adapter::bluetooth_enabled()) {
                std::lock_guard<std::mutex> lk(m);
                adapterMsg = "Bluetooth is off, or this app has no Bluetooth permission";
            }
            auto list = SimpleBLE::Adapter::get_adapters();
            if (list.empty()) { std::lock_guard<std::mutex> lk(m); adapterMsg = "No Bluetooth adapter found"; return; }
            adapter = std::make_unique<SimpleBLE::Adapter>(list[0]);
            adapter->set_callback_on_scan_found([this](SimpleBLE::Peripheral p) { onScan(p); });
            adapter->set_callback_on_scan_updated([this](SimpleBLE::Peripheral p) { onScan(p); });
            std::lock_guard<std::mutex> lk(m);
            hasAdapter = true;
            adapterMsg = "Bluetooth ready";
        } catch (std::exception& e) {
            std::lock_guard<std::mutex> lk(m);
            adapterMsg = std::string("Bluetooth unavailable: ") + e.what();
        }
    }

    static std::string idOf(SimpleBLE::Peripheral& p) {
        std::string a = p.address();
        return a.empty() ? p.identifier() : a;
    }

    void onScan(SimpleBLE::Peripheral p) {
        try {
            bool ftms = false, hrs = false, cps = false, zw = false;
            for (auto& s : p.services()) {
                auto u = lowerStr(s.uuid());
                if (u == proto::uuid16(proto::SVC_FTMS)) ftms = true;
                else if (u == proto::uuid16(proto::SVC_HRS)) hrs = true;
                else if (u == proto::uuid16(proto::SVC_CPS)) cps = true;
                else if (u == proto::zwift::SERVICE || u == proto::zwift::SERVICE_FC82) zw = true;
            }
            try { for (auto& [mid, data] : p.manufacturer_data()) if (mid == proto::zwift::MANUFACTURER_ID) zw = true; } catch (...) {}
            std::string name = p.identifier();
            {
                std::string ln0 = lowerStr(name);
                if (ln0.find("zwift") != std::string::npos && (ln0.find("click") != std::string::npos || ln0.find("play") != std::string::npos || ln0.find("ride") != std::string::npos)) zw = true;
            }
            std::string id = idOf(p);
            std::lock_guard<std::mutex> lk(m);
            auto it = found.find(id);
            if (it != found.end()) {  // keep what earlier adverts told us
                ftms |= it->second.ftms;
                if (name.empty()) name = it->second.name;
            }
            std::string ln = lowerStr(name);
            DeviceInfo d;
            if (zw && !ftms) d.kind = DevKind::Shifter;
            else if (ftms || ln.find("kickr") != std::string::npos) d.kind = DevKind::Trainer;
            else if (hrs) d.kind = DevKind::HeartRate;
            else if (cps) d.kind = DevKind::Power;
            else if (it != found.end()) d.kind = it->second.kind;
            else return;  // not a fitness device
            d.id = id;
            d.ftms = ftms;
            d.rssi = p.rssi();
            d.name = !name.empty() ? name : d.kind == DevKind::Trainer ? "Smart trainer" : d.kind == DevKind::HeartRate ? "Heart rate monitor" : d.kind == DevKind::Shifter ? "Zwift controller" : "Power meter";
            found[id] = d;
            peripherals[id] = p;
            bool autoT = !autoTrainer.empty() && id == autoTrainer && trainer.state == LinkState::Disconnected && trainerCancel;
            bool autoH = !autoHr.empty() && id == autoHr && hrm.state == LinkState::Disconnected && hrCancel;
            bool autoS = !autoShifter.empty() && id == autoShifter && shifter.state == LinkState::Disconnected && shifterCancel;
            if (autoT) { trainer.state = LinkState::Connecting; trainer.id = id; trainer.name = d.name; }
            if (autoH) { hrm.state = LinkState::Connecting; hrm.id = id; hrm.name = d.name; }
            if (autoS) { shifter.state = LinkState::Connecting; shifter.id = id; shifter.name = d.name; }
            if (autoT || autoH || autoS) {
                std::thread([this, id, autoT, autoH, autoS] {
                    std::lock_guard<std::mutex> g(ctl);
                    if (quit) return;
                    if (autoT) startTrainer(id);
                    if (autoH) startHrm(id);
                    if (autoS) startShifter(id);
                }).detach();
            }
        } catch (...) {
        }
    }

    std::optional<SimpleBLE::Peripheral> peripheral(const std::string& id) {
        std::lock_guard<std::mutex> lk(m);
        auto it = peripherals.find(id);
        if (it == peripherals.end()) return std::nullopt;
        return it->second;
    }

    static std::optional<std::string> findService(SimpleBLE::Peripheral& p, uint16_t chr) {
        auto c = proto::uuid16(chr);
        for (auto& s : p.services())
            for (auto& ch : s.characteristics())
                if (ch.uuid() == c) return s.uuid();
        return std::nullopt;
    }

    static std::optional<std::string> findServiceFull(SimpleBLE::Peripheral& p, const std::string& chrUuid) {
        std::string c = lowerStr(chrUuid);
        for (auto& s : p.services())
            for (auto& ch : s.characteristics())
                if (lowerStr(ch.uuid()) == c) return s.uuid();
        return std::nullopt;
    }

    // ---------------------------------------------------------------- trainer
    struct Note { uint16_t chr; std::vector<uint8_t> data; };

    void startTrainer(const std::string& id) {
        stopTrainer();
        trainerCancel = false;
        {
            std::lock_guard<std::mutex> lk(m);
            trainer.state = LinkState::Connecting;
            trainer.id = id;
            auto it = found.find(id);
            trainer.name = it != found.end() ? it->second.name : "Trainer";
            trainer.detail.clear();
        }
        trainerThread = std::thread([this, id] { trainerSupervisor(id); });
    }
    void stopTrainer() {
        trainerCancel = true;
        if (trainerThread.joinable()) trainerThread.join();
    }

    void trainerSupervisor(std::string id) {
        int attempt = 0;
        std::optional<TrainerCommand> lastCmd;
        while (!trainerCancel && !quit) {
            std::string detail = "Connection closed";
            try { trainerSession(id, lastCmd); }
            catch (std::exception& e) { detail = e.what(); }
            if (trainerCancel || quit) break;
            ++attempt;
            addLog("trainer session ended: " + detail);
            setLink(true, LinkState::Reconnecting, detail + " - retrying...");
            {
                std::lock_guard<std::mutex> lk(m);
                clearTelemetry();
            }
            double until = appClock() + std::max(1, std::min(attempt, 5));
            while (appClock() < until && !trainerCancel && !quit) sleepMs(100);
        }
        if (auto p = peripheral(id)) try { if (p->is_connected()) p->disconnect(); } catch (...) {}
        std::lock_guard<std::mutex> lk(m);
        clearTelemetry();
        trainer = Link{};
    }

    void trainerSession(const std::string& id, std::optional<TrainerCommand>& lastCmd) {
        auto po = peripheral(id);
        if (!po) throw std::runtime_error("Unknown device - scan again");
        SimpleBLE::Peripheral p = *po;
        auto dropped = std::make_shared<std::atomic<bool>>(false);
        if (!p.is_connected()) p.connect();
        p.set_callback_on_disconnected([dropped] { *dropped = true; });
        auto svcIbd = findService(p, proto::CHR_INDOOR_BIKE_DATA);
        auto svcCp = findService(p, proto::CHR_FTMS_CONTROL_POINT);
        auto svcCps = findService(p, proto::CHR_CP_MEASUREMENT);
        if (!svcIbd || !svcCp) {
            // No FTMS (older KICKR firmware, many power-meter style trainers): fall back to
            // the Cycling Power Service, with Wahoo's legacy control characteristic if present.
            if (svcCps) { cpsSession(p, dropped, lastCmd); return; }
            throw std::runtime_error("Trainer has neither FTMS nor Cycling Power. Update the trainer's firmware (Wahoo app) to enable FTMS.");
        }
        auto svcStatus = findService(p, proto::CHR_FTMS_STATUS);
        std::optional<proto::Range> powerRange, resRange;
        if (auto s = findService(p, proto::CHR_POWER_RANGE))
            try { auto b = p.read(*s, proto::uuid16(proto::CHR_POWER_RANGE)); powerRange = proto::parseRange(b.data(), b.size()); } catch (...) {}
        if (auto s = findService(p, proto::CHR_RESISTANCE_RANGE))
            try { auto b = p.read(*s, proto::uuid16(proto::CHR_RESISTANCE_RANGE)); resRange = proto::parseRange(b.data(), b.size()); } catch (...) {}

        struct NoteQueue { std::mutex m; std::deque<Note> notes; };
        auto nq = std::make_shared<NoteQueue>();
        auto onNote = [nq](uint16_t c) {
            return [nq, c](SimpleBLE::ByteArray b) {
                std::lock_guard<std::mutex> lk(nq->m);
                nq->notes.push_back({c, std::vector<uint8_t>(b.data(), b.data() + b.size())});
            };
        };
        // Bike data is handled directly in the callback (low latency); CP/status go through the queue.
        p.notify(*svcIbd, proto::uuid16(proto::CHR_INDOOR_BIKE_DATA), [this](SimpleBLE::ByteArray b) {
            auto d = proto::parseIndoorBikeData(b.data(), b.size());
            if (!d) return;
            double now = appClock();
            std::lock_guard<std::mutex> lk(m);
            if (d->power_w) { power = std::max(0, *d->power_w); lastPowerT = ibdPowerT = now; }
            if (d->cadence_rpm) { cadence = *d->cadence_rpm; lastCadT = ibdCadT = now; }
            if (d->speed_kmh) speed = *d->speed_kmh;
            if (d->heart_rate) trainerHr = *d->heart_rate > 0 ? std::optional<double>(*d->heart_rate) : std::nullopt;
            lastTrainer = now;
        });
        // Also listen to CPS when the trainer has it: FTMS stays the source of truth, but
        // trainers whose Indoor Bike Data carries no cadence get it from CPS crank events.
        auto crank = std::make_shared<proto::CrankCadence>();
        if (svcCps) try { p.notify(*svcCps, proto::uuid16(proto::CHR_CP_MEASUREMENT), cpsHandler(crank, false)); } catch (...) {}
        p.indicate(*svcCp, proto::uuid16(proto::CHR_FTMS_CONTROL_POINT), onNote(proto::CHR_FTMS_CONTROL_POINT));
        if (svcStatus) try { p.notify(*svcStatus, proto::uuid16(proto::CHR_FTMS_STATUS), onNote(proto::CHR_FTMS_STATUS)); } catch (...) {}

        auto encode = [&](const TrainerCommand& c) -> proto::Bytes {
            switch (c.type) {
                case TrainerCommand::Simulation: return proto::ftmsSetSimulation(c.gradePct, c.windMps, c.crr, c.cw);
                case TrainerCommand::TargetPower: return proto::ftmsSetTargetPower(int(std::lround(c.watts)));
                case TrainerCommand::Resistance: {
                    double lo = 0, hi = 25.4;
                    if (resRange && resRange->max > resRange->min) { lo = resRange->min / 10.0; hi = resRange->max / 10.0; }
                    return proto::ftmsSetTargetResistance(lo + (hi - lo) * std::clamp(c.levelPct, 0.0, 100.0) / 100.0);
                }
            }
            return {};
        };
        auto isTarget = [](const proto::Bytes& b) { return b[0] == 0x05 || b[0] == 0x11 || b[0] == 0x04; };

        std::deque<proto::Bytes> queue{proto::ftmsRequestControl(), proto::ftmsStart()};
        if (lastCmd) queue.push_back(encode(*lastCmd));
        std::optional<std::pair<uint8_t, double>> pending;
        bool hasControl = false;
        double sessionStart = appClock();
        {
            std::lock_guard<std::mutex> lk(m);
            trainer.state = LinkState::Connected;
            trainer.detail = "Requesting control...";
            if (powerRange) trainer.powerRange = std::make_pair(int(powerRange->min), int(powerRange->max));
        }
        addLog(trainer.name + ": connected (FTMS)");

        while (!trainerCancel && !quit) {
            if (*dropped) throw std::runtime_error("Trainer disconnected");
            // newest command from the engine replaces any queued target
            {
                std::optional<TrainerCommand> c;
                {
                    std::lock_guard<std::mutex> lk(m);
                    c = pendingCmd;
                    pendingCmd.reset();
                }
                if (c) {
                    lastCmd = c;
                    queue.erase(std::remove_if(queue.begin(), queue.end(), isTarget), queue.end());
                    queue.push_back(encode(*c));
                }
            }
            if (!pending && !queue.empty()) {
                auto b = queue.front();
                queue.pop_front();
                p.write_request(*svcCp, proto::uuid16(proto::CHR_FTMS_CONTROL_POINT), SimpleBLE::ByteArray(b));
                pending = std::make_pair(b[0], appClock());
            }
            std::deque<Note> got;
            {
                std::lock_guard<std::mutex> lk(nq->m);
                got.swap(nq->notes);
            }
            for (auto& n : got) {
                if (n.chr == proto::CHR_FTMS_CONTROL_POINT) {
                    auto r = proto::parseControlResponse(n.data.data(), n.data.size());
                    if (!r) continue;
                    if (pending && pending->first == r->request_op) pending.reset();
                    if (r->request_op == 0x00 && r->result == 0x01) {
                        hasControl = true;
                        setLink(true, LinkState::Connected, "");
                    } else if (r->result == 0x05) {
                        hasControl = false;
                        queue.push_front(proto::ftmsRequestControl());
                        if (lastCmd) queue.push_back(encode(*lastCmd));
                    } else if (r->result != 0x01) {
                        char b[80];
                        std::snprintf(b, sizeof b, "FTMS op 0x%02X -> %s", r->request_op, proto::controlResultName(r->result));
                        addLog(b);
                    }
                } else if (n.chr == proto::CHR_FTMS_STATUS) {
                    auto st = proto::parseMachineStatus(n.data.data(), n.data.size());
                    if (st && *st == proto::MachineStatus::ControlPermissionLost) {
                        hasControl = false;
                        queue.push_front(proto::ftmsStart());
                        queue.push_front(proto::ftmsRequestControl());
                        if (lastCmd) queue.push_back(encode(*lastCmd));
                    }
                }
            }
            if (pending && appClock() - pending->second > 2.0) {
                char b[48];
                std::snprintf(b, sizeof b, "FTMS op 0x%02X timed out", pending->first);
                addLog(b);
                if (pending->first == 0x00 && !hasControl) queue.push_front(proto::ftmsRequestControl());
                pending.reset();
            }
            double lt;
            {
                std::lock_guard<std::mutex> lk(m);
                lt = lastTrainer;
            }
            bool stale = lt < 0 || appClock() - lt > 6;
            if (stale && appClock() - sessionStart > 8 && !p.is_connected()) throw std::runtime_error("Trainer stopped responding");
            sleepMs(25);
        }
        try { p.unsubscribe(*svcIbd, proto::uuid16(proto::CHR_INDOOR_BIKE_DATA)); } catch (...) {}
        if (svcCps) try { p.unsubscribe(*svcCps, proto::uuid16(proto::CHR_CP_MEASUREMENT)); } catch (...) {}
    }

    // CPS notification handler. `primary`: CPS is the only data source (no FTMS), so its
    // power is used directly; otherwise it only fills in what FTMS has not sent for 3 s.
    std::function<void(SimpleBLE::ByteArray)> cpsHandler(std::shared_ptr<proto::CrankCadence> crank, bool primary) {
        return [this, crank, primary](SimpleBLE::ByteArray b) {
            auto c = proto::parseCyclingPower(b.data(), b.size());
            if (!c) return;
            double now = appClock();
            std::optional<double> cad;
            if (c->crank_revs && c->crank_event_1024) cad = crank->update(*c->crank_revs, *c->crank_event_1024, now);
            std::lock_guard<std::mutex> lk(m);
            if (primary || ibdPowerT < 0 || now - ibdPowerT > 3) { power = std::max(0, c->power_w); lastPowerT = now; }
            if (cad && (primary || ibdCadT < 0 || now - ibdCadT > 3)) { cadence = *cad; lastCadT = now; }
            if (primary) lastTrainer = now;
        };
    }

    // Trainer without FTMS: power/cadence from CPS; control (if any) through Wahoo's
    // legacy characteristic: unlock, then ERG (0x42), sim (0x43 init + 0x46 grade) or
    // resistance (0x40). Writes are coalesced so only the newest target is sent.
    void cpsSession(SimpleBLE::Peripheral& p, std::shared_ptr<std::atomic<bool>> dropped, std::optional<TrainerCommand>& lastCmd) {
        auto svcCps = findService(p, proto::CHR_CP_MEASUREMENT);
        auto crank = std::make_shared<proto::CrankCadence>();
        p.notify(*svcCps, proto::uuid16(proto::CHR_CP_MEASUREMENT), cpsHandler(crank, true));
        auto svcW = findServiceFull(p, proto::WAHOO_TRAINER_CHR);
        bool control = false;
        auto write = [&](const proto::Bytes& b) {
            p.write_request(*svcW, proto::WAHOO_TRAINER_CHR, SimpleBLE::ByteArray(b));
        };
        if (svcW) {
            try { p.indicate(*svcW, proto::WAHOO_TRAINER_CHR, [](SimpleBLE::ByteArray) {}); } catch (...) {}
            try { write(proto::wahooUnlock()); control = true; }
            catch (std::exception& e) { addLog(std::string("Wahoo unlock failed: ") + e.what()); }
        }
        {
            std::lock_guard<std::mutex> lk(m);
            trainer.state = LinkState::Connected;
            trainer.detail = control ? "Cycling Power + Wahoo control (no FTMS)" : "Power only - this trainer can't be controlled (no FTMS)";
        }
        addLog(trainer.name + (control ? ": connected (CPS + Wahoo legacy control)" : ": connected (CPS, read-only)"));
        std::optional<TrainerCommand> want = lastCmd;
        std::optional<std::tuple<double, double, double>> simInit;  // mass, crr, cw last sent
        double lastWrite = 0;
        while (!trainerCancel && !quit) {
            if (*dropped) throw std::runtime_error("Trainer disconnected");
            {
                std::lock_guard<std::mutex> lk(m);
                if (pendingCmd) { want = pendingCmd; pendingCmd.reset(); }
            }
            if (control && want && appClock() - lastWrite > 0.25) {
                TrainerCommand c = *want;
                want.reset();
                lastCmd = c;
                try {
                    if (c.type == TrainerCommand::TargetPower) { write(proto::wahooSetErg(int(std::lround(c.watts)))); simInit.reset(); }
                    else if (c.type == TrainerCommand::Resistance) { write(proto::wahooSetResistance(c.levelPct / 100.0)); simInit.reset(); }
                    else {
                        double mass = c.massKg > 20 ? c.massKg : 83.0;
                        auto key = std::make_tuple(std::round(mass), c.crr, c.cw);
                        if (simInit != key) { write(proto::wahooInitSim(mass, c.crr, c.cw)); simInit = key; sleepMs(60); }
                        write(proto::wahooSetGrade(c.gradePct));
                    }
                } catch (std::exception& e) {
                    addLog(std::string("Wahoo control write failed: ") + e.what());
                }
                lastWrite = appClock();
            }
            sleepMs(25);
        }
        try { p.unsubscribe(*svcCps, proto::uuid16(proto::CHR_CP_MEASUREMENT)); } catch (...) {}
    }

    // ---------------------------------------------------------------- heart rate
    void startHrm(const std::string& id) {
        stopHrm();
        hrCancel = false;
        {
            std::lock_guard<std::mutex> lk(m);
            hrm.state = LinkState::Connecting;
            hrm.id = id;
            auto it = found.find(id);
            hrm.name = it != found.end() ? it->second.name : "Heart rate";
            hrm.detail.clear();
        }
        hrThread = std::thread([this, id] { hrmSupervisor(id); });
    }
    void stopHrm() {
        hrCancel = true;
        if (hrThread.joinable()) hrThread.join();
    }
    void hrmSupervisor(std::string id) {
        int attempt = 0;
        while (!hrCancel && !quit) {
            std::string detail = "Connection closed";
            try { hrmSession(id); }
            catch (std::exception& e) { detail = e.what(); }
            if (hrCancel || quit) break;
            ++attempt;
            setLink(false, LinkState::Reconnecting, detail + " - retrying...");
            double until = appClock() + std::min(attempt, 5);
            while (appClock() < until && !hrCancel && !quit) sleepMs(100);
        }
        if (auto p = peripheral(id)) try { if (p->is_connected()) p->disconnect(); } catch (...) {}
        std::lock_guard<std::mutex> lk(m);
        lastHr = -1;
        hrm = Link{};
    }
    void hrmSession(const std::string& id) {
        auto po = peripheral(id);
        if (!po) throw std::runtime_error("Unknown device - scan again");
        SimpleBLE::Peripheral p = *po;
        auto dropped = std::make_shared<std::atomic<bool>>(false);
        if (!p.is_connected()) p.connect();
        p.set_callback_on_disconnected([dropped] { *dropped = true; });
        auto svc = findService(p, proto::CHR_HR_MEASUREMENT);
        if (!svc) throw std::runtime_error("Device has no heart rate measurement");
        p.notify(*svc, proto::uuid16(proto::CHR_HR_MEASUREMENT), [this](SimpleBLE::ByteArray b) {
            auto h = proto::parseHeartRate(b.data(), b.size());
            if (!h) return;
            std::lock_guard<std::mutex> lk(m);
            hr = h->bpm;
            lastHr = h->bpm > 0 ? appClock() : -1;
        });
        setLink(false, LinkState::Connected, "");
        addLog(hrm.name + ": heart rate connected");
        while (!hrCancel && !quit) {
            if (*dropped) throw std::runtime_error("Heart rate monitor disconnected");
            sleepMs(200);
        }
        try { p.unsubscribe(*svc, proto::uuid16(proto::CHR_HR_MEASUREMENT)); } catch (...) {}
    }
    // ---------------------------------------------------------------- Zwift shifter
    void startShifter(const std::string& id) {
        stopShifter();
        shifterCancel = false;
        {
            std::lock_guard<std::mutex> lk(m);
            shifter.state = LinkState::Connecting;
            shifter.id = id;
            auto it = found.find(id);
            shifter.name = it != found.end() ? it->second.name : "Zwift controller";
            shifter.detail.clear();
        }
        shifterThread = std::thread([this, id] { shifterSupervisor(id); });
    }
    void stopShifter() {
        shifterCancel = true;
        if (shifterThread.joinable()) shifterThread.join();
    }
    void shifterSupervisor(std::string id) {
        int attempt = 0;
        while (!shifterCancel && !quit) {
            std::string detail = "Connection closed";
            try { shifterSession(id); }
            catch (std::exception& e) { detail = e.what(); }
            if (shifterCancel || quit) break;
            ++attempt;
            addLog("shifter session ended: " + detail);
            setShifterLink(LinkState::Reconnecting, detail + " - retrying...");
            double until = appClock() + std::min(attempt, 5);
            while (appClock() < until && !shifterCancel && !quit) sleepMs(100);
        }
        if (auto p = peripheral(id)) try { if (p->is_connected()) p->disconnect(); } catch (...) {}
        std::lock_guard<std::mutex> lk(m);
        shifter = Link{};
    }
    void shifterSession(const std::string& id) {
        auto po = peripheral(id);
        if (!po) throw std::runtime_error("Unknown device - scan again");
        SimpleBLE::Peripheral p = *po;
        auto dropped = std::make_shared<std::atomic<bool>>(false);
        if (!p.is_connected()) p.connect();
        p.set_callback_on_disconnected([dropped] { *dropped = true; });
        auto svc = findServiceFull(p, proto::zwift::ASYNC);
        if (!svc) throw std::runtime_error("Not a Zwift controller (no Zwift button service)");
        auto edges = std::make_shared<proto::zwift::ShiftEdges>();
        p.notify(*svc, proto::zwift::ASYNC, [this, edges](SimpleBLE::ByteArray b) {
            auto btn = proto::zwift::parseButtons(b.data(), b.size());
            if (!btn) return;
            int d = edges->update(*btn);
            if (d) { std::lock_guard<std::mutex> lk(m); shifts += d; }
        });
        if (auto tx = findServiceFull(p, proto::zwift::SYNC_TX)) try { p.indicate(*tx, proto::zwift::SYNC_TX, [](SimpleBLE::ByteArray) {}); } catch (...) {}
        // the handshake: "RideOn" starts plain button notifications
        if (auto rx = findServiceFull(p, proto::zwift::SYNC_RX)) {
            SimpleBLE::ByteArray hello(proto::zwift::rideOn());
            try { p.write_request(*rx, proto::zwift::SYNC_RX, hello); }
            catch (...) { p.write_command(*rx, proto::zwift::SYNC_RX, hello); }
        }
        setShifterLink(LinkState::Connected, "");
        addLog(shifter.name + ": shifter connected");
        while (!shifterCancel && !quit) {
            if (*dropped) throw std::runtime_error("Shifter disconnected");
            sleepMs(100);
        }
        try { p.unsubscribe(*svc, proto::zwift::ASYNC); } catch (...) {}
    }
#else
    void startShifter(const std::string&) {}
    void stopShifter() {}
    void startTrainer(const std::string&) {}
    void stopTrainer() {}
    void startHrm(const std::string&) {}
    void stopHrm() {}
#endif
};

BleManager::BleManager() : impl_(std::make_unique<Impl>()) {
#ifdef CORERAY_BLE
    // adapter init can block briefly on macOS while CoreBluetooth powers up
    impl_->scanThread = std::thread([this] {
        impl_->initAdapter();
        while (!impl_->quit) {
            if (impl_->scanning && appClock() > impl_->scanUntil) stopScan();
            sleepMs(250);
        }
    });
#endif
}

BleManager::~BleManager() {
    impl_->quit = true;
    impl_->trainerCancel = true;
    impl_->hrCancel = true;
    impl_->shifterCancel = true;
    std::lock_guard<std::mutex> g(impl_->ctl);
    impl_->stopTrainer();
    impl_->stopHrm();
    impl_->stopShifter();
#ifdef CORERAY_BLE
    try { if (impl_->adapter && impl_->adapter->scan_is_active()) impl_->adapter->scan_stop(); } catch (...) {}
#endif
    if (impl_->scanThread.joinable()) impl_->scanThread.join();
}

bool BleManager::available() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->hasAdapter; }
std::string BleManager::status() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->adapterMsg; }
bool BleManager::scanning() const { return impl_->scanning; }

void BleManager::startScan(int seconds) {
#ifdef CORERAY_BLE
    std::thread([this, seconds] {
        for (int i = 0; i < 40 && !available() && !impl_->quit; ++i) sleepMs(100);  // wait for adapter
        try {
            if (impl_->adapter && !impl_->adapter->scan_is_active()) impl_->adapter->scan_start();
            impl_->scanUntil = appClock() + std::clamp(seconds, 5, 600);
            impl_->scanning = impl_->adapter != nullptr;
        } catch (std::exception& e) {
            impl_->addLog(std::string("Failed to start scanning: ") + e.what());
        }
    }).detach();
#else
    (void)seconds;
#endif
}

void BleManager::stopScan() {
#ifdef CORERAY_BLE
    try { if (impl_->adapter && impl_->adapter->scan_is_active()) impl_->adapter->scan_stop(); } catch (...) {}
#endif
    impl_->scanning = false;
}

std::vector<DeviceInfo> BleManager::devices() const {
    std::lock_guard<std::mutex> lk(impl_->m);
    std::vector<DeviceInfo> v;
    for (auto& [k, d] : impl_->found) v.push_back(d);
    std::sort(v.begin(), v.end(), [](const DeviceInfo& a, const DeviceInfo& b) {
        auto rank = [](DevKind k) { return k == DevKind::Trainer ? 0 : k == DevKind::Power ? 1 : 2; };
        if (rank(a.kind) != rank(b.kind)) return rank(a.kind) < rank(b.kind);
        return a.rssi > b.rssi;
    });
    return v;
}

void BleManager::connectTrainer(const std::string& id) {
    { std::lock_guard<std::mutex> lk(impl_->m); impl_->trainer.state = LinkState::Connecting; impl_->trainer.id = id; }
    std::thread([this, id] { std::lock_guard<std::mutex> g(impl_->ctl); if (!impl_->quit) impl_->startTrainer(id); }).detach();
}
void BleManager::disconnectTrainer() {
    impl_->trainerCancel = true;
    std::thread([this] { std::lock_guard<std::mutex> g(impl_->ctl); impl_->stopTrainer(); }).detach();
}
void BleManager::connectHrm(const std::string& id) {
    { std::lock_guard<std::mutex> lk(impl_->m); impl_->hrm.state = LinkState::Connecting; impl_->hrm.id = id; }
    std::thread([this, id] { std::lock_guard<std::mutex> g(impl_->ctl); if (!impl_->quit) impl_->startHrm(id); }).detach();
}
void BleManager::disconnectHrm() {
    impl_->hrCancel = true;
    std::thread([this] { std::lock_guard<std::mutex> g(impl_->ctl); impl_->stopHrm(); }).detach();
}

void BleManager::connectShifter(const std::string& id) {
    { std::lock_guard<std::mutex> lk(impl_->m); impl_->shifter.state = LinkState::Connecting; impl_->shifter.id = id; }
    std::thread([this, id] { std::lock_guard<std::mutex> g(impl_->ctl); if (!impl_->quit) impl_->startShifter(id); }).detach();
}
void BleManager::disconnectShifter() {
    impl_->shifterCancel = true;
    std::thread([this] { std::lock_guard<std::mutex> g(impl_->ctl); impl_->stopShifter(); }).detach();
}
Link BleManager::shifter() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->shifter; }
int BleManager::takeShifts() {
    std::lock_guard<std::mutex> lk(impl_->m);
    int n = impl_->shifts;
    impl_->shifts = 0;
    return n;
}

Link BleManager::trainer() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->trainer; }
Link BleManager::hrm() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->hrm; }

void BleManager::setAutoConnect(const std::string& t, const std::string& h, const std::string& sh) {
    std::lock_guard<std::mutex> lk(impl_->m);
    impl_->autoTrainer = t;
    impl_->autoHr = h;
    impl_->autoShifter = sh;
}

void BleManager::send(const TrainerCommand& c) {
    std::lock_guard<std::mutex> lk(impl_->m);
    impl_->pendingCmd = c;
}

TrainerInput BleManager::input() const {
    std::lock_guard<std::mutex> lk(impl_->m);
    double now = appClock();
    bool fresh = impl_->lastTrainer >= 0 && now - impl_->lastTrainer < 3;
    bool hrFresh = impl_->lastHr >= 0 && now - impl_->lastHr < 5;
    TrainerInput in;
    in.powerW = fresh && impl_->lastPowerT >= 0 && now - impl_->lastPowerT < 3 ? impl_->power : 0;
    in.cadenceRpm = fresh && impl_->lastCadT >= 0 && now - impl_->lastCadT < 3 ? impl_->cadence : 0;
    in.heartRate = hrFresh ? std::optional<double>(impl_->hr) : fresh ? impl_->trainerHr : std::nullopt;
    in.connected = fresh;
    if (fresh && impl_->speed) in.trainerSpeedKmh = impl_->speed;
    return in;
}

std::optional<double> BleManager::speedKmh() const { std::lock_guard<std::mutex> lk(impl_->m); return impl_->speed; }

std::vector<std::string> BleManager::log() const {
    std::lock_guard<std::mutex> lk(impl_->m);
    return {impl_->logLines.begin(), impl_->logLines.end()};
}
