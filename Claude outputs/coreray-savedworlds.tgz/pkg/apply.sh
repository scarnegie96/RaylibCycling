#!/bin/bash
# Applies the "saved worlds + ride/weather HUD + weather systems" changes to a CoreRay tree.
# Usage:  bash apply.sh [path-to-CoreRay]   (default ~/CoreRay)
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TREE="${1:-$HOME/CoreRay}"
cd "$TREE"
MD5() { if command -v md5sum >/dev/null; then md5sum "$1" | cut -d' ' -f1; else md5 -q "$1"; fi; }
bad=0
while read -r sum f; do
  [ "$(MD5 "$f")" = "$sum" ] || { echo "changed since the last delivery: $f"; bad=1; }
done < "$HERE/pre.md5"
[ $bad = 0 ] || { echo "Not applied: these files differ from what the package expects."; exit 1; }
mkdir -p "Claude outputs/pre-savedworlds"
tar czf "Claude outputs/pre-savedworlds/backup.tgz" $(awk '{print $2}' "$HERE/pre.md5")
while read -r sum f; do cp -f "$HERE/files/$f" "$f"; done < "$HERE/post.md5"
while read -r sum f; do
  [ "$(MD5 "$f")" = "$sum" ] || { echo "copy failed: $f"; exit 1; }
done < "$HERE/post.md5"
echo "Applied $(wc -l < "$HERE/post.md5" | tr -d ' ') files; originals in Claude outputs/pre-savedworlds/backup.tgz. Now rebuild."
