// Towns and the road network laid over the finished land.
#include <atomic>
#include <cstdlib>
#include <functional>
#include <cstdio>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>

#include "world/WorldInternal.h"
#include "world/WorldMap.h"

namespace wmap {
using namespace detail;

namespace {

const int NB = 16;
const int MX[NB] = {1, 0, -1, 0, 1, -1, 1, -1, 2, 1, -1, -2, -2, -1, 1, 2};
const int MZ[NB] = {0, 1, 0, -1, 1, 1, -1, -1, 1, 2, 2, 1, -1, -2, -2, -1};
constexpr float HW = 3.6f;   // road half width (matches Course::roadHalfWidth)

std::string placeName(std::mt19937& r, int rank) {
    static const char* A[] = {"Ash", "Bram", "Cal", "Dun", "Eld", "Fen", "Gil", "Hart", "Ivy", "Kel", "Lang", "Mar", "Nor", "Oak", "Pen",
                              "Quar", "Rook", "Sand", "Thorn", "Ul", "Ven", "Wes", "Yar", "Brack", "Cold", "Red", "Stone", "High", "Elm", "Wolf"};
    static const char* B[] = {"ford", "by", "ton", "ley", "wick", "stead", "bridge", "mere", "dale", "thorpe", "holm", "field", "combe",
                              "well", "burn", "haven", "moor", "cross", "gate", "worth"};
    std::string s = std::string(A[r() % (sizeof(A) / sizeof(*A))]) + B[r() % (sizeof(B) / sizeof(*B))];
    if (rank == 2 && r() % 4 == 0) s = "Great " + s;
    return s;
}

struct Router {
    Map& M;
    int n;
    float cell;
    std::vector<float> hs;          // smoothed ground for grades
    std::vector<uint8_t> lake;      // impassable water
    std::vector<float> riverW;      // channel width under the cell (0 = none)
    std::vector<float> rdx, rdz;    // river direction
    std::vector<float> biomeCost;   // dunes, marsh, ...
    std::vector<int> roadOf;        // cell -> road id
    explicit Router(Map& m) : M(m), n(m.n), cell(m.cell) {}
    size_t id(int i, int k) const { return size_t(k) * n + i; }
    float X(int i) const { return M.x0 + i * cell; }
    float Z(int k) const { return M.z0 + k * cell; }

    void prepare() {
        const size_t NN = size_t(n) * n;
        hs = M.h;
        for (int pass = 0; pass < 2; ++pass) {
            std::vector<float> s(hs);
            parallelFor(n - 2, [&](int kk) {
                int k = kk + 1;
                for (int i = 1; i < n - 1; ++i) {
                    float a = 0;
                    for (int dk = -1; dk <= 1; ++dk) for (int di = -1; di <= 1; ++di) a += hs[id(i + di, k + dk)];
                    s[id(i, k)] = a / 9.f;
                }
            });
            hs.swap(s);
        }
        lake.assign(NN, 0);
        for (size_t c = 0; c < NN; ++c)
            if (M.lakeId[c] >= 0 && !M.lakes[M.lakeId[c]].playa) lake[c] = 1;
        riverW.assign(NN, 0.f);
        rdx.assign(NN, 0.f);
        rdz.assign(NN, 0.f);
        for (const River& R : M.rivers) {
            if (R.dry) continue;
            for (size_t j = 0; j + 1 < R.pts.size(); ++j) {
                const RiverPt& p = R.pts[j];
                const RiverPt& q = R.pts[j + 1];
                float w = 2 * p.half;
                if (w < 1.2f) continue;
                int r = std::max(0, int(std::ceil((p.half + 2.f) / cell)));
                int ci = int(std::lround((p.x - M.x0) / cell)), ck = int(std::lround((p.z - M.z0) / cell));
                float tx = q.x - p.x, tz = q.z - p.z, tl = std::max(1e-3f, std::hypot(tx, tz));
                for (int dk = -r; dk <= r; ++dk)
                    for (int di = -r; di <= r; ++di) {
                        int a = ci + di, b = ck + dk;
                        if (a < 0 || b < 0 || a >= n || b >= n) continue;
                        if (std::hypot(X(a) - p.x, Z(b) - p.z) > p.half + 0.75f * cell) continue;
                        size_t c = id(a, b);
                        if (w > riverW[c]) { riverW[c] = w; rdx[c] = tx / tl; rdz[c] = tz / tl; }
                    }
            }
        }
        biomeCost.assign(NN, 1.f);
        parallelFor(n, [&](int k) {
            for (int i = 0; i < n; ++i) {
                float w[BIOMES];
                M.biomeAt(X(i), Z(k), w);
                biomeCost[id(i, k)] = 1.f + 3.5f * w[Dunes] + 2.5f * w[Wetland] + 0.4f * w[Badlands] + (M.wash[id(i, k)] ? 0.6f : 0.f);
            }
        });
        roadOf.assign(NN, -1);
    }

    // A* between two cells; returns cells (start..end) or empty
    std::vector<int> route(int s, int t, int cls) {
        const float gs = cls == 0 ? 0.05f : 0.07f, gmax = cls == 0 ? 0.085f : 0.12f;
        int si = s % n, sk = s / n, ti = t % n, tk = t / n;
        float dist = std::hypot(float(si - ti), float(sk - tk));
        // room to wind up and down: big climbs need a longer road than the straight line
        float dh = std::fabs(hs[s] - hs[t]);
        int margin = int(std::max({70.f, dist * 0.55f, dh / (cls == 0 ? 0.08f : 0.11f) / cell * 0.35f}));
        int i0 = std::max(1, std::min(si, ti) - margin), i1 = std::min(n - 2, std::max(si, ti) + margin);
        int k0 = std::max(1, std::min(sk, tk) - margin), k1 = std::min(n - 2, std::max(sk, tk) + margin);
        int W = i1 - i0 + 1, H = k1 - k0 + 1;
        auto L = [&](int i, int k) { return (k - k0) * W + (i - i0); };
        std::vector<float> g(size_t(W) * H, 1e30f);
        std::vector<int> par(size_t(W) * H, -1);
        std::vector<int8_t> pdir(size_t(W) * H, -1);
        std::vector<uint8_t> closed(size_t(W) * H, 0);
        std::vector<float> leg(size_t(W) * H, 1e4f);   // straight distance since the last real turn
        using QE = std::pair<float, int>;
        std::priority_queue<QE, std::vector<QE>, std::greater<QE>> pq;
        g[L(si, sk)] = 0;
        pq.push({0, L(si, sk)});
        const float tx = X(ti), tz = Z(tk);
        float dl[NB];
        for (int d = 0; d < NB; ++d) dl[d] = std::hypot(float(MX[d]), float(MZ[d]));
        bool found = false;
        while (!pq.empty()) {
            auto [f, l] = pq.top();
            pq.pop();
            if (closed[l]) continue;
            closed[l] = 1;
            int i = l % W + i0, k = l / W + k0;
            if (i == ti && k == tk) { found = true; break; }
            size_t c = id(i, k);
            int pd = pdir[l];
            for (int d = 0; d < NB; ++d) {
                int a = i + MX[d], b = k + MZ[d];
                if (a < i0 || b < k0 || a > i1 || b > k1) continue;
                int nl = L(a, b);
                if (closed[nl]) continue;
                size_t nc = id(a, b);
                if (lake[nc]) continue;
                // cells a knight's move passes over
                size_t mid1 = c, mid2 = nc;
                if (std::abs(MX[d]) + std::abs(MZ[d]) == 3) {
                    mid1 = id(i + (MX[d] / 2 != 0 ? MX[d] / 2 : 0), k + (MZ[d] / 2 != 0 ? MZ[d] / 2 : 0));
                    mid2 = id(i + (MX[d] - (MX[d] / 2)), k + (MZ[d] - (MZ[d] / 2)));
                    mid1 = id(i + (std::abs(MX[d]) == 2 ? MX[d] / 2 : 0), k + (std::abs(MZ[d]) == 2 ? MZ[d] / 2 : 0));
                    mid2 = id(i + (std::abs(MX[d]) == 2 ? MX[d] / 2 : MX[d]), k + (std::abs(MZ[d]) == 2 ? MZ[d] / 2 : MZ[d]));
                    if (lake[mid1] || lake[mid2]) continue;
                }
                float len = dl[d] * cell;
                // grade on the real ground (a smoothed grid would hide mesa cliffs and canyon walls),
                // the larger of the step itself and the smoothed trend
                float gr = std::max(std::fabs(M.h[nc] - M.h[c]), std::fabs(hs[nc] - hs[c])) / len;
                float fac = 1.f + 1.5f * (gr / gs) * (gr / gs);
                if (gr > gmax) fac += 220.f * (gr - gmax) / 0.01f;
                fac *= 0.5f * (biomeCost[c] + biomeCost[nc]);
                bool reuse = roadOf[nc] >= 0 && roadOf[c] >= 0;
                if (reuse) fac *= 0.3f;
                float cost = len * fac;
                // bridges: short and square to the current
                float rw = std::max({riverW[nc], riverW[mid1], riverW[mid2]});
                if (rw > 0 && !reuse && riverW[c] <= 0) {
                    if (rw > 45.f) continue;
                    size_t rc = riverW[nc] > 0 ? nc : riverW[mid1] > 0 ? mid1 : mid2;
                    float mxn = MX[d] / dl[d], mzn = MZ[d] / dl[d];
                    float along = std::fabs(mxn * rdx[rc] + mzn * rdz[rc]);
                    cost += 140.f + 14.f * rw + 600.f * along * along;
                }
                if (riverW[c] > 0 && riverW[nc] > 0 && !reuse) cost += 400.f;   // never along a river
                // every metre climbed costs (engineers and cyclists both go round when they can)
                cost += std::fabs(M.h[nc] - M.h[c]) * (cls == 0 ? 6.f : 4.f);
                if (pd >= 0) {
                    float dot = (MX[d] * MX[pd] + MZ[d] * MZ[pd]) / (dl[d] * dl[pd]);
                    float ang = std::acos(std::clamp(dot, -1.f, 1.f));
                    cost += ang * ang * (cls == 0 ? 60.f : 35.f);
                    // a hairpin is expensive, and only after a long straight leg (no zigzags)
                    // no turn sharper than ~100 degrees: a hairpin is two right-angle bends
                    // with a stretch between, so its legs lie well apart
                    if (ang > 1.75f) continue;
                    if (ang > 1.2f) {
                        if (leg[l] < 60.f) continue;
                        cost += cls == 0 ? 260.f : 160.f;
                    }
                }
                float ng = g[l] + cost;
                if (ng < g[nl]) {
                    g[nl] = ng;
                    par[nl] = l;
                    pdir[nl] = int8_t(d);
                    {
                        float ang = 0;
                        if (pd >= 0) ang = std::acos(std::clamp((MX[d] * MX[pd] + MZ[d] * MZ[pd]) / (dl[d] * dl[pd]), -1.f, 1.f));
                        leg[nl] = ang > 0.5f ? len : leg[l] + len;
                    }
                    float h = 0.55f * std::hypot(X(a) - tx, Z(b) - tz);
                    pq.push({ng + h, nl});
                }
            }
        }
        if (!found) return {};
        std::vector<int> path;
        for (int l = L(ti, tk); l >= 0; l = par[l]) path.push_back(int(id(l % W + i0, l / W + k0)));
        std::reverse(path.begin(), path.end());
        return path;
    }
    void mark(const std::vector<int>& path, int road) {
        for (size_t j = 0; j + 1 < path.size(); ++j) {
            int a = path[j], b = path[j + 1];
            int ai = a % n, ak = a / n, bi = b % n, bk = b / n;
            int steps = std::max(std::abs(bi - ai), std::abs(bk - ak)) * 2;
            for (int s = 0; s <= steps; ++s) {
                int i = int(std::lround(ai + (bi - ai) * float(s) / steps)), k = int(std::lround(ak + (bk - ak) * float(s) / steps));
                // the road and a cell either side: a later route that comes this close joins it
                for (int dk = -1; dk <= 1; ++dk)
                    for (int di = -1; di <= 1; ++di) {
                        int a2 = i + di, b2 = k + dk;
                        if (a2 < 0 || b2 < 0 || a2 >= n || b2 >= n) continue;
                        size_t c = id(a2, b2);
                        if (roadOf[c] < 0) roadOf[c] = road;
                    }
            }
        }
    }
};

struct Proto {                     // a road before the network is split at its junctions
    std::vector<RoadPt> pts;
    int cls = 1;
    int joinA = -1, joinB = -1;    // road it branches from at each end
    int townA = -1, townB = -1;
};

void chaikin(std::vector<RoadPt>& p, int iters) {
    for (int it = 0; it < iters; ++it) {
        if (p.size() < 3) return;
        std::vector<RoadPt> o;
        o.push_back(p.front());
        for (size_t j = 0; j + 1 < p.size(); ++j) {
            const RoadPt& a = p[j];
            const RoadPt& b = p[j + 1];
            o.push_back({lerpf(a.x, b.x, 0.25f), lerpf(a.z, b.z, 0.25f), lerpf(a.y, b.y, 0.25f)});
            o.push_back({lerpf(a.x, b.x, 0.75f), lerpf(a.z, b.z, 0.75f), lerpf(a.y, b.y, 0.75f)});
        }
        o.push_back(p.back());
        p.swap(o);
    }
}
std::vector<RoadPt> resample(const std::vector<RoadPt>& p, float step) {
    std::vector<RoadPt> o;
    if (p.size() < 2) return p;
    std::vector<float> acc(p.size(), 0.f);
    for (size_t j = 1; j < p.size(); ++j) acc[j] = acc[j - 1] + std::hypot(p[j].x - p[j - 1].x, p[j].z - p[j - 1].z);
    int N = std::max(1, int(std::lround(acc.back() / step)));
    size_t j = 0;
    for (int s = 0; s <= N; ++s) {
        float t = acc.back() * s / N;
        while (j + 2 < p.size() && acc[j + 1] < t) ++j;
        float f = (t - acc[j]) / std::max(1e-6f, acc[j + 1] - acc[j]);
        f = std::clamp(f, 0.f, 1.f);
        o.push_back({lerpf(p[j].x, p[j + 1].x, f), lerpf(p[j].z, p[j + 1].z, f), lerpf(p[j].y, p[j + 1].y, f)});
    }
    return o;
}
float polyLen(const std::vector<RoadPt>& p) {
    float L = 0;
    for (size_t j = 1; j < p.size(); ++j) L += std::hypot(p[j].x - p[j - 1].x, p[j].z - p[j - 1].z);
    return L;
}
// nearest point on a polyline: segment index and parameter
float nearestOn(const std::vector<RoadPt>& p, float x, float z, size_t& seg, float& t) {
    float best = 1e30f;
    seg = 0; t = 0;
    for (size_t j = 0; j + 1 < p.size(); ++j) {
        float tt;
        float d = segDist(x, z, p[j].x, p[j].z, p[j + 1].x, p[j + 1].z, tt);
        if (d < best) { best = d; seg = j; t = tt; }
    }
    return best;
}

}  // namespace

void buildRoads(Map& M, std::mt19937& rng, const Progress& progress) {
    Router R(M);
    R.prepare();
    const int n = M.n;
    const float cell = M.cell;
    auto X = [&](int i) { return M.x0 + i * cell; };
    auto Z = [&](int k) { return M.z0 + k * cell; };
    auto U = [&]() { return std::uniform_real_distribution<float>(0.f, 1.f)(rng); };

    // ---------------------------------------------------------------- towns
    {
        // distance to permanent water
        const size_t NN = size_t(n) * n;
        std::vector<float> dw(NN, 1e9f);
        for (size_t c = 0; c < NN; ++c)
            if (R.lake[c] || R.riverW[c] > 2.f) dw[c] = 0;
        for (int k = 0; k < n; ++k)
            for (int i = 0; i < n; ++i) {
                float& v = dw[R.id(i, k)];
                if (i > 0) v = std::min(v, dw[R.id(i - 1, k)] + cell);
                if (k > 0) v = std::min(v, dw[R.id(i, k - 1)] + cell);
            }
        for (int k = n - 1; k >= 0; --k)
            for (int i = n - 1; i >= 0; --i) {
                float& v = dw[R.id(i, k)];
                if (i < n - 1) v = std::min(v, dw[R.id(i + 1, k)] + cell);
                if (k < n - 1) v = std::min(v, dw[R.id(i, k + 1)] + cell);
            }
        struct Cand { float s; int i, k; };
        std::vector<Cand> cands;
        const int edge = int(900.f / cell), st = 4;
        for (int k = edge; k < n - edge; k += st)
            for (int i = edge; i < n - edge; i += st) {
                size_t c = R.id(i, k);
                if (R.lake[c] || R.riverW[c] > 0) continue;
                float sx = (R.hs[R.id(i + 5, k)] - R.hs[R.id(i - 5, k)]) / (10 * cell);
                float sz = (R.hs[R.id(i, k + 5)] - R.hs[R.id(i, k - 5)]) / (10 * cell);
                float slope = std::hypot(sx, sz);
                float flat = sstep(0.09f, 0.015f, slope);
                // and no cliff or canyon edge anywhere close
                float lo = 1e9f, hi = -1e9f;
                for (int dk = -4; dk <= 4; dk += 2)
                    for (int di = -4; di <= 4; di += 2) { float v = M.h[R.id(i + di, k + dk)]; lo = std::min(lo, v); hi = std::max(hi, v); }
                if (hi - lo > 22.f) continue;
                float d = dw[c];
                float water = std::exp(-((d - 180.f) * (d - 180.f)) / (2 * 380.f * 380.f)) * sstep(25.f, 70.f, d);
                float w[BIOMES];
                M.biomeAt(X(i), Z(k), w);
                float pen = 0.95f * w[Dunes] + 0.75f * w[Wetland] + 0.7f * w[Alpine] + 0.35f * w[Badlands] + 0.2f * w[Boreal];
                if (M.temp[c] < 1.f) pen = 1;
                float s = flat * (0.35f + 0.65f * water) * (1.f - std::min(1.f, pen)) + 0.08f * hashf(i, k, M.params.seed + 7);
                if (s > 0.2f) cands.push_back({s, i, k});
            }
        std::sort(cands.begin(), cands.end(), [](const Cand& a, const Cand& b) { return a.s > b.s; });
        const float area = M.params.size * M.params.size / 4.2e8f;   // 1 for 20 km
        const int maxTowns = std::max(2, int(7 * area)), maxVillages = std::max(4, int(26 * area));
        auto farEnough = [&](float x, float z, float d) {
            for (const Town& t : M.towns) if (std::hypot(t.x - x, t.z - z) < d) return false;
            return true;
        };
        for (const Cand& c : cands) {
            if (int(M.towns.size()) >= maxTowns) break;
            if (!farEnough(X(c.i), Z(c.k), 4200.f)) continue;
            M.towns.push_back({X(c.i), Z(c.k), M.grid(c.i, c.k), 2, ""});
        }
        int nt = int(M.towns.size());
        for (const Cand& c : cands) {
            if (int(M.towns.size()) >= nt + maxVillages) break;
            if (c.s < 0.32f) break;
            if (!farEnough(X(c.i), Z(c.k), 1700.f)) continue;
            M.towns.push_back({X(c.i), Z(c.k), M.grid(c.i, c.k), 1, ""});
        }
        std::set<std::string> used;
        for (Town& t : M.towns) {
            std::string s;
            do s = placeName(rng, t.rank); while (used.count(s));
            used.insert(s);
            t.name = s;
        }
        M.stats.towns = int(M.towns.size());
    }
    if (M.towns.size() < 2) return;
    if (progress) progress("roads", 0.75f);

    // ---------------------------------------------------------------- the links
    const int P = int(M.towns.size());
    struct E { int a, b; float len; int cls; bool tree = false; };
    std::vector<E> gab;
    for (int a = 0; a < P; ++a)
        for (int b = a + 1; b < P; ++b) {
            float mx = 0.5f * (M.towns[a].x + M.towns[b].x), mz = 0.5f * (M.towns[a].z + M.towns[b].z);
            float r2 = 0.25f * ((M.towns[a].x - M.towns[b].x) * (M.towns[a].x - M.towns[b].x) + (M.towns[a].z - M.towns[b].z) * (M.towns[a].z - M.towns[b].z));
            bool ok = true;
            for (int c = 0; c < P && ok; ++c)
                if (c != a && c != b && (M.towns[c].x - mx) * (M.towns[c].x - mx) + (M.towns[c].z - mz) * (M.towns[c].z - mz) < r2) ok = false;
            if (!ok) continue;
            float len = std::sqrt(r2) * 2;
            gab.push_back({a, b, len, (M.towns[a].rank == 2 && M.towns[b].rank == 2) ? 0 : 1, false});
        }
    std::sort(gab.begin(), gab.end(), [](const E& x, const E& y) { return x.len < y.len; });
    std::vector<int> uf(P);
    std::iota(uf.begin(), uf.end(), 0);
    std::function<int(int)> find = [&](int x) { return uf[x] == x ? x : uf[x] = find(uf[x]); };
    std::vector<E> links;
    for (E e : gab) {
        int ra = find(e.a), rb = find(e.b);
        e.tree = ra != rb;
        if (e.tree) uf[ra] = rb;
        if (e.tree || (e.len < 9000.f && U() < 0.85f)) links.push_back(e);
    }
    // the main roads first, then the minor ones, each shortest first
    std::stable_sort(links.begin(), links.end(), [](const E& x, const E& y) { return x.cls < y.cls; });

    // ---------------------------------------------------------------- route them
    std::vector<Proto> protos;
    int done = 0;
    for (const E& e : links) {
        const Town& A = M.towns[e.a];
        const Town& B = M.towns[e.b];
        int s = int(R.id(int(std::lround((A.x - M.x0) / cell)), int(std::lround((A.z - M.z0) / cell))));
        int t = int(R.id(int(std::lround((B.x - M.x0) / cell)), int(std::lround((B.z - M.z0) / cell))));
        auto path = R.route(s, t, e.cls);
        if (std::getenv("WMAP_PROFILE")) std::printf("    link %s-%s %.1f km cls %d: %zu cells\n", M.towns[e.a].name.c_str(), M.towns[e.b].name.c_str(), e.len / 1000, e.cls, path.size());
        if (progress) progress("roads", 0.75f + 0.17f * float(++done) / links.size());
        if (path.size() < 2) continue;
        if (!e.tree) {   // optional links that need a staircase of hairpins or a long detour aren't built
            int hairpins = 0;
            float plen = 0;
            for (size_t j = 1; j < path.size(); ++j) {
                plen += std::hypot(float(path[j] % n - path[j - 1] % n), float(path[j] / n - path[j - 1] / n)) * cell;
                if (j + 1 < path.size()) {
                    float ax = float(path[j] % n - path[j - 1] % n), az = float(path[j] / n - path[j - 1] / n);
                    float bx = float(path[j + 1] % n - path[j] % n), bz = float(path[j + 1] / n - path[j] / n);
                    float c = (ax * bx + az * bz) / std::max(1e-3f, std::hypot(ax, az) * std::hypot(bx, bz));
                    hairpins += c < 0.35f;
                }
            }
            if (hairpins > 2 || plen > 2.2f * e.len) continue;
        }
        // split into runs of new road; where it runs along an existing road it reuses it
        std::vector<int> run;
        int joinFrom = -1;
        bool fresh = false;
        auto flush = [&](int joinTo, bool endsAtTown) {
            if (run.size() >= 2) {
                Proto p;
                p.cls = e.cls;
                p.joinA = joinFrom; p.joinB = joinTo;
                if (joinFrom < 0) p.townA = e.a;
                if (endsAtTown) p.townB = e.b;
                for (int c : run) p.pts.push_back({X(c % n), Z(c / n), M.h[c]});
                int rid = int(protos.size());
                R.mark(run, rid);
                protos.push_back(std::move(p));
            }
            run.clear();
        };
        for (size_t j = 0; j < path.size(); ++j) {
            int c = path[j];
            int owner = R.roadOf[c];
            if (owner >= 0) {
                if (fresh) { run.push_back(c); flush(owner, false); }
                run.clear();
                run.push_back(c);
                joinFrom = owner;
                fresh = false;
            } else {
                run.push_back(c);
                fresh = true;
            }
        }
        if (fresh) flush(-1, true);
    }

    // ---------------------------------------------------------------- shape them
    for (Proto& p : protos) {
        chaikin(p.pts, 3);
        p.pts = resample(p.pts, 5.f);
    }
    // branch roads start exactly on the road they leave
    struct Split { int road; size_t seg; float t; float x, z; };
    std::vector<Split> splits;
    for (size_t r = 0; r < protos.size(); ++r) {
        Proto& p = protos[r];
        for (int end = 0; end < 2; ++end) {
            int j = end == 0 ? p.joinA : p.joinB;
            if (j < 0 || j == int(r) || p.pts.size() < 3) continue;
            RoadPt& e = end == 0 ? p.pts.front() : p.pts.back();
            size_t seg;
            float t;
            float d = nearestOn(protos[j].pts, e.x, e.z, seg, t);
            if (d > 60.f) continue;
            const auto& a = protos[j].pts[seg];
            const auto& b = protos[j].pts[seg + 1];
            float sx = lerpf(a.x, b.x, t), sz = lerpf(a.z, b.z, t);
            // ease the last stretch onto the junction
            float dx = sx - e.x, dz = sz - e.z;
            float accd = 0;
            int N = int(p.pts.size());
            for (int q = 0; q < N; ++q) {
                int qi = end == 0 ? q : N - 1 - q;
                if (q > 0) {
                    int qp = end == 0 ? qi - 1 : qi + 1;
                    accd += std::hypot(p.pts[qi].x - p.pts[qp].x, p.pts[qi].z - p.pts[qp].z);
                }
                float f = 1.f - sstep(0.f, 60.f, accd);
                if (f <= 0) break;
                p.pts[qi].x += dx * f;
                p.pts[qi].z += dz * f;
            }
            splits.push_back({j, seg, t, sx, sz});
        }
    }
    // ---------------------------------------------------------------- profiles
    // the land under the line, smoothed, then held to the grade limit; junctions meet the road
    // they leave; rivers pass under bridges with clearance
    auto profileAt = [&](const Proto& p, float x, float z) {
        size_t seg;
        float t;
        nearestOn(p.pts, x, z, seg, t);
        return lerpf(p.pts[seg].y, p.pts[seg + 1].y, t);
    };
    std::vector<Bridge> bridges;
    for (size_t r = 0; r < protos.size(); ++r) {
        Proto& p = protos[r];
        const size_t N = p.pts.size();
        std::vector<float> y(N), s(N, 0.f);
        for (size_t j = 0; j < N; ++j) {
            y[j] = M.height(p.pts[j].x, p.pts[j].z);
            if (j) s[j] = s[j - 1] + std::hypot(p.pts[j].x - p.pts[j - 1].x, p.pts[j].z - p.pts[j - 1].z);
        }
        for (int pass = 0; pass < 3; ++pass) {   // ~ +-30 m Gaussian-ish smoothing
            std::vector<float> o(y);
            for (size_t j = 0; j < N; ++j) {
                float a = 0, w = 0;
                for (int k = -6; k <= 6; ++k) {
                    long q = long(j) + k;
                    if (q < 0 || q >= long(N)) continue;
                    float ww = std::exp(-0.5f * (k / 3.f) * (k / 3.f));
                    a += y[q] * ww; w += ww;
                }
                o[j] = a / w;
            }
            y.swap(o);
        }
        // ends fixed where they meet an earlier road
        auto fixEnd = [&](int end, float target) {
            float delta = target - (end == 0 ? y.front() : y.back());
            for (size_t j = 0; j < N; ++j) {
                float dd = end == 0 ? s[j] : s.back() - s[j];
                y[j] += delta * (1.f - sstep(0.f, 160.f, dd));
            }
        };
        if (p.joinA >= 0 && p.joinA < int(r)) fixEnd(0, profileAt(protos[p.joinA], p.pts.front().x, p.pts.front().z));
        if (p.joinB >= 0 && p.joinB < int(r)) fixEnd(1, profileAt(protos[p.joinB], p.pts.back().x, p.pts.back().z));
        // bridges: decks clear the water
        std::vector<std::pair<float, float>> lifts;   // (s, required deck height)
        for (size_t j = 0; j + 1 < N; ++j) {
            int ci = int(std::lround((p.pts[j].x - M.x0) / cell)), ck = int(std::lround((p.pts[j].z - M.z0) / cell));
            if (ci < 0 || ck < 0 || ci >= n || ck >= n || R.riverW[R.id(ci, ck)] <= 0) continue;
            // the exact crossing with a river polyline
            for (const River& Rv : M.rivers) {
                if (Rv.dry) continue;
                for (size_t q = 0; q + 1 < Rv.pts.size(); ++q) {
                    const RiverPt& a = Rv.pts[q];
                    const RiverPt& b = Rv.pts[q + 1];
                    if (std::fabs(a.x - p.pts[j].x) > 60.f || std::fabs(a.z - p.pts[j].z) > 60.f) continue;
                    // segment intersection
                    float rx = p.pts[j + 1].x - p.pts[j].x, rz = p.pts[j + 1].z - p.pts[j].z;
                    float sx2 = b.x - a.x, sz2 = b.z - a.z;
                    float den = rx * sz2 - rz * sx2;
                    if (std::fabs(den) < 1e-9f) continue;
                    float qx = a.x - p.pts[j].x, qz = a.z - p.pts[j].z;
                    float tt = (qx * sz2 - qz * sx2) / den, uu = (qx * rz - qz * rx) / den;
                    if (tt < 0 || tt > 1 || uu < 0 || uu > 1) continue;
                    float level = lerpf(a.level, b.level, uu), half = lerpf(a.half, b.half, uu);
                    if (half < 0.6f) continue;
                    float bx = p.pts[j].x + rx * tt, bz = p.pts[j].z + rz * tt;
                    bool dup = false;
                    for (const Bridge& o : bridges) dup |= std::hypot(o.x - bx, o.z - bz) < 15.f;
                    if (dup) continue;
                    float clear = level + 2.6f + 0.06f * half * 2;
                    lifts.push_back({lerpf(s[j], s[j + 1], tt), clear});
                    float rl = std::max(1e-3f, std::hypot(rx, rz));
                    bridges.push_back({bx, bz, 0.f, level, 2 * (half + 2.f + 0.45f * half) + 8.f, 2 * half, rx / rl, rz / rl});
                }
            }
        }
        // lake shores: the road stays a little above the water
        for (size_t j = 0; j < N; ++j) {
            int ci = int(std::lround((p.pts[j].x - M.x0) / cell)), ck = int(std::lround((p.pts[j].z - M.z0) / cell));
            float lv = -1e9f;
            for (int dk = -3; dk <= 3; ++dk)
                for (int di = -3; di <= 3; ++di) {
                    int a2 = ci + di, b2 = ck + dk;
                    if (a2 < 0 || b2 < 0 || a2 >= n || b2 >= n) continue;
                    int l = M.lakeId[R.id(a2, b2)];
                    if (l >= 0 && !M.lakes[l].playa) lv = std::max(lv, M.lakes[l].level);
                }
            // only a lake at the road's own level can lap at it (not a tarn up the hillside)
            float ground = M.height(p.pts[j].x, p.pts[j].z);
            if (lv > -1e8f && y[j] < lv + 1.2f && lv < ground + 3.f) lifts.push_back({s[j], lv + 1.2f});
        }
        if (std::getenv("WMAP_PROFILE"))
            for (auto [s0, need] : lifts)
                if (need > y[std::min(N - 1, size_t(s0 / 5.f))] + 30.f) std::printf("    road %zu lift %.0f at s %.0f (y %.0f)\n", r, need, s0, y[std::min(N - 1, size_t(s0 / 5.f))]);
        if (std::getenv("WMAP_PROFILE") && (p.joinA >= 0 || p.joinB >= 0))
            std::printf("    road %zu joins %d/%d ends y %.0f/%.0f ground %.0f/%.0f\n", r, p.joinA, p.joinB, y.front(), y.back(), M.height(p.pts.front().x, p.pts.front().z), M.height(p.pts.back().x, p.pts.back().z));
        for (auto [s0, need] : lifts)
            for (size_t j = 0; j < N; ++j) y[j] = std::max(y[j], need - 0.035f * std::max(0.f, std::fabs(s[j] - s0) - 6.f));
        // grade limit (forwards and backwards)
        const float gm = p.cls == 0 ? 0.095f : 0.13f;
        for (int pass = 0; pass < 2; ++pass) {
            for (size_t j = 1; j < N; ++j) {
                float ds = s[j] - s[j - 1];
                y[j] = std::clamp(y[j], y[j - 1] - gm * ds, y[j - 1] + gm * ds);
            }
            for (long j = long(N) - 2; j >= 0; --j) {
                float ds = s[j + 1] - s[j];
                y[j] = std::clamp(y[j], y[j + 1] - gm * ds, y[j + 1] + gm * ds);
            }
        }
        // the road never floats far off the land or digs far into it: where the grade limit
        // can't be met in the ground the road gets steeper instead (then a light smooth)
        {
            std::vector<float> g(N);
            for (size_t j = 0; j < N; ++j) g[j] = M.height(p.pts[j].x, p.pts[j].z);
            for (size_t j = 0; j < N; ++j) {
                float env = -1e9f;   // what bridges and lake shores need here
                for (auto [s0, need] : lifts) env = std::max(env, need - 0.035f * std::max(0.f, std::fabs(s[j] - s0) - 6.f));
                y[j] = std::clamp(y[j], g[j] - 10.f, std::max(g[j] + 10.f, env));
            }
            for (int pass = 0; pass < 2; ++pass) {
                std::vector<float> o(y);
                for (size_t j = 2; j + 2 < N; ++j) o[j] = (y[j - 2] + 2 * y[j - 1] + 3 * y[j] + 2 * y[j + 1] + y[j + 2]) / 9.f;
                y.swap(o);
            }
        }
        for (size_t j = 0; j < N; ++j) p.pts[j].y = y[j];
    }
    // bridge decks from the finished profiles; a bridge spans as far as the road is well
    // above the ground (a gorge, not just the stream)
    for (Bridge& b : bridges) {
        float best = 1e9f;
        int pr = -1;
        size_t bseg = 0;
        for (size_t q = 0; q < protos.size(); ++q) {
            size_t seg;
            float t;
            float d = nearestOn(protos[q].pts, b.x, b.z, seg, t);
            if (d < best) { best = d; b.roadY = lerpf(protos[q].pts[seg].y, protos[q].pts[seg + 1].y, t); pr = int(q); bseg = seg; }
        }
        if (pr < 0) continue;
        // a gorge: walk out to the rim on each side (where the ground stops rising); if both
        // rims stand well above the water within reach, the bridge spans rim to rim at rim height
        const auto& P = protos[pr].pts;
        float rim[2] = {0, 0}, at[2] = {0, 0};
        bool ok = true;
        for (int side = 0; side < 2; ++side) {
            int dir = side == 0 ? -1 : 1;
            float best = -1e9f, acc = 0;
            for (long j = long(bseg) + (dir > 0 ? 1 : 0), prev = -1; j >= 0 && j < long(P.size()); prev = j, j += dir) {
                if (prev >= 0) acc += std::hypot(P[j].x - P[prev].x, P[j].z - P[prev].z);
                if (acc > 400.f) { ok = false; break; }
                float g = M.height(P[j].x, P[j].z);
                if (g > best) { best = g; at[side] = acc; }
                else if (g < best - 2.f && acc > 20.f) break;
            }
            rim[side] = best;
        }
        float rimY = std::min(rim[0], rim[1]);
        if (ok && rimY - b.level > 15.f) {
            b.roadY = rimY + 0.5f;
            b.span = at[0] + at[1] + 10.f;
        }
        b.roadY = std::max(b.roadY, b.level + 2.6f);
    }
    M.bridges = bridges;

    // ---------------------------------------------------------------- the network graph
    // split every road where another branches off it, then join ends into nodes
    std::vector<std::vector<std::pair<size_t, float>>> cuts(protos.size());
    for (const Split& s : splits) cuts[s.road].push_back({s.seg, s.t});
    M.roads.clear();
    M.nodes.clear();
    auto nodeAt = [&](float x, float z, float y) {
        for (size_t i = 0; i < M.nodes.size(); ++i)
            if (std::hypot(M.nodes[i].x - x, M.nodes[i].z - z) < 6.f) return int(i);
        Node nd;
        nd.x = x; nd.z = z; nd.y = y;
        M.nodes.push_back(nd);
        return int(M.nodes.size() - 1);
    };
    for (size_t r = 0; r < protos.size(); ++r) {
        const Proto& p = protos[r];
        if (p.pts.size() < 2) continue;
        auto cs = cuts[r];
        std::sort(cs.begin(), cs.end(), [](auto& a, auto& b) { return a.first < b.first || (a.first == b.first && a.second < b.second); });
        std::vector<RoadPt> cur;
        cur.push_back(p.pts[0]);
        size_t ci = 0;
        auto emit = [&]() {
            if (cur.size() < 2 || polyLen(cur) < 3.f) return;
            Road rd;
            rd.pts = cur;
            rd.cls = p.cls;
            rd.length = polyLen(cur);
            M.roads.push_back(rd);
        };
        for (size_t j = 0; j + 1 < p.pts.size(); ++j) {
            while (ci < cs.size() && cs[ci].first == j) {
                const auto& a = p.pts[j];
                const auto& b = p.pts[j + 1];
                float t = cs[ci].second;
                RoadPt m{lerpf(a.x, b.x, t), lerpf(a.z, b.z, t), lerpf(a.y, b.y, t)};
                cur.push_back(m);
                emit();
                cur.clear();
                cur.push_back(m);
                ++ci;
            }
            cur.push_back(p.pts[j + 1]);
        }
        emit();
    }
    for (size_t r = 0; r < M.roads.size(); ++r) {
        Road& rd = M.roads[r];
        rd.a = nodeAt(rd.pts.front().x, rd.pts.front().z, rd.pts.front().y);
        rd.b = nodeAt(rd.pts.back().x, rd.pts.back().z, rd.pts.back().y);
        M.nodes[rd.a].roads.push_back(int(r));
        M.nodes[rd.b].roads.push_back(int(r));
    }
    auto easeNodes = [&]() {
    // every road meeting at a node meets at one height: the mean of their ends, each road
        // eased onto it over its last couple of hundred metres
        for (size_t i = 0; i < M.nodes.size(); ++i) {
            Node& nd = M.nodes[i];
            double sum = 0;
            int cnt = 0;
            for (int r : nd.roads) {
                const Road& rd = M.roads[r];
                if (rd.a == int(i)) { sum += rd.pts.front().y; ++cnt; }
                if (rd.b == int(i)) { sum += rd.pts.back().y; ++cnt; }
            }
            if (!cnt) continue;
            // ends far above or below the rest meet across a cliff, not at a junction: detach them
            std::vector<float> ys;
            for (int r : nd.roads) {
                const Road& rd = M.roads[r];
                if (rd.a == int(i)) ys.push_back(rd.pts.front().y);
                if (rd.b == int(i)) ys.push_back(rd.pts.back().y);
            }
            std::sort(ys.begin(), ys.end());
            float med = ys[ys.size() / 2];
            sum = 0; cnt = 0;
            std::vector<int> keep;
            for (int r : nd.roads) {
                Road& rd = M.roads[r];
                bool ok = true;
                for (int end = 0; end < 2; ++end) {
                    if ((end == 0 ? rd.a : rd.b) != int(i)) continue;
                    float ey = end == 0 ? rd.pts.front().y : rd.pts.back().y;
                    if (std::fabs(ey - med) > 15.f) {
                        Node lone;
                        lone.x = nd.x; lone.z = nd.z; lone.y = ey;
                        lone.roads.push_back(r);
                        (end == 0 ? rd.a : rd.b) = int(M.nodes.size());
                        M.nodes.push_back(lone);
                        ok = false;
                    } else { sum += ey; ++cnt; }
                }
                if (ok || rd.a == int(i) || rd.b == int(i)) keep.push_back(r);
            }
            Node& nd2 = M.nodes[i];   // (push_back may have moved it)
            nd2.roads = keep;
            if (!cnt) continue;
            nd2.y = float(sum / cnt);
            for (int r : nd2.roads) {
                Road& rd = M.roads[r];
                for (int end = 0; end < 2; ++end) {
                    if ((end == 0 ? rd.a : rd.b) != int(i)) continue;
                    float delta = nd2.y - (end == 0 ? rd.pts.front().y : rd.pts.back().y);
                    if (std::fabs(delta) < 0.01f) continue;
                    float span = std::clamp(std::fabs(delta) / 0.06f, 120.f, std::max(120.f, rd.length * 0.5f));
                    float acc = 0;
                    int N = int(rd.pts.size());
                    for (int q = 0; q < N; ++q) {
                        int qi = end == 0 ? q : N - 1 - q;
                        if (q > 0) { int qp = end == 0 ? qi - 1 : qi + 1; acc += std::hypot(rd.pts[qi].x - rd.pts[qp].x, rd.pts[qi].z - rd.pts[qp].z); }
                        if (acc > span) break;
                        float f = 1.f - sstep(0.f, span, acc);
                        rd.pts[qi].y += delta * f;
                    }
                }
            }
        }
    };
    // the final word on every profile: within 10 m of the land, except bridge decks (and the
    // ramps up to them); then the junctions once more (now only small differences)
    auto clampToLand = [&]() {
        for (Road& rd : M.roads) {
            const size_t N = rd.pts.size();
            std::vector<float> y(N), s(N, 0.f), lo(N), hi(N), dk(N);
            for (size_t j = 0; j < N; ++j) {
                y[j] = rd.pts[j].y;
                if (j) s[j] = s[j - 1] + std::hypot(rd.pts[j].x - rd.pts[j - 1].x, rd.pts[j].z - rd.pts[j - 1].z);
            }
            // this road's own bridges, by their position along it
            std::vector<std::pair<float, const Bridge*>> mine;
            for (const Bridge& b : M.bridges) {
                size_t seg;
                float t;
                if (nearestOn(rd.pts, b.x, b.z, seg, t) < 3.f) mine.push_back({lerpf(s[seg], s[seg + 1], t), &b});
            }
            for (size_t j = 0; j < N; ++j) {
                const RoadPt& p = rd.pts[j];
                float g = M.height(p.x, p.z), env = -1e9f, deck = -1e9f;
                for (auto [sb, b] : mine) {
                    float ramp = b->roadY - 0.035f * std::max(0.f, std::fabs(s[j] - sb) - b->span * 0.5f);   // up the ramp onto the deck
                    env = std::max(env, ramp);
                    deck = std::max(deck, ramp);
                }
                lo[j] = g - 25.f;
                hi[j] = std::max(g + 25.f, env);
                dk[j] = deck;
                y[j] = std::clamp(y[j], g - 10.f, std::max(g + 10.f, env));
                if (deck > -1e8f) y[j] = std::max(y[j], deck);
            }
            // then the grade cap again, allowed to cut / fill up to 25 m to keep it (beyond that
            // the road follows the land, steeper)
            const float gm = rd.cls == 0 ? 0.11f : 0.15f;
            for (int pass = 0; pass < 2; ++pass) {
                for (size_t j = 1; j < N; ++j) {
                    float ds = s[j] - s[j - 1];
                    y[j] = std::clamp(std::clamp(y[j], y[j - 1] - gm * ds, y[j - 1] + gm * ds), lo[j], hi[j]);
                }
                for (long j = long(N) - 2; j >= 0; --j) {
                    float ds = s[j + 1] - s[j];
                    y[j] = std::clamp(std::clamp(y[j], y[j + 1] - gm * ds, y[j + 1] + gm * ds), lo[j], hi[j]);
                }
            }
            for (size_t j = 0; j < N; ++j) if (dk[j] > -1e8f) y[j] = std::max(y[j], dk[j]);
            for (int pass = 0; pass < 2; ++pass) {
                std::vector<float> o(y);
                for (size_t j = 2; j + 2 < N; ++j) o[j] = (y[j - 2] + 2 * y[j - 1] + 3 * y[j] + 2 * y[j + 1] + y[j + 2]) / 9.f;
                y.swap(o);
            }
            for (size_t j = 0; j < N; ++j) rd.pts[j].y = y[j];
        }
    };
    M.bridges = bridges;
    easeNodes();
    clampToLand();
    easeNodes();
    for (size_t t = 0; t < M.towns.size(); ++t) {
        Town& T = M.towns[t];
        float best = 1e9f;
        int bn = -1;
        for (size_t i = 0; i < M.nodes.size(); ++i) {
            float d = std::hypot(M.nodes[i].x - T.x, M.nodes[i].z - T.z);
            if (d < best) { best = d; bn = int(i); }
        }
        if (bn >= 0 && best < 120.f && M.nodes[bn].town < 0) { M.nodes[bn].town = int(t); T.y = M.nodes[bn].y; }
    }

    // ---------------------------------------------------------------- cut and fill
    // the land is shaped to the road at grid scale (the fine formation is analytic, at sample
    // time): embankments and cuttings at a 1:2 batter, nothing under bridges
    {
        const size_t NN = size_t(n) * n;
        std::vector<float> nd(NN, 1e9f), ny(NN, 0.f);
        const float reach = 40.f;
        for (const Road& rd : M.roads)
            for (size_t j = 0; j < rd.pts.size(); j += 2) {
                const RoadPt& p = rd.pts[j];
                int ci = int(std::lround((p.x - M.x0) / cell)), ck = int(std::lround((p.z - M.z0) / cell));
                int r = int(std::ceil(reach / cell));
                for (int dk = -r; dk <= r; ++dk)
                    for (int di = -r; di <= r; ++di) {
                        int a = ci + di, b = ck + dk;
                        if (a < 0 || b < 0 || a >= n || b >= n) continue;
                        float d = std::hypot(X(a) - p.x, Z(b) - p.z);
                        size_t c = R.id(a, b);
                        if (d < nd[c]) { nd[c] = d; ny[c] = p.y; }
                    }
            }
        // only the grid points right by the road are pre-shaped (so the coarse surface
        // doesn't fight the fine formation); it fades out well inside the reach
        for (size_t c = 0; c < NN; ++c) {
            if (nd[c] > reach || R.lake[c]) continue;
            float x = X(int(c % n)), z = Z(int(c / n));
            bool underBridge = false;
            for (const Bridge& b : M.bridges) underBridge |= std::hypot(b.x - x, b.z - z) < b.span * 0.5f + 10.f;
            if (underBridge || R.riverW[c] > 0) continue;
            float w0 = HW + 3.f;
            float lim = std::max(0.f, nd[c] - w0) * 0.7f;
            float target = ny[c] - 0.3f;
            float shaped = target + std::clamp(M.h[c] - target, -lim, lim);
            M.h[c] = lerpf(shaped, M.h[c], sstep(12.f, 34.f, nd[c]));
        }
    }
    // culverts: a stream crossing a road with no bridge runs under it, below the formation
    M.index();
    for (River& Rv : M.rivers) {
        bool changed = false;
        for (RiverPt& p : Rv.pts) {
            float px, pz, py;
            float d = M.roadNearest(p.x, p.z, px, pz, py);
            if (d > HW + p.half + 6.f) continue;
            bool bridged = false;
            for (const Bridge& b : M.bridgesNear(p.x, p.z, 40.f)) bridged |= std::hypot(b.x - p.x, b.z - p.z) < b.span * 0.5f + 6.f;
            if (bridged) continue;
            float cap = py - 1.2f - p.depth;
            if (p.level > cap) { p.level = cap; changed = true; }
        }
        if (changed)
            for (size_t j = 1; j < Rv.pts.size(); ++j) Rv.pts[j].level = std::min(Rv.pts[j].level, Rv.pts[j - 1].level - 0.001f);
    }
    float km = 0;
    for (const Road& rd : M.roads) km += rd.length / 1000.f;
    M.stats.roads = int(M.roads.size());
    M.stats.roadKm = km;
    M.stats.bridges = int(M.bridges.size());
}

// ==================================================================== loops on the network
std::vector<RoadPt> Map::loop(float targetKm, uint32_t seed, float sx, float sz, std::string* name) const {
    std::vector<RoadPt> out;
    if (nodes.empty() || roads.empty()) return out;
    const float L = targetKm * 1000.f;
    auto dijkstra = [&](int src, const std::vector<float>& pen, std::vector<float>& dist, std::vector<int>& via) {
        dist.assign(nodes.size(), 1e30f);
        via.assign(nodes.size(), -1);
        using QE = std::pair<float, int>;
        std::priority_queue<QE, std::vector<QE>, std::greater<QE>> pq;
        dist[src] = 0;
        pq.push({0, src});
        while (!pq.empty()) {
            auto [d, u] = pq.top();
            pq.pop();
            if (d > dist[u]) continue;
            for (int r : nodes[u].roads) {
                const Road& rd = roads[r];
                int v = rd.a == u ? rd.b : rd.a;
                float nd = d + rd.length * pen[r];
                if (nd < dist[v]) { dist[v] = nd; via[v] = r; pq.push({nd, v}); }
            }
        }
    };
    auto pathTo = [&](int src, int dst, const std::vector<int>& via) {
        std::vector<int> rs;
        int u = dst;
        while (u != src && via[u] >= 0) {
            int r = via[u];
            rs.push_back(r);
            u = roads[r].a == u ? roads[r].b : roads[r].a;
        }
        std::reverse(rs.begin(), rs.end());
        return u == src ? rs : std::vector<int>{};
    };
    // starts: the towns and junctions nearest the requested point
    std::vector<std::pair<float, int>> starts;
    for (size_t i = 0; i < nodes.size(); ++i)
        if (!nodes[i].roads.empty())   // through-places: a dead end would start the loop with a U-turn
            starts.push_back({std::hypot(nodes[i].x - sx, nodes[i].z - sz) * (nodes[i].town >= 0 ? 0.7f : 1.f) * (nodes[i].roads.size() < 2 ? 4.f : 1.f), int(i)});
    if (starts.empty()) return out;
    std::sort(starts.begin(), starts.end());
    if (starts.size() > 8) starts.resize(8);
    std::mt19937 rng(seed * 2654435761u + 99u);
    std::vector<int> bestRoads;
    float bestScore = 1e30f;
    int A = starts[0].second;
    for (auto [sd, a] : starts) {
        std::vector<float> pen(roads.size(), 1.f), d1;
        std::vector<int> v1;
        dijkstra(a, pen, d1, v1);
        std::vector<int> cand;
        for (size_t i = 0; i < nodes.size(); ++i)
            if (int(i) != a && d1[i] < 1e29f && d1[i] > 0.15f * L && d1[i] < 0.6f * L) cand.push_back(int(i));
        std::shuffle(cand.begin(), cand.end(), rng);
        if (cand.size() > 16) cand.resize(16);
        for (int B : cand) {
            auto p1 = pathTo(a, B, v1);
            if (p1.empty()) continue;
            std::vector<float> pen2(roads.size(), 1.f);
            for (int r : p1) pen2[r] = 6.f;
            std::vector<float> d2;
            std::vector<int> v2;
            dijkstra(B, pen2, d2, v2);
            auto p2 = pathTo(B, a, v2);
            if (p2.empty()) continue;
            float len = 0, overlap = 0;
            std::set<int> s1(p1.begin(), p1.end());
            for (int r : p1) len += roads[r].length;
            for (int r : p2) { len += roads[r].length; if (s1.count(r)) overlap += 2 * roads[r].length; }
            // a lollipop (a stem ridden both ways to a loop) is fine; a pure out-and-back is not
            float score = std::fabs(len - L) / L + 1.5f * overlap / len + 0.15f * sd / 5000.f;
            if (overlap > 0.97f * len) score += 2.f;
            if (score < bestScore) {
                bestScore = score;
                A = a;
                bestRoads = p1;
                bestRoads.insert(bestRoads.end(), p2.begin(), p2.end());
            }
        }
    }
    if (bestRoads.empty()) return out;
    // stitch the polylines in travel order
    int u = A;
    std::vector<RoadPt> pts;
    for (int r : bestRoads) {
        const Road& rd = roads[r];
        bool fwd = rd.a == u;
        if (fwd) for (size_t j = 0; j < rd.pts.size(); ++j) { if (!pts.empty() && j == 0) continue; pts.push_back(rd.pts[j]); }
        else for (size_t j = rd.pts.size(); j-- > 0;) { if (!pts.empty() && j + 1 == rd.pts.size()) continue; pts.push_back(rd.pts[j]); }
        u = fwd ? rd.b : rd.a;
    }
    // round the corners at junctions a little and resample
    chaikin(pts, 1);
    out = resample(pts, 4.f);
    if (out.size() > 2 && std::hypot(out.front().x - out.back().x, out.front().z - out.back().z) < 1.f) out.pop_back();
    if (name) {
        int ta = nodes[A].town;
        std::string nm = ta >= 0 ? towns[ta].name : "the crossroads";
        *name = "Loop from " + nm;
    }
    return out;
}

}  // namespace wmap
