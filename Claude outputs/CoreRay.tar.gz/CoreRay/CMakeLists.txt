cmake_minimum_required(VERSION 3.21)
project(CoreRay VERSION 0.1.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
    set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
endif()

option(CORERAY_WITH_BLE "Build with SimpleBLE (real trainer / HRM support)" ON)
option(CORERAY_TESTS "Build protocol parser tests" ON)

include(FetchContent)
set(FETCHCONTENT_QUIET OFF)

# ---------------------------------------------------------------- raylib
set(BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(BUILD_GAMES OFF CACHE BOOL "" FORCE)
set(CUSTOMIZE_BUILD OFF CACHE BOOL "" FORCE)
FetchContent_Declare(raylib
    GIT_REPOSITORY https://github.com/raysan5/raylib.git
    GIT_TAG 5.5
    GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(raylib)

# ---------------------------------------------------------------- SimpleBLE
if(CORERAY_WITH_BLE)
    set(SIMPLEBLE_INSTALL OFF CACHE BOOL "" FORCE)
    set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
    FetchContent_Declare(simpleble
        GIT_REPOSITORY https://github.com/simpleble/simpleble.git
        GIT_TAG v1.4.0
        GIT_SHALLOW TRUE
        SOURCE_SUBDIR simpleble)
    FetchContent_MakeAvailable(simpleble)
endif()

# ---------------------------------------------------------------- app
# Pure core (no raylib / BLE): engine, physics, workouts, tests, simulator, export
add_library(coreray_core STATIC
    src/Protocol.cpp
    src/core/Physics.cpp
    src/core/Metrics.cpp
    src/core/Workout.cpp
    src/core/Sim.cpp
    src/core/Engine.cpp
    src/core/Export.cpp
)
target_include_directories(coreray_core PUBLIC src)
target_compile_features(coreray_core PUBLIC cxx_std_17)

add_executable(CoreRay
    src/main.cpp
    src/App.cpp
    src/HomeUi.cpp
    src/RideUi.cpp
    src/SummaryUi.cpp
    src/Audio.cpp
    src/Ble.cpp
    src/Course.cpp
    src/Renderer.cpp
    src/Store.cpp
    src/Ui.cpp
)
target_link_libraries(CoreRay PRIVATE coreray_core raylib)
if(CORERAY_WITH_BLE)
    target_link_libraries(CoreRay PRIVATE simpleble::simpleble)
    target_compile_definitions(CoreRay PRIVATE CORERAY_BLE=1)
endif()

# SQLite is only used to import your profile + workouts from CoreKick (optional)
find_package(SQLite3 QUIET)
if(SQLite3_FOUND)
    target_link_libraries(CoreRay PRIVATE SQLite::SQLite3)
    target_compile_definitions(CoreRay PRIVATE CORERAY_SQLITE=1)
endif()

if(APPLE)
    target_link_libraries(CoreRay PRIVATE "-framework IOKit" "-framework Cocoa" "-framework OpenGL"
                                          "-framework CoreBluetooth" "-framework Foundation")
    # Embed an Info.plist in the plain executable so macOS shows the Bluetooth
    # permission prompt with a proper description (works when run from Terminal).
    target_link_options(CoreRay PRIVATE
        "LINKER:-sectcreate,__TEXT,__info_plist,${CMAKE_CURRENT_SOURCE_DIR}/macos/Info.plist")
endif()

if(MSVC)
    target_compile_options(CoreRay PRIVATE /W3)
else()
    target_compile_options(CoreRay PRIVATE -Wall -Wextra -Wno-missing-field-initializers -Wno-unused-parameter)
endif()

# Copy assets next to the binary
add_custom_command(TARGET CoreRay POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_directory
            ${CMAKE_CURRENT_SOURCE_DIR}/assets $<TARGET_FILE_DIR:CoreRay>/assets)

if(CORERAY_TESTS)
    enable_testing()
    add_executable(protocol_tests tests/protocol_tests.cpp)
    target_link_libraries(protocol_tests PRIVATE coreray_core)
    add_test(NAME protocol_tests COMMAND protocol_tests)
    add_executable(core_tests tests/core_tests.cpp)
    target_link_libraries(core_tests PRIVATE coreray_core)
    add_test(NAME core_tests COMMAND core_tests)
endif()
