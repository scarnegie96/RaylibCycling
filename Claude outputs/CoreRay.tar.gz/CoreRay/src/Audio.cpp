#include "Audio.h"

#include <cmath>
#include <vector>

#include "raylib.h"

namespace sfx {

static Sound g_sounds[COUNT];
static bool g_ok = false;

static Sound tone(std::vector<std::pair<float, float>> notes, float gap = 0.03f) {
    const int rate = 44100;
    std::vector<short> pcm;
    for (auto [freq, dur] : notes) {
        int n = int(dur * rate);
        for (int i = 0; i < n; ++i) {
            float t = float(i) / rate;
            float env = std::min(1.f, t / 0.008f) * std::exp(-t * 5.5f);
            float s = std::sin(2 * PI * freq * t) * 0.6f + std::sin(2 * PI * freq * 2 * t) * 0.15f;
            pcm.push_back(short(s * env * 26000));
        }
        pcm.insert(pcm.end(), int(gap * rate), 0);
    }
    Wave w{};
    w.frameCount = (unsigned)pcm.size();
    w.sampleRate = rate;
    w.sampleSize = 16;
    w.channels = 1;
    w.data = pcm.data();
    return LoadSoundFromWave(w);  // copies the data
}

void init() {
    InitAudioDevice();
    if (!IsAudioDeviceReady()) return;
    g_sounds[StepChange] = tone({{880, 0.12f}, {1320, 0.18f}});
    g_sounds[Lap] = tone({{660, 0.1f}, {880, 0.1f}, {1100, 0.22f}});
    g_sounds[HrHigh] = tone({{1200, 0.12f}, {900, 0.12f}, {700, 0.2f}});
    g_sounds[HrLow] = tone({{500, 0.12f}, {700, 0.12f}, {900, 0.2f}});
    g_sounds[Countdown] = tone({{1000, 0.08f}});
    g_sounds[Done] = tone({{523, 0.14f}, {659, 0.14f}, {784, 0.14f}, {1046, 0.4f}});
    g_ok = true;
}

void shutdown() {
    if (!g_ok) return;
    for (auto& s : g_sounds) UnloadSound(s);
    CloseAudioDevice();
    g_ok = false;
}

void play(Kind k) { if (g_ok) PlaySound(g_sounds[k]); }
void setVolume(float v) { if (g_ok) SetMasterVolume(v); }

}  // namespace sfx
