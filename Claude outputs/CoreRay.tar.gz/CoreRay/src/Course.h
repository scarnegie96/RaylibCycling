#pragma once
// Procedural closed-loop course: road centreline, elevation, grade, and the terrain
// height field that the road is carved into.
#include <cstdint>
#include <string>
#include <vector>

struct V3 { float x = 0, y = 0, z = 0; };

struct CoursePoint {
    V3 pos;            // centreline at road surface
    float heading;     // yaw (radians), 0 = +Z
    float dist;        // metres from start
    float grade;       // fraction (0.05 = 5 %)
};

class Course {
public:
    void generate(int seed);

    float length() const { return length_; }
    std::string name() const { return name_; }
    const std::vector<CoursePoint>& points() const { return pts_; }

    // Interpolated sample at distance (wraps around the loop)
    CoursePoint at(double dist) const;
    float gradeAt(double dist) const { return at(dist).grade; }
    float elevationAt(double dist) const { return at(dist).pos.y; }
    float minElevation() const { return minEle_; }
    float maxElevation() const { return maxEle_; }
    float totalAscent() const { return ascent_; }

    // Terrain
    float terrainHeight(float x, float z) const;   // final height incl. road carving
    float roadDistance(float x, float z, float* roadY = nullptr) const;
    float waterLevel() const { return water_; }
    float extent() const { return extent_; }       // half-size of the world square
    float roadHalfWidth() const { return 3.6f; }

private:
    float baseNoise(float x, float z) const;
    float regionalHeight(float x, float z, float* coarseDist) const;

    std::vector<CoursePoint> pts_;
    std::vector<int> coarse_;                        // indices of sparse samples for IDW
    std::vector<std::vector<int>> grid_;             // spatial hash for nearest road lookup
    float gridMin_ = 0, gridCell_ = 40;
    int gridN_ = 0;
    float length_ = 0, minEle_ = 0, maxEle_ = 0, ascent_ = 0, water_ = 0, extent_ = 3000;
    uint32_t seed_ = 1;
    std::string name_;
};

// value-noise helpers shared with the renderer
float hash2(int x, int y, uint32_t seed);
float vnoise(float x, float y, uint32_t seed);
float fbm(float x, float y, int oct, uint32_t seed);
