// Ride summary: NP / IF / TSS / VI, energy, zones, power bests, splits, charts, test result, exports.
#include <algorithm>
#include <cmath>
#include <cstdio>

#include "App.h"
#include "core/Metrics.h"
#include "raylib.h"

using namespace ui;

static std::string fmt(const char* f, double v) { char b[64]; std::snprintf(b, sizeof b, f, v); return b; }

static std::string durLabel(int s) {
    if (s < 60) return std::to_string(s) + "s";
    if (s < 3600) return std::to_string(s / 60) + "m";
    return fmt("%.1fh", s / 3600.0);
}

void App::drawSummary() {
    const float W = float(GetScreenWidth()), H = float(GetScreenHeight());
    const RideSummary& s = summary_;
    const bool metric = prof_.metric;
    DrawRectangle(0, 0, int(W), int(H), Color{0, 0, 0, 120});
    Rectangle r{W * 0.04f, H * 0.04f, W * 0.92f, H * 0.92f};
    panel(r, Color{12, 14, 22, 246});
    float x = r.x + 26, y = r.y + 18, w = r.width - 52;
    text("Ride summary", x, y, F::Title, TEXT);
    text(summaryName_ == course_.name() ? summaryName_ : summaryName_ + "  \xC2\xB7  " + course_.name(), x + 260, y + 10, F::Body, DIM);
    if (newPb_) textRight("New personal best - saved as your ghost", x + w, y + 10, F::Body, GOOD);
    y += 54;

    // metric grid
    struct Item { const char* l; std::string v; };
    std::vector<Item> items = {
        {"TIME", fmtTime(s.elapsedS)},
        {"DISTANCE", fmtDist(s.distanceM, metric)},
        {"CLIMBING", fmt(metric ? "%.0f m" : "%.0f ft", metric ? s.elevationGainM : s.elevationGainM * 3.28084)},
        {"AVG SPEED", fmtSpeed(s.avgSpeedMps, metric) + (metric ? " km/h" : " mph")},
        {"AVG POWER", fmt("%.0f W", s.avgPower)},
        {"NORMALIZED", fmt("%.0f W", s.np)},
        {"MAX POWER", fmt("%.0f W", s.maxPower)},
        {"IF / VI", fmt("%.2f", s.intensityFactor) + " / " + fmt("%.2f", s.vi)},
        {"TSS", fmt("%.0f", s.tss)},
        {"WORK", fmt("%.0f kJ", s.workKj)},
        {"CALORIES", fmt("%.0f kcal", s.caloriesKcal) + (s.caloriesHr > 0 ? fmt(" (HR %.0f)", s.caloriesHr) : "")},
        {"AVG / MAX HR", s.avgHr ? fmt("%.0f", *s.avgHr) + " / " + fmt("%.0f", s.maxHr.value_or(0)) : "--"},
        {"AVG CADENCE", fmt("%.0f rpm", s.avgCadence)},
        {"W/KG (NP)", fmt("%.2f", s.np / prof_.weightKg)},
    };
    int cols = 7;
    float cw = (w - (cols - 1) * 10) / cols, ch = 64;
    for (size_t i = 0; i < items.size(); ++i) {
        float ix = x + (i % cols) * (cw + 10), iy = y + (i / cols) * (ch + 10);
        panel({ix, iy, cw, ch}, Color{26, 30, 42, 225});
        text(items[i].l, ix + 12, iy + 7, F::Small, DIM, 12);
        text(items[i].v, ix + 12, iy + 25, F::Title, TEXT, std::min(28.f, cw / std::max(4.f, float(items[i].v.size())) * 1.7f));
    }
    y += 2 * (ch + 10) + 6;

    // test result
    if (s.test) {
        Rectangle tr{x, y, w, 58};
        panel(tr, Color{255, 92, 56, 40});
        std::string msg = std::string(s.test->valid ? "" : "(incomplete) ") + s.test->detail + "  \xE2\x86\x92  FTP " + fmt("%.0f W", s.test->ftp);
        text(msg, tr.x + 16, tr.y + 17, F::Body, TEXT, 20);
        if (!ftpApplied_ && s.test->ftp > 0) {
            if (button({tr.x + tr.width - 220, tr.y + 9, 204, 40}, "Set FTP to " + fmt("%.0f W", s.test->ftp), true)) {
                prof_.ftp = s.test->ftp;
                store::save(prof_, prefs_);
                ftpApplied_ = true;
                toast("FTP updated", GOOD);
            }
        } else if (ftpApplied_) textRight("FTP updated", tr.x + tr.width - 16, tr.y + 19, F::Body, GOOD);
        y += 68;
    }

    float bottomH = 64;
    float avail = r.y + r.height - y - bottomH;
    float leftW = w * 0.62f;
    // charts
    float chH = avail * 0.58f;
    Rectangle pc{x, y, leftW, chH};
    panel(pc, Color{20, 24, 34, 220});
    text("POWER  \xC2\xB7  HEART RATE  \xC2\xB7  CADENCE", pc.x + 12, pc.y + 6, F::Small, DIM, 12);
    Samples sm;
    sm.power = sumPower_; sm.hr = sumHr_; sm.cadence = sumCad_;
    sm.target.assign(sumPower_.size(), 0.f);
    powerChart({pc.x + 12, pc.y + 24, pc.width - 24, pc.height - 32}, sm, prof_.ftp, prof_.maxHr, std::max(60, int(sumPower_.size())), true, false);
    float y2 = y + chH + 10;
    float h2 = avail - chH - 10;
    Rectangle ec{x, y2, leftW / 2 - 5, h2};
    panel(ec, Color{20, 24, 34, 220});
    text("ELEVATION", ec.x + 12, ec.y + 6, F::Small, DIM, 12);
    if (!sumEle_.empty()) {
        float lo = *std::min_element(sumEle_.begin(), sumEle_.end()), hi = *std::max_element(sumEle_.begin(), sumEle_.end());
        seriesChart({ec.x + 12, ec.y + 24, ec.width - 24, ec.height - 32}, sumEle_, Color{180, 190, 210, 255}, lo - 5, std::max(hi, lo + 20) + 5, true);
    }
    Rectangle sc{x + leftW / 2 + 5, y2, leftW / 2 - 5, h2};
    panel(sc, Color{20, 24, 34, 220});
    text("SPEED", sc.x + 12, sc.y + 6, F::Small, DIM, 12);
    if (!sumSpeed_.empty()) {
        float hi = *std::max_element(sumSpeed_.begin(), sumSpeed_.end());
        seriesChart({sc.x + 12, sc.y + 24, sc.width - 24, sc.height - 32}, sumSpeed_, SKY, 0, std::max(hi, 5.f) * 1.1f, true);
    }

    // right column: zones, bests, splits
    float rx = x + leftW + 14, rw = w - leftW - 14;
    float ry = y;
    Rectangle zr{rx, ry, rw, avail * 0.36f};
    panel(zr, Color{20, 24, 34, 220});
    text("TIME IN POWER ZONES", zr.x + 12, zr.y + 6, F::Small, DIM, 12);
    {
        std::vector<std::string> zl;
        std::vector<Color> zc;
        for (int z = 0; z < 7; ++z) { zl.push_back("Z" + std::to_string(z + 1) + " " + metrics::ZONE_NAMES[z]); zc.push_back(zoneColor(z)); }
        zoneBars({zr.x + 12, zr.y + 24, zr.width - 24, zr.height - 30}, s.powerZoneS.data(), 7, zl, zc);
    }
    ry += zr.height + 10;
    if (!s.hrZoneS.empty() && s.avgHr) {
        Rectangle hz{rx, ry, rw, avail * 0.24f};
        panel(hz, Color{20, 24, 34, 220});
        text("TIME IN HEART-RATE ZONES", hz.x + 12, hz.y + 6, F::Small, DIM, 12);
        std::vector<std::string> zl;
        std::vector<Color> zc;
        auto zones = prof_.hrZones();
        for (auto& z : zones) { zl.push_back("Z" + std::to_string(z.zone) + " " + z.name); zc.push_back(hrZoneColor(z.zone, int(zones.size()))); }
        zoneBars({hz.x + 12, hz.y + 24, hz.width - 24, hz.height - 30}, s.hrZoneS.data(), int(s.hrZoneS.size()), zl, zc);
        ry += hz.height + 10;
    }
    Rectangle br{rx, ry, rw, y + avail - ry};
    panel(br, Color{20, 24, 34, 220});
    text("POWER BESTS", br.x + 12, br.y + 6, F::Small, DIM, 12);
    float bx = br.x + 12, by = br.y + 26;
    for (auto& [d, wv] : s.bests) {
        if (bx + 86 > br.x + br.width) { bx = br.x + 12; by += 44; }
        if (by + 40 > br.y + br.height) break;
        text(durLabel(d), bx, by, F::Small, DIM, 12);
        text(fmt("%.0f W", wv), bx, by + 14, F::Body, TEXT, 18);
        bx += 86;
    }
    int laps = 0;
    for (auto& sp : s.splits) if (sp.kind == "lap" || sp.kind == "route_lap") ++laps;
    if (laps && by + 70 < br.y + br.height) {
        by += 50;
        text("SPLITS", br.x + 12, by, F::Small, DIM, 12);
        by += 18;
        for (auto& sp : s.splits) {
            if (by + 20 > br.y + br.height) break;
            char b[160];
            std::snprintf(b, sizeof b, "%-12s %8s  %7s  %4.0f W  NP %3.0f%s", sp.name.c_str(), fmtTime(sp.durationS).c_str(), fmtDist(sp.distanceM, metric).c_str(),
                          sp.avgPower, sp.np, sp.avgHr ? fmt("  %3.0f bpm", *sp.avgHr).c_str() : "");
            text(b, br.x + 12, by, F::Small, TEXT, 14);
            by += 20;
        }
    }

    // bottom
    float fy = r.y + r.height - bottomH + 8;
    if (!savedDir_.empty()) text("Saved to " + savedDir_ + "/" + savedBase_ + ".fit  (.tcx, .csv)  -  upload the FIT to Strava as a Virtual Ride", x, fy + 14, F::Small, DIM, 14);
    else text("Too short to save", x, fy + 14, F::Small, DIM, 14);
    if (button({x + w - 200, fy, 200, 46}, "Done", true) || (IsKeyPressed(KEY_ENTER) && !anyTextActive())) {
        screen_ = Screen::Home;
        eng_.reset();
    }
    if (!savedDir_.empty() && button({x + w - 420, fy, 210, 46}, "Open rides folder")) OpenURL(("file://" + savedDir_).c_str());
}
