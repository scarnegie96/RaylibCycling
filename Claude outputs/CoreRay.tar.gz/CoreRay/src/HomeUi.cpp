// Home screen: Ride setup, Workouts library + editor, Devices (+ simulator test mode), Profile.
#include <algorithm>
#include <cmath>
#include <cstdio>

#include <fstream>

#include "App.h"
#include "core/Export.h"
#include "core/Metrics.h"
#include "raylib.h"

using namespace ui;

static std::string fmt(const char* f, double v) { char b[64]; std::snprintf(b, sizeof b, f, v); return b; }

void App::drawHome() {
    const float W = float(GetScreenWidth()), H = float(GetScreenHeight());
    // dim the 3D world so it reads as a backdrop
    DrawRectangle(0, 0, int(W), int(H), Color{6, 8, 12, 150});
    DrawRectangleGradientV(0, 0, int(W), 90, Color{9, 11, 16, 230}, Color{9, 11, 16, 0});
    text("CORE", 36, 18, F::Big, TEXT, 52);
    float cw = measure("CORE", F::Big, 52).x;
    text("RAY", 36 + cw + 3, 18, F::Big, ACCENT, 52);
    static const std::vector<std::string> tabs = {"Ride", "Workouts", "Devices", "Profile"};
    int t = segmented({W / 2 - 260, 24, 520, 44}, tabs, tab_);
    if (t >= 0) tab_ = t;
    {
        float cx = W - 24;
        auto chipFor = [&](const Link& l, const char* none, bool trainer) {
            Color c = l.state == LinkState::Connected ? GOOD : l.state == LinkState::Disconnected ? FAINT : WARN;
            std::string label = l.state == LinkState::Disconnected || l.name.empty() ? none : l.name;
            if (trainer && simActive()) { label = "Simulator"; c = SKY; }
            float wdt;
            chip(cx - measure(label, F::Small).x - 34, 30, label, c, &wdt);
            cx -= wdt + 8;
        };
        chipFor(ble_.hrm(), "No HRM", false);
        chipFor(ble_.trainer(), "No trainer", true);
    }
    Rectangle body{32, 96, W - 64, H - 120};
    switch (tab_) {
        case TabRide: drawRideSetup(body); break;
        case TabWorkouts: drawWorkoutsTab(body); break;
        case TabDevices: drawDevicesTab(body); break;
        default: drawProfileTab(body); break;
    }
    if (IsKeyPressed(KEY_ENTER) && !anyTextActive() && tab_ == TabRide) startRide();
}

// ------------------------------------------------------------------ ride setup
void App::drawRideSetup(Rectangle r) {
    float lw = std::min(620.f, r.width * 0.46f);
    Rectangle L{r.x, r.y, lw, r.height};
    panel(L, Color{12, 14, 22, 242});
    float x = L.x + 22, y = L.y + 18, w = L.width - 44;
    text("Start a ride", x, y, F::Title, TEXT);
    y += 50;
    static const std::vector<std::string> kinds = {"Route", "Workout", "Test", "Free ride"};
    int k = segmented({x, y, w, 42}, kinds, int(setupKind_));
    if (k >= 0) setupKind_ = RideKind(k);
    y += 60;
    int d;
    char b[160];
    switch (setupKind_) {
        case RideKind::Route: {
            textWrapped("Ride the course for a set number of laps. The trainer follows the real gradient, scaled by your difficulty setting. "
                        "Race your personal best as a ghost.", {x, y, w, 80}, F::Body, DIM, 17);
            y += 70;
            if (stepper({x, y, w, 36}, "Laps", std::to_string(setupLaps_), &d)) setupLaps_ = std::clamp(setupLaps_ + d, 1, 20);
            y += 48;
            std::snprintf(b, sizeof b, "%s  \xC2\xB7  %.0f m climbing", fmtDist(route_.length * setupLaps_, prof_.metric).c_str(), course_.totalAscent() * setupLaps_);
            text(b, x, y, F::Body, TEXT);
            y += 34;
            double best = 0;
            auto ghost = store::loadGhost(prefs_.courseSeed, setupLaps_, &best);
            if (!ghost.empty()) {
                if (toggle({x, y, w, 34}, "Race your ghost (PB " + fmtTime(best) + ")", raceGhost_)) raceGhost_ = !raceGhost_;
            } else text("No ghost yet - finish this route to set one.", x, y + 6, F::Small, FAINT);
            y += 46;
            if (stepper({x, y, w, 36}, "Trainer difficulty", fmt("%.0f%%", prof_.trainerDifficulty * 100), &d))
                prof_.trainerDifficulty = std::clamp(prof_.trainerDifficulty + d * 0.05, 0.0, 1.5);
            y += 48;
            break;
        }
        case RideKind::Workout: {
            const wk::Workout* wkp = findWorkout(selWorkout_);
            if (!wkp) break;
            text(wkp->name, x, y, F::Title, TEXT, 28);
            y += 36;
            auto e = wkp->estimate(prof_.ftp);
            std::snprintf(b, sizeof b, "%s  \xC2\xB7  TSS %.0f  \xC2\xB7  IF %.2f  \xC2\xB7  %s", fmtTime(e.durationS).c_str(), e.tss, e.intensityFactor, wkp->category.c_str());
            text(b, x, y, F::Body, DIM);
            y += 30;
            y += textWrapped(wkp->description, {x, y, w, 60}, F::Body, DIM, 16) + 8;
            auto steps = wkp->steps();
            workoutChart({x, y, w, 110}, steps, prof_.ftp, 1.0, -1, nullptr);
            y += 124;
            if (button({x, y, 200, 36}, "Choose workout...")) tab_ = TabWorkouts;
            y += 50;
            if (toggle({x, y, w, 34}, "Resistance mode (you control power)", workoutResistance_)) workoutResistance_ = !workoutResistance_;
            y += 46;
            break;
        }
        case RideKind::Test: {
            for (auto& t : wk::testCatalogue()) {
                Rectangle c{x, y, w, 96};
                bool sel = t.kind == selTest_;
                bool h = hovered(c);
                DrawRectangleRounded(c, 0.15f, 8, sel ? Color{255, 92, 56, 55} : h ? Color{40, 46, 64, 230} : Color{24, 28, 40, 220});
                if (sel) DrawRectangleRoundedLinesEx(c, 0.15f, 8, 1.5f, ACCENT);
                text(t.name, c.x + 14, c.y + 8, F::Body, TEXT, 21);
                textRight("~" + std::to_string(t.approxMinutes) + " min", c.x + c.width - 14, c.y + 10, F::Small, DIM);
                textWrapped(t.summary, {c.x + 14, c.y + 36, c.width - 28, 50}, F::Small, DIM, 15);
                if (clicked(c)) selTest_ = t.kind;
                y += 106;
            }
            for (auto& t : wk::testCatalogue())
                if (t.kind == selTest_) y += textWrapped(t.how, {x, y, w, 90}, F::Small, FAINT, 14) + 6;
            if (selTest_ == wk::TestKind::Ramp) {
                auto [st, stp] = wk::rampParams(prof_.ftp);
                std::snprintf(b, sizeof b, "Starts at %.0f W, +%.0f W per minute (FTP %.0f W)", st, stp, prof_.ftp);
                text(b, x, y, F::Small, TEXT, 15);
            }
            break;
        }
        case RideKind::Free: {
            text("Mode", x, y, F::Small, DIM);
            y += 22;
            static const std::vector<std::string> modes = {"Gradient", "Power (ERG)", "Level", "Heart rate"};
            int m = segmented({x, y, w, 38}, modes, int(setupFreeMode_));
            if (m >= 0) setupFreeMode_ = FreeMode(m);
            y += 50;
            static const char* desc[] = {"SIM mode: the course gradient (plus an offset you set with the arrow keys).",
                                         "ERG: hold fixed watts. Up/Down change the target by 5 W.",
                                         "Resistance level, like a classic trainer. Up/Down change the level.",
                                         "ERG adjusted automatically to hold a target heart rate (needs a strap)."};
            textWrapped(desc[int(setupFreeMode_)], {x, y, w, 40}, F::Small, DIM, 15);
            y += 44;
            text("Goal", x, y, F::Small, DIM);
            y += 22;
            static const std::vector<std::string> goals = {"None", "Time", "Distance", "kJ", "kcal", "Climbing"};
            int g = segmented({x, y, w, 36}, goals, int(setupGoal_.type));
            if (g >= 0) {
                setupGoal_.type = Goal::Type(g);
                static const double defaults[] = {0, 3600, 30000, 600, 600, 500};
                setupGoal_.value = defaults[g];
            }
            y += 48;
            if (setupGoal_.type != Goal::None) {
                static const double steps[] = {0, 300, 5000, 50, 50, 50};
                if (stepper({x, y, w, 36}, "Target", goalLabel(setupGoal_, prof_.metric), &d, 150))
                    setupGoal_.value = std::max(steps[setupGoal_.type], setupGoal_.value + d * steps[setupGoal_.type]);
                y += 48;
            }
            break;
        }
    }
    // start button
    bool ready = ble_.trainer().state == LinkState::Connected || simActive();
    Rectangle sb{x, L.y + L.height - 92, w, 70};
    if (button(sb, ready ? "START RIDE" : "START  (no trainer - connect one or use the simulator)", true, true, ready ? 24 : 17)) startRide();

    // right: course card
    Rectangle R{L.x + L.width + 20, r.y, r.width - L.width - 20, std::min(330.f, r.height)};
    panel(R, Color{12, 14, 22, 242});
    x = R.x + 22; y = R.y + 18; w = R.width - 44;
    text(course_.name(), x, y, F::Title, TEXT, 30);
    if (button({R.x + R.width - 160, y, 138, 34}, "New course")) {
        newCourse(prefs_.courseSeed + 1);
        rebuildWorld();
        store::save(prof_, prefs_);
    }
    y += 44;
    double maxG = 0;
    for (size_t i = 0; i + 5 < route_.ele.size(); i += 5) maxG = std::max(maxG, (route_.ele[i + 5] - route_.ele[i]) / 50.0);
    std::snprintf(b, sizeof b, "%s loop  \xC2\xB7  %.0f m climbing  \xC2\xB7  max %.1f%%  \xC2\xB7  %zu climbs", fmtDist(route_.length, prof_.metric).c_str(),
                  course_.totalAscent(), maxG * 100, route_.climbs.size());
    text(b, x, y, F::Body, DIM);
    y += 34;
    routeProfile({x, y, w, R.y + R.height - y - 70}, route_, std::fmod(homeDist_, route_.length), -1, prof_.metric);
    y = R.y + R.height - 58;
    float cx = x;
    for (auto& c : route_.climbs) {
        std::snprintf(b, sizeof b, "%s  %.1f km @ %.1f%%", c.category == "Uncategorised" ? "Climb" : c.category.c_str(), c.lengthM / 1000, c.avgGradePct);
        float cwid = measure(b, F::Small).x + 20;
        if (cx + cwid > x + w) break;
        DrawRectangleRounded({cx, y, cwid, 26}, 1, 8, Color{40, 46, 64, 220});
        text(b, cx + 10, y + 5, F::Small, TEXT);
        cx += cwid + 8;
    }
    // tips panel
    Rectangle T{R.x, R.y + R.height + 16, R.width, r.height - R.height - 16};
    if (T.height > 120) {
        panel(T, Color{12, 14, 22, 200});
        float ty = T.y + 16;
        text("While riding", T.x + 22, ty, F::Body, TEXT);
        ty += 30;
        const char* lines[] = {"Space  pause / resume          L  lap          E  edit drawer          V  2D / 3D",
                               "Up / Down  nudge target (intensity, watts, gradient, level, HR)          Right  skip step",
                               "[ ]  or  PgUp/PgDn  virtual gears          C  camera          T  time of day          H  HR alerts",
                               "D  simulator test data          Tab  hide HUD          ?  help          Esc  menu",
                               "Drop .zwo / .erg / .mrc / .txt files on the window to import workouts."};
        for (auto* l : lines) {
            if (ty > T.y + T.height - 22) break;
            text(l, T.x + 22, ty, F::Small, DIM, 15);
            ty += 24;
        }
    }
}

// ------------------------------------------------------------------ workouts
void App::drawWorkoutsTab(Rectangle r) {
    if (editorOpen_) { drawWorkoutEditor(r); return; }
    float lw = std::min(640.f, r.width * 0.5f);
    Rectangle L{r.x, r.y, lw, r.height};
    panel(L, Color{12, 14, 22, 242});
    float x = L.x + 18, y = L.y + 14, w = L.width - 36;
    text("Workouts", x, y, F::Title, TEXT);
    if (button({L.x + L.width - 150, y + 2, 132, 34}, "+ New")) {
        editorOpen_ = true;
        editingId_.clear();
        edName_.text = "My workout";
        edDesc_.text.clear();
        edText_.text = "10m 45-75%\n3x (8m @95%, 4m @55%)\n5m 60-40%";
        edErr_.clear();
    }
    y += 48;
    // category chips
    std::vector<std::string> cats = {"All"};
    for (auto& c : wk::categories()) cats.push_back(c);
    if (!custom_.empty()) cats.push_back("Custom");
    float cx = x;
    for (size_t i = 0; i < cats.size(); ++i) {
        float cwid = measure(cats[i], F::Small).x + 22;
        if (cx + cwid > x + w) { cx = x; y += 32; }
        if (chipButton({cx, y, cwid, 26}, cats[i], wkCategory_ == int(i))) wkCategory_ = int(i);
        cx += cwid + 6;
    }
    y += 34;
    static const std::vector<std::string> sorts = {"Library order", "Duration", "TSS"};
    int s = segmented({x, y, 360, 32}, sorts, wkSort_);
    if (s >= 0) wkSort_ = s;
    y += 44;
    std::vector<const wk::Workout*> list;
    for (auto* wp : allWorkouts()) {
        if (wkCategory_ == 0) list.push_back(wp);
        else if (cats[wkCategory_] == "Custom" ? wp->id.rfind("custom-", 0) == 0 : wp->category == cats[wkCategory_]) list.push_back(wp);
    }
    if (wkSort_ == 1) std::stable_sort(list.begin(), list.end(), [](auto* a, auto* b) { return a->durationS() < b->durationS(); });
    if (wkSort_ == 2) std::stable_sort(list.begin(), list.end(), [&](auto* a, auto* b) { return a->estimate(prof_.ftp).tss < b->estimate(prof_.ftp).tss; });
    Rectangle listR{x, y, w, L.y + L.height - y - 12};
    if (hovered(listR)) wkScroll_ -= GetMouseWheelMove() * 60;
    float rowH = 62;
    wkScroll_ = std::clamp(wkScroll_, 0.f, std::max(0.f, list.size() * (rowH + 6) - listR.height));
    BeginScissorMode(int(listR.x), int(listR.y), int(listR.width), int(listR.height));
    char b[160];
    for (size_t i = 0; i < list.size(); ++i) {
        const auto* wp = list[i];
        Rectangle c{listR.x, listR.y + i * (rowH + 6) - wkScroll_, listR.width, rowH};
        if (c.y + c.height < listR.y || c.y > listR.y + listR.height) continue;
        bool sel = wp->id == wkSelected_;
        bool h = hovered(c) && CheckCollisionPointRec(GetMousePosition(), listR);
        DrawRectangleRounded(c, 0.2f, 8, sel ? Color{255, 92, 56, 55} : h ? Color{40, 46, 64, 230} : Color{24, 28, 40, 220});
        if (sel) DrawRectangleRoundedLinesEx(c, 0.2f, 8, 1.4f, ACCENT);
        text(wp->name, c.x + 14, c.y + 8, F::Body, TEXT, 19);
        auto e = wp->estimate(prof_.ftp);
        std::snprintf(b, sizeof b, "%s  \xC2\xB7  TSS %.0f  \xC2\xB7  %s", fmtTime(e.durationS).c_str(), e.tss, wp->category.c_str());
        text(b, c.x + 14, c.y + 36, F::Small, DIM, 14);
        workoutChart({c.x + c.width - 170, c.y + 8, 156, rowH - 16}, wp->steps(), prof_.ftp, 1.0, -1, nullptr);
        if (h && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) wkSelected_ = wp->id;
    }
    EndScissorMode();

    // detail
    const wk::Workout* sel = findWorkout(wkSelected_);
    Rectangle R{L.x + L.width + 20, r.y, r.width - L.width - 20, r.height};
    panel(R, Color{12, 14, 22, 242});
    if (!sel) return;
    x = R.x + 22; y = R.y + 18; w = R.width - 44;
    text(sel->name, x, y, F::Title, TEXT);
    y += 44;
    y += textWrapped(sel->description.empty() ? sel->category : sel->description, {x, y, w, 80}, F::Body, DIM, 17) + 10;
    auto steps = sel->steps();
    workoutChart({x, y, w, 150}, steps, prof_.ftp, 1.0, -1, nullptr);
    y += 166;
    auto e = sel->estimate(prof_.ftp);
    struct KV { const char* k; std::string v; };
    std::vector<KV> kv = {{"DURATION", fmtTime(e.durationS)}, {"TSS", fmt("%.0f", e.tss)},     {"IF", fmt("%.2f", e.intensityFactor)},
                          {"NP", fmt("%.0f W", e.np)},          {"WORK", fmt("%.0f kJ", e.workKj)}, {"AVG", fmt("%.0f W", e.avgPower)}};
    float tw = (w - 5 * 10) / 6;
    for (size_t i = 0; i < kv.size(); ++i) {
        Rectangle c{x + i * (tw + 10), y, tw, 62};
        panel(c, Color{26, 30, 42, 220});
        text(kv[i].k, c.x + 10, c.y + 6, F::Small, DIM, 12);
        text(kv[i].v, c.x + 10, c.y + 24, F::Title, TEXT, 26);
    }
    y += 76;
    text("Time in zone", x, y, F::Small, DIM);
    y += 22;
    std::vector<std::string> zl;
    std::vector<Color> zc;
    for (int z = 0; z < 7; ++z) { zl.push_back("Z" + std::to_string(z + 1) + " " + metrics::ZONE_NAMES[z]); zc.push_back(zoneColor(z)); }
    float zh = std::min(170.f, R.y + R.height - y - 80);
    if (zh > 70) zoneBars({x, y, w, zh}, e.zoneS.data(), 7, zl, zc);
    // actions
    float by = R.y + R.height - 62;
    if (button({x, by, 220, 46}, "Ride this workout", true)) {
        selWorkout_ = sel->id;
        setupKind_ = RideKind::Workout;
        tab_ = TabRide;
    }
    if (button({x + 232, by, 150, 46}, "Export .zwo")) {
        std::string base = sel->name;
        for (auto& c : base) if (!std::isalnum((unsigned char)c)) c = '_';
        std::string path = exporter::ridesDir() + "/" + base + ".zwo";
        std::ofstream(path) << wk::toZwo(*sel);
        toast("Saved " + path, GOOD);
    }
    bool isCustom = sel->id.rfind("custom-", 0) == 0;
    if (button({x + 394, by, 160, 46}, isCustom ? "Edit" : "Copy & edit")) {
        editorOpen_ = true;
        editingId_ = isCustom ? sel->id : "";
        edName_.text = isCustom ? sel->name : sel->name + " (copy)";
        edDesc_.text = sel->description;
        edText_.text = wk::toText(sel->blocks);
        edErr_.clear();
    }
    if (isCustom && button({x + 566, by, 120, 46}, "Delete")) {
        store::deleteCustomWorkout(sel->id);
        custom_ = store::loadCustomWorkouts();
        wkSelected_ = builtin_[0].id;
        toast("Workout deleted");
    }
}

void App::drawWorkoutEditor(Rectangle r) {
    panel(r, Color{12, 14, 22, 235});
    float x = r.x + 22, y = r.y + 16, w = r.width - 44;
    text(editingId_.empty() ? "New workout" : "Edit workout", x, y, F::Title, TEXT);
    y += 50;
    float lw = w * 0.46f;
    text("Name", x, y, F::Small, DIM);
    textBox({x, y + 20, lw, 38}, edName_, false);
    text("Description", x + lw + 20, y, F::Small, DIM);
    textBox({x + lw + 20, y + 20, w - lw - 20, 38}, edDesc_, false);
    y += 74;
    text("Plan (text format)", x, y, F::Small, DIM);
    Rectangle tr{x, y + 20, lw, r.y + r.height - y - 110};
    textBox(tr, edText_, true, "10m 50-75%");
    // help
    float hx = x + lw + 20, hw = w - lw - 20;
    float hy = y;
    text("Format", hx, hy, F::Small, DIM);
    hy += 22;
    const char* help[] = {"10m 50-75%                 ramp from 50 % to 75 % FTP", "20m @90% 85rpm             steady with a cadence target",
                          "5x 1m @120% / 1m @50%      intervals", "3x (30s @150%, 30s @50%)   a repeat set (nestable)",
                          "2m free  \xC2\xB7  30s effort @2%   rider-controlled", "1:30 @250w  \xC2\xB7  1h @65%       mm:ss, hours, watts",
                          "One item per line, or separate with commas."};
    for (auto* h : help) { text(h, hx, hy, F::Small, TEXT, 14); hy += 20; }
    hy += 10;
    std::vector<wk::Block> blocks;
    std::string err;
    bool ok = wk::parseText(edText_.text, prof_.ftp, blocks, err);
    if (ok) {
        auto steps = wk::blocksToSteps(blocks);
        workoutChart({hx, hy, hw, 140}, steps, prof_.ftp, 1.0, -1, nullptr);
        hy += 152;
        auto e = wk::estimateSteps(steps, prof_.ftp);
        char b[200];
        std::snprintf(b, sizeof b, "%s  \xC2\xB7  TSS %.0f  \xC2\xB7  IF %.2f  \xC2\xB7  NP %.0f W  \xC2\xB7  %.0f kJ  \xC2\xB7  %zu steps", fmtTime(e.durationS).c_str(), e.tss,
                      e.intensityFactor, e.np, e.workKj, steps.size());
        text(b, hx, hy, F::Body, TEXT, 17);
    } else {
        DrawRectangleRounded({hx, hy, hw, 44}, 0.3f, 6, Color{248, 82, 82, 40});
        text(err, hx + 12, hy + 12, F::Body, BAD, 16);
    }
    float by = r.y + r.height - 70;
    if (button({x, by, 180, 48}, "Save", true, ok && !edName_.text.empty())) {
        wk::Workout wo;
        wo.id = editingId_;
        wo.name = edName_.text;
        wo.description = edDesc_.text;
        wo.category = "Custom";
        wo.blocks = blocks;
        std::string e2;
        if (store::saveCustomWorkout(wo, e2)) {
            custom_ = store::loadCustomWorkouts();
            for (auto& c : custom_) if (c.name == wo.name) wkSelected_ = c.id;
            editorOpen_ = false;
            toast("Workout saved", GOOD);
        } else toast(e2, BAD);
    }
    if (button({x + 192, by, 140, 48}, "Cancel")) editorOpen_ = false;
}

// ------------------------------------------------------------------ devices
void App::drawDevicesTab(Rectangle r) {
    float lw = std::min(720.f, r.width * 0.55f);
    Rectangle L{r.x, r.y, lw, r.height};
    panel(L, Color{12, 14, 22, 242});
    float x = L.x + 22, y = L.y + 16, w = L.width - 44;
    char b[200];
    text("Devices", x, y, F::Title, TEXT);
    textRight(ble_.status(), x + w, y + 12, F::Small, ble_.available() ? DIM : WARN);
    y += 52;
    TrainerInput live = ble_.input();
    for (int k = 0; k < 2; ++k) {
        Link l = k == 0 ? ble_.trainer() : ble_.hrm();
        Rectangle c{x, y, w, 64};
        panel(c, Color{24, 28, 40, 220});
        Color dot = l.state == LinkState::Connected ? GOOD : l.state == LinkState::Disconnected ? FAINT : WARN;
        DrawCircle(int(c.x + 20), int(c.y + 32), 7, dot);
        text(k == 0 ? "Smart trainer" : "Heart rate", c.x + 38, c.y + 8, F::Body, TEXT);
        static const char* st[] = {"not connected", "connecting...", "connected", "reconnecting..."};
        std::snprintf(b, sizeof b, "%s  %s  %s", l.name.c_str(), st[int(l.state)], l.detail.c_str());
        text(b, c.x + 38, c.y + 36, F::Small, DIM, 14);
        if (l.state != LinkState::Disconnected && button({c.x + c.width - 130, c.y + 14, 116, 36}, "Disconnect")) {
            if (k == 0) { ble_.disconnectTrainer(); prefs_.trainerId.clear(); } else { ble_.disconnectHrm(); prefs_.hrId.clear(); }
            ble_.setAutoConnect(prefs_.trainerId, prefs_.hrId);
            store::save(prof_, prefs_);
        }
        y += 74;
    }
    std::snprintf(b, sizeof b, "Live:  %s W   %s rpm   %s bpm", live.connected ? std::to_string(int(live.powerW)).c_str() : "--",
                  live.connected ? std::to_string(int(live.cadenceRpm)).c_str() : "--",
                  live.heartRate ? std::to_string(int(*live.heartRate)).c_str() : "--");
    text(b, x, y, F::Body, TEXT);
    y += 36;
    bool scanning = ble_.scanning();
    if (button({x, y, 200, 40}, scanning ? "Stop scanning" : "Scan for devices", !scanning, ble_.available())) {
        if (scanning) ble_.stopScan(); else ble_.startScan(60);
    }
    if (scanning) text(std::string("Scanning") + std::string(int(GetTime() * 3) % 4, '.'), x + 214, y + 10, F::Body, DIM);
    y += 54;
    auto devs = ble_.devices();
    if (devs.empty())
        textWrapped("Pedal to wake the KICKR, put on (or start broadcasting) your heart-rate strap, then scan. Close Zwift / the Wahoo app first - "
                    "only one app can control the trainer.", {x, y, w, 80}, F::Body, DIM, 16);
    for (auto& d : devs) {
        if (y > L.y + L.height - 140) break;
        Rectangle c{x, y, w, 50};
        DrawRectangleRounded(c, 0.25f, 8, Color{24, 28, 40, 200});
        text(d.name, c.x + 14, c.y + 6, F::Body, TEXT, 19);
        const char* tag = d.kind == DevKind::Trainer ? (d.ftms ? "FTMS trainer" : "Trainer") : d.kind == DevKind::HeartRate ? "Heart rate" : "Power meter";
        std::snprintf(b, sizeof b, "%s  \xC2\xB7  %d dBm", tag, d.rssi);
        text(b, c.x + 14, c.y + 29, F::Small, DIM, 13);
        Link lt = ble_.trainer(), lh = ble_.hrm();
        if (d.kind == DevKind::Trainer) {
            bool on = lt.id == d.id && lt.state == LinkState::Connected;
            if (button({c.x + c.width - 150, c.y + 8, 136, 34}, on ? "Trainer \xE2\x9C\x93" : "Use as trainer", !on)) ble_.connectTrainer(d.id);
        } else if (d.kind == DevKind::HeartRate) {
            bool on = lh.id == d.id && lh.state == LinkState::Connected;
            if (button({c.x + c.width - 150, c.y + 8, 136, 34}, on ? "Heart rate" : "Use as HRM", !on)) ble_.connectHrm(d.id);
        }
        y += 58;
    }
    // tips
    float ty = L.y + L.height - 74;
    textWrapped("KICKR CORE: update firmware in the Wahoo app (FTMS control arrived in 2021). COROS / Garmin watches: enable heart-rate broadcast, "
                "and disconnect the watch from your phone first. If the trainer drops out, CoreRay reconnects and re-sends the target.",
                {x, ty, w, 70}, F::Small, FAINT, 13);

    Rectangle R{L.x + L.width + 20, r.y, r.width - L.width - 20, r.height};
    panel(R, Color{12, 14, 22, 242});
    drawSimPanel({R.x + 20, R.y + 16, R.width - 40, R.height - 32}, false);
}

void App::drawSimPanel(Rectangle r, bool compact) {
    float x = r.x, y = r.y, w = r.width;
    text(compact ? "Test data" : "Simulator", x, y, F::Title, TEXT, compact ? 24 : 34);
    y += compact ? 36 : 48;
    if (!compact) {
        textWrapped("A virtual trainer and rider so you can try everything without the bike. Rides on the simulator never count as real efforts.",
                    {x, y, w, 60}, F::Small, DIM, 15);
        y += 48;
        if (toggle({x, y, w, 34}, "Use the simulator instead of Bluetooth", prefs_.simEnabled)) {
            prefs_.simEnabled = !prefs_.simEnabled;
            store::save(prof_, prefs_);
        }
        y += 50;
    }
    sim::Settings s = sim_->settings();
    bool ch = false;
    int d;
    text("Power", x, y, F::Small, DIM);
    y += 20;
    int ps = segmented({x, y, w, 32}, {"Simulated rider", "Fixed watts"}, int(s.powerSource));
    if (ps >= 0) { s.powerSource = sim::PowerSource(ps); ch = true; }
    y += 40;
    if (s.powerSource == sim::PowerSource::Rider) {
        if (stepper({x, y, w, 30}, "Rider effort", fmt("%.0f W", s.effortW), &d)) { s.effortW += d * 10; ch = true; }
    } else if (stepper({x, y, w, 30}, "Fixed power", fmt("%.0f W", s.powerW), &d)) { s.powerW += d * 10; ch = true; }
    y += 40;
    int pt = segmented({x, y, w, 30}, {"Steady", "Surges", "Wave", "Fade"}, int(s.pattern));
    if (pt >= 0) { s.pattern = sim::Pattern(pt); ch = true; }
    y += 42;
    text("Heart rate", x, y, F::Small, DIM);
    y += 20;
    int hs = segmented({x, y, w, 30}, {"Model", "Fixed", "Off"}, int(s.hrSource));
    if (hs >= 0) { s.hrSource = sim::HrSource(hs); ch = true; }
    y += 38;
    if (s.hrSource == sim::HrSource::Fixed) {
        if (stepper({x, y, w, 30}, "Heart rate", fmt("%.0f bpm", s.hrBpm), &d)) { s.hrBpm += d * 2; ch = true; }
        y += 38;
    }
    int cs = segmented({x, y, w * 0.5f - 6, 30}, {"Auto cadence", "Fixed"}, int(s.cadenceSource));
    if (cs >= 0) { s.cadenceSource = sim::CadenceSource(cs); ch = true; }
    if (s.cadenceSource == sim::CadenceSource::Fixed) {
        int d2;
        if (stepper({x + w * 0.5f + 6, y, w * 0.5f - 6, 30}, "", fmt("%.0f rpm", s.cadenceRpm), &d2, 80)) { s.cadenceRpm += d2 * 5; ch = true; }
    }
    y += 40;
    if (stepper({x, y, w, 30}, "Noise", fmt("%.0f%%", s.variability * 100), &d)) { s.variability += d * 0.1; ch = true; }
    y += 40;
    if (toggle({x, y, w, 30}, "Trainer signal dropout", s.dropout)) { s.dropout = !s.dropout; ch = true; }
    y += 40;
    if (ch) { sim_->set(s); prefs_.sim = sim_->settings(); }
    if (compact) text("Shift+Up/Down power 10 W  \xC2\xB7  Alt+Up/Down HR 2 bpm", x, y, F::Small, FAINT, 13);
}

// ------------------------------------------------------------------ profile
void App::drawProfileTab(Rectangle r) {
    float colW = (r.width - 40) / 3;
    int d;
    char b[160];
    bool changed = false;
    auto row = [&](Rectangle c, float& y, const std::string& label, const std::string& val, auto apply) {
        if (stepper({c.x + 20, y, c.width - 40, 34}, label, val, &d, 110)) { apply(d); changed = true; }
        y += 44;
    };
    // --- rider
    Rectangle A{r.x, r.y, colW, r.height};
    panel(A, Color{12, 14, 22, 242});
    float y = A.y + 16;
    text("Rider", A.x + 20, y, F::Title, TEXT);
    y += 52;
    row(A, y, "FTP", fmt("%.0f W", prof_.ftp), [&](int k) { prof_.ftp = std::clamp(prof_.ftp + k * 5, 60.0, 600.0); });
    row(A, y, "Weight", fmt(prof_.metric ? "%.1f kg" : "%.0f lb", prof_.metric ? prof_.weightKg : prof_.weightKg * 2.20462),
        [&](int k) { prof_.weightKg = std::clamp(prof_.weightKg + k * (prof_.metric ? 0.5 : 0.4536), 30.0, 180.0); });
    row(A, y, "Bike weight", fmt("%.1f kg", prof_.bikeWeightKg), [&](int k) { prof_.bikeWeightKg = std::clamp(prof_.bikeWeightKg + k * 0.5, 4.0, 25.0); });
    row(A, y, "Age", std::to_string(prof_.age), [&](int k) { prof_.age = std::clamp(prof_.age + k, 10, 99); });
    if (toggle({A.x + 20, y, A.width - 40, 34}, prof_.male ? "Sex: male" : "Sex: female", !prof_.male)) { prof_.male = !prof_.male; changed = true; }
    y += 44;
    std::snprintf(b, sizeof b, "%.2f W/kg", prof_.ftp / prof_.weightKg);
    text(b, A.x + 20, y, F::Title, ACCENT, 30);
    y += 48;
    if (toggle({A.x + 20, y, A.width - 40, 34}, "Metric units", prof_.metric)) { prof_.metric = !prof_.metric; changed = true; }
    y += 52;
    if (store::coreKickAvailable()) {
        if (button({A.x + 20, y, A.width - 40, 44}, "Import profile & workouts from CoreKick")) {
            std::vector<wk::Workout> imp;
            store::importCoreKick(prof_, imp, importMsg_);
            custom_ = store::loadCustomWorkouts();
            changed = true;
            toast(importMsg_, GOOD);
        }
        y += 52;
        if (!importMsg_.empty()) textWrapped(importMsg_, {A.x + 20, y, A.width - 40, 40}, F::Small, DIM, 14);
    } else textWrapped("CoreKick's database wasn't found on this computer, so there is nothing to import.", {A.x + 20, y, A.width - 40, 40}, F::Small, FAINT, 14);

    // --- heart rate
    Rectangle B{A.x + colW + 20, r.y, colW, r.height};
    panel(B, Color{12, 14, 22, 242});
    y = B.y + 16;
    text("Heart rate", B.x + 20, y, F::Title, TEXT);
    y += 52;
    row(B, y, "Max HR", fmt("%.0f", prof_.maxHr), [&](int k) { prof_.maxHr = std::clamp(prof_.maxHr + k, 120.0, 230.0); });
    row(B, y, "Resting HR", fmt("%.0f", prof_.restHr), [&](int k) { prof_.restHr = std::clamp(prof_.restHr + k, 30.0, 100.0); });
    text("Zone model", B.x + 20, y, F::Small, DIM);
    y += 20;
    int zm = segmented({B.x + 20, y, B.width - 40, 32}, {"% max", "Reserve", "LTHR"}, int(prof_.hrZoneModel));
    if (zm >= 0) { prof_.hrZoneModel = HrZoneModel(zm); changed = true; }
    y += 42;
    if (prof_.hrZoneModel == HrZoneModel::Lthr)
        row(B, y, "Threshold HR", fmt("%.0f", prof_.lthr > 0 ? prof_.lthr : prof_.maxHr * 0.9),
            [&](int k) { prof_.lthr = std::clamp((prof_.lthr > 0 ? prof_.lthr : prof_.maxHr * 0.9) + k, 100.0, 210.0); });
    auto zones = prof_.hrZones();
    for (auto& z : zones) {
        std::snprintf(b, sizeof b, "Z%d %s", z.zone, z.name.c_str());
        DrawRectangleRounded({B.x + 20, y + 4, 8, 16}, 1, 4, hrZoneColor(z.zone, int(zones.size())));
        text(b, B.x + 36, y, F::Small, TEXT, 15);
        std::snprintf(b, sizeof b, z.hi ? "%.0f - %.0f bpm" : "%.0f+ bpm", z.lo, z.hi.value_or(0));
        textRight(b, B.x + B.width - 20, y, F::Small, DIM, 15);
        y += 22;
    }
    y += 12;
    if (toggle({B.x + 20, y, B.width - 40, 34}, "Heart-rate alerts", prof_.hrAlerts)) { prof_.hrAlerts = !prof_.hrAlerts; hrAlertsOn_ = prof_.hrAlerts; changed = true; }
    y += 44;
    int nz = int(zones.size());
    row(B, y, "Stay above zone", "Z" + std::to_string(prof_.hrAlertLo), [&](int k) { prof_.hrAlertLo = std::clamp(prof_.hrAlertLo + k, 1, prof_.hrAlertHi); });
    row(B, y, "Stay below zone", "Z" + std::to_string(prof_.hrAlertHi), [&](int k) { prof_.hrAlertHi = std::clamp(prof_.hrAlertHi + k, prof_.hrAlertLo, nz); });
    row(B, y, "Warm-up grace", fmtTime(prof_.hrAlertGraceS), [&](int k) { prof_.hrAlertGraceS = std::clamp(prof_.hrAlertGraceS + k * 60, 0.0, 1800.0); });

    // --- bike & trainer
    Rectangle C{B.x + colW + 20, r.y, colW, r.height};
    panel(C, Color{12, 14, 22, 242});
    y = C.y + 16;
    text("Bike & trainer", C.x + 20, y, F::Title, TEXT);
    y += 52;
    text("Position (CdA)", C.x + 20, y, F::Small, DIM);
    y += 20;
    static const double cdas[] = {0.40, 0.32, 0.28, 0.24};
    int ci = 1;
    for (int i = 0; i < 4; ++i) if (std::fabs(prof_.cda - cdas[i]) < 0.005) ci = i;
    int cn = segmented({C.x + 20, y, C.width - 40, 32}, {"Upright", "Hoods", "Drops", "TT"}, ci);
    if (cn >= 0) { prof_.cda = cdas[cn]; changed = true; }
    y += 42;
    text("Road surface (Crr)", C.x + 20, y, F::Small, DIM);
    y += 20;
    static const double crrs[] = {0.003, 0.004, 0.006, 0.008};
    int ri = 1;
    for (int i = 0; i < 4; ++i) if (std::fabs(prof_.crr - crrs[i]) < 0.0005) ri = i;
    int rn = segmented({C.x + 20, y, C.width - 40, 32}, {"Smooth", "Asphalt", "Rough", "Gravel"}, ri);
    if (rn >= 0) { prof_.crr = crrs[rn]; changed = true; }
    y += 44;
    row(C, y, "Trainer difficulty", fmt("%.0f%%", prof_.trainerDifficulty * 100), [&](int k) { prof_.trainerDifficulty = std::clamp(prof_.trainerDifficulty + k * 0.05, 0.0, 1.5); });
    row(C, y, "Max trainer grade", fmt("%.0f%%", prof_.maxTrainerGrade), [&](int k) { prof_.maxTrainerGrade = std::clamp(prof_.maxTrainerGrade + k, 2.0, 25.0); });
    row(C, y, "Min trainer grade", fmt("%.0f%%", prof_.minTrainerGrade), [&](int k) { prof_.minTrainerGrade = std::clamp(prof_.minTrainerGrade + k, -20.0, 0.0); });
    row(C, y, "Gross efficiency", fmt("%.0f%%", prof_.grossEfficiency * 100), [&](int k) { prof_.grossEfficiency = std::clamp(prof_.grossEfficiency + k * 0.01, 0.15, 0.30); });
    if (toggle({C.x + 20, y, C.width - 40, 34}, "Virtual shifting (Zwift Cog)", prof_.virtualShifting)) { prof_.virtualShifting = !prof_.virtualShifting; changed = true; }
    y += 44;
    if (prof_.virtualShifting) {
        row(C, y, "Start gear", std::to_string(prof_.startGear) + " / 24", [&](int k) { prof_.startGear = std::clamp(prof_.startGear + k, 1, 24); });
        row(C, y, "Wheel circumference", fmt("%.0f mm", prof_.wheelCircM * 1000), [&](int k) { prof_.wheelCircM = std::clamp(prof_.wheelCircM + k * 0.005, 1.9, 2.4); });
    }
    text("Graphics", C.x + 20, y, F::Small, DIM);
    y += 20;
    int q = segmented({C.x + 20, y, C.width - 40, 32}, {"Battery", "Balanced", "High"}, prefs_.quality);
    if (q >= 0 && q != prefs_.quality) { prefs_.quality = q; rebuildWorld(); changed = true; }
    y += 46;
    // live physics readout, like CoreKick's settings
    phys::Params pp;
    pp.massKg = prof_.weightKg + prof_.bikeWeightKg; pp.cda = prof_.cda; pp.crr = prof_.crr;
    std::snprintf(b, sizeof b, "250 W = %s %s on the flat, %s up 6%%", fmtSpeed(phys::steadySpeed(250, 0, 0, pp), prof_.metric).c_str(),
                  prof_.metric ? "km/h" : "mph", fmtSpeed(phys::steadySpeed(250, 0.06, 0, pp), prof_.metric).c_str());
    textWrapped(b, {C.x + 20, std::min(y, C.y + C.height - 50), C.width - 40, 40}, F::Body, TEXT, 16);
    if (changed) store::save(prof_, prefs_);
}
