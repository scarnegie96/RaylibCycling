#pragma once
#include <ctime>
#include <deque>
#include <memory>
#include <string>
#include <vector>

#include "Ble.h"
#include "Course.h"
#include "Renderer.h"
#include "Store.h"
#include "Ui.h"
#include "core/Engine.h"
#include "core/Sim.h"
#include "core/Workout.h"

class App {
public:
    int run(int argc, char** argv);

private:
    enum class Screen { Home, Ride, Summary };
    enum Tab { TabRide, TabWorkouts, TabDevices, TabProfile };

    // ---- lifecycle / flow (App.cpp)
    void newCourse(int seed);
    void rebuildWorld();
    void startRide();
    void endRide(bool save);
    void frameUpdate(float dt);
    void handleRideKeys(float dt);
    void handleEvents();
    void hrAlerts();
    void toast(const std::string& s, Color c = ui::TEXT);
    void drawToasts();
    void handleDroppedFiles();
    TrainerInput currentInput(float dt);
    bool simActive() const;
    const wk::Workout* findWorkout(const std::string& id) const;
    std::vector<const wk::Workout*> allWorkouts() const;

    // ---- home (HomeUi.cpp)
    void drawHome();
    void drawRideSetup(Rectangle r);
    void drawWorkoutsTab(Rectangle r);
    void drawWorkoutEditor(Rectangle r);
    void drawDevicesTab(Rectangle r);
    void drawSimPanel(Rectangle r, bool compact);
    void drawProfileTab(Rectangle r);

    // ---- ride (RideUi.cpp)
    void drawRideHud();
    void drawDashboard2d();
    void drawStepPanel(Rectangle r);
    void drawEditDrawer();
    void drawPauseMenu();
    void drawHelp();

    // ---- summary (SummaryUi.cpp)
    void drawSummary();

    // state ---------------------------------------------------------------
    Profile prof_;
    Prefs prefs_;
    BleManager ble_;
    Course course_;
    RouteProfile route_;
    Renderer renderer_;
    std::unique_ptr<sim::SimTrainer> sim_;
    std::vector<wk::Workout> builtin_, custom_;

    Screen screen_ = Screen::Home;
    int tab_ = TabRide;

    // ride setup
    RideKind setupKind_ = RideKind::Free;
    int setupLaps_ = 1;
    bool raceGhost_ = true;
    std::string selWorkout_ = "builtin-sweet-spot-2x20";
    bool workoutResistance_ = false;
    wk::TestKind selTest_ = wk::TestKind::Ramp;
    FreeMode setupFreeMode_ = FreeMode::Gradient;
    Goal setupGoal_;

    // workouts tab
    int wkCategory_ = 0;  // 0 = all
    int wkSort_ = 0;      // 0 default, 1 duration, 2 TSS
    std::string wkSelected_ = "builtin-sweet-spot-2x20";
    float wkScroll_ = 0;
    bool editorOpen_ = false;
    std::string editingId_;
    ui::TextBox edName_, edDesc_, edText_;
    std::string edErr_;

    // ride
    std::unique_ptr<RideEngine> eng_;
    std::time_t rideStart_ = 0;
    bool view3d_ = true;
    bool hudHidden_ = false;
    bool drawerOpen_ = false;
    int drawerTab_ = 0;
    bool testPanel_ = false;
    bool helpOpen_ = false;
    bool pauseMenu_ = false;
    bool hrAlertsOn_ = false;
    ui::TextBox insertText_;
    std::string insertErr_;
    CamMode cam_ = CamMode::Chase;
    double crank_ = 0, animTime_ = 0, lean_ = 0, stand_ = 0, tuck_ = 0, standTimer_ = 0;
    double lastAlertT_ = -1e9;
    int lastHrState_ = 0;
    int lastStepIdx_ = -1;

    // summary
    RideSummary summary_;
    std::string summaryName_;
    std::string savedDir_, savedBase_;
    bool newPb_ = false, ftpApplied_ = false;
    std::vector<float> sumPower_, sumHr_, sumCad_, sumSpeed_, sumEle_;

    // home background
    double homeDist_ = 0;

    struct Toast { std::string text; double t; Color c; };
    std::deque<Toast> toasts_;
    std::string importMsg_;
};
