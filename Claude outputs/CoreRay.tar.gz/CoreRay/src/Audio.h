#pragma once
// Synthesised sounds (no audio files): HR alert tones, step / lap chimes.
namespace sfx {
enum Kind { StepChange, Lap, HrHigh, HrLow, Countdown, Done, COUNT };
void init();
void shutdown();
void play(Kind k);
void setVolume(float v);
}  // namespace sfx
