#pragma once
// Real-time ride engine (port of CoreKick engine.rs, minus in-ride road editing).
// Feed it dt + trainer telemetry each frame; it integrates speed/distance from power on the
// real gradient, drives ERG / SIM / level targets, handles workouts, FTP tests, free-ride
// modes (gradient, power, level, heart-rate), goals, laps, climbs, ghosts and 1 Hz recording.
#include <optional>
#include <set>
#include <string>
#include <vector>

#include "Physics.h"
#include "Workout.h"

// ------------------------------------------------------------------ profile
enum class HrZoneModel { MaxHr, Reserve, Lthr };
struct HrZone { int zone; std::string name; double lo; std::optional<double> hi; };

struct Profile {
    std::string name = "Rider";
    double weightKg = 75, bikeWeightKg = 8.5;
    int age = 40;
    bool male = true;
    double ftp = 220;
    double maxHr = 182, restHr = 55;
    bool metric = true;
    double grossEfficiency = 0.24, cda = 0.32, crr = 0.004;
    double trainerDifficulty = 1.0, maxTrainerGrade = 16, minTrainerGrade = -10;
    bool virtualShifting = false;
    double wheelCircM = 2.105;
    int startGear = 10;
    HrZoneModel hrZoneModel = HrZoneModel::MaxHr;
    double lthr = 0;
    // heart-rate alerts
    bool hrAlerts = false;
    int hrAlertLo = 2, hrAlertHi = 4;   // allowed zone range (1-based)
    bool hrAlertHigh = true, hrAlertLow = true;
    double hrAlertGraceS = 300, hrAlertRepeatS = 30;
    std::vector<HrZone> hrZones() const;
};
int hrZoneOf(double hr, const std::vector<HrZone>& zones);

// ------------------------------------------------------------------ trainer IO
struct TrainerCommand {
    enum Type { Simulation, TargetPower, Resistance } type = Simulation;
    double gradePct = 0, windMps = 0, crr = 0.004, cw = 0.51;
    double watts = 0;
    double levelPct = 0;
    static TrainerCommand sim(double g, double crr, double cw) { TrainerCommand c; c.type = Simulation; c.gradePct = g; c.crr = crr; c.cw = cw; return c; }
    static TrainerCommand erg(double w) { TrainerCommand c; c.type = TargetPower; c.watts = w; return c; }
    static TrainerCommand level(double l) { TrainerCommand c; c.type = Resistance; c.levelPct = l; return c; }
};

struct TrainerInput {
    double powerW = 0, cadenceRpm = 0;
    std::optional<double> heartRate;
    bool connected = false;
};

// ------------------------------------------------------------------ route profile
struct Climb {
    double startD, endD, lengthM, gainM, avgGradePct, maxGradePct, startEle, topEle, score;
    std::string category;
};

struct RouteProfile {
    std::vector<double> ele;  // uniform samples
    double step = 10;         // metres between samples
    double length = 0;
    bool loop = true;
    std::vector<Climb> climbs;
    double elevationAt(double d) const;
    double gradeAt(double d, double half) const;  // fraction, central difference over +-half
    void detectClimbs();
};
const char* climbCategory(double score);

// ------------------------------------------------------------------ setup
enum class RideKind { Route, Workout, Test, Free };
enum class FreeMode { Gradient, Power, Level, HeartRate };
enum class ControlMode { Sim, Erg, Level };

struct Goal {
    enum Type { None, Time, Distance, Energy, Calories, Elevation } type = None;
    double value = 0;
};
std::string goalLabel(const Goal& g, bool metric);

struct RideSetup {
    RideKind kind = RideKind::Free;
    std::string name;
    int laps = 1;
    std::optional<wk::Workout> workout;
    std::optional<wk::TestKind> test;
    FreeMode freeMode = FreeMode::Gradient;
    double freeGradePct = 0, freeWatts = 0, freeLevelPct = 30, freeTargetHr = 0;
    Goal goal;
    std::vector<float> ghost;  // ghost trace: distance (m) at each second
};

struct Split {
    std::string kind, name;
    int index = 0;
    double startS = 0, durationS = 0, distanceM = 0, elevationGainM = 0;
    double avgPower = 0, maxPower = 0, np = 0, avgCadence = 0, avgSpeedKmh = 0;
    std::optional<double> avgHr;
};

struct Samples {
    std::vector<float> power, cadence, speed, hr, target, distance, ele, grade;
    size_t size() const { return power.size(); }
    std::vector<double> powerD() const { return std::vector<double>(power.begin(), power.end()); }
};

struct RideEvent { std::string kind, message; };

struct RideSummary {
    double elapsedS = 0, movingS = 0, distanceM = 0, elevationGainM = 0;
    double avgPower = 0, maxPower = 0, np = 0, intensityFactor = 0, tss = 0, vi = 0;
    double workKj = 0, caloriesKcal = 0, caloriesHr = 0;
    std::optional<double> avgHr, maxHr;
    double avgCadence = 0, maxCadence = 0, avgSpeedMps = 0, maxSpeedMps = 0;
    double ftp = 0;
    std::vector<std::pair<int, double>> bests;
    std::array<double, 7> powerZoneS{};
    std::vector<double> hrZoneS;
    std::vector<Split> splits;
    std::optional<wk::TestResult> test;
    bool routeComplete = false;
};

// ------------------------------------------------------------------ engine
class RideEngine {
public:
    RideEngine(const Profile& profile, RideSetup setup, const RouteProfile& route);

    // advance; returns a command when the trainer target changed
    std::optional<TrainerCommand> tick(double dt, const TrainerInput& in);

    // ---- actions (keyboard / edit drawer)
    void pause();
    void resume();
    void ergBias(double deltaPct);
    void skipStep();
    void toggleErg();
    void grade(double deltaPct);
    void difficulty(double deltaPct);
    void shift(int delta);
    void setFreeMode(FreeMode m);
    void freeWatts(double deltaW);
    void level(double deltaPct);
    void hrTarget(double deltaBpm);
    void setGoal(Goal g);
    void lap();
    void addLaps(int delta);
    void extendStep(int seconds);
    void adjustStep(double deltaPct);
    void insertBlocks(const std::vector<wk::Block>& blocks, bool atEnd);
    void oneMoreRep();
    void skipToCooldown();
    void endWorkout();
    void nudge(int dir);  // context-sensitive up/down like CoreKick's arrow keys

    RideSummary finish();
    std::vector<RideEvent> drainEvents();

    // ---- state for the UI
    const RideSetup& setup() const { return setup_; }
    const Profile& profile() const { return profile_; }
    const RouteProfile& route() const { return route_; }
    const std::vector<wk::Step>& steps() const { return steps_; }
    const Samples& samples() const { return samples_; }
    const std::vector<Split>& splits() const { return splits_; }
    bool paused() const { return paused_; }
    bool finished() const { return finished_; }
    bool endless() const { return setup_.kind != RideKind::Route; }
    bool structured() const { return !steps_.empty(); }
    bool structuredActive() const { return !steps_.empty() && !workoutComplete_; }
    bool workoutComplete() const { return workoutComplete_; }
    bool routeComplete() const { return routeCompleteAt_.has_value(); }
    bool started() const { return activeS_ > 0; }
    double elapsedS() const { return activeS_; }
    double movingS() const { return movingS_; }
    double distance() const { return distance_; }
    double lapDistance() const;
    int lapNumber() const { return lap_; }
    int laps() const { return setup_.laps; }
    double ele() const { return ele_; }
    double gradePct() const { return grade_ * 100; }
    double trainerGradePct() const { return trainerGradePct_; }
    double difficultyValue() const { return difficulty_; }
    ControlMode mode() const { return mode_; }
    std::optional<double> targetW() const { return targetW_; }
    double speedMps() const { return speed_; }
    double power() const { return power_; }
    double power3s() const;
    double cadence() const { return cadence_; }
    std::optional<double> heartRate() const { return hr_; }
    int hrZone() const;
    double avgPower() const { return activeS_ > 0 ? kj_ * 1000 / activeS_ : 0; }
    double maxPower() const { return maxPower_; }
    double np() const { return np_; }
    double workKj() const { return kj_; }
    double calories() const;
    double gain() const { return gain_; }
    double tss() const;
    double workoutT() const { return activeS_ + offsetS_; }
    double workoutTotalS() const { return steps_.empty() ? 0 : steps_.back().endS(); }
    std::optional<std::pair<size_t, double>> currentStep() const;
    double ergBiasValue() const { return ergBias_; }
    bool ergDisabled() const { return ergDisabled_; }
    FreeMode freeMode() const { return freeMode_; }
    double freeGrade() const { return freeGradePct_; }
    double freeWattsValue() const { return freeWatts_; }
    double freeLevel() const { return freeLevelPct_; }
    double hrTargetValue() const { return hrTarget_; }
    double hrControlW() const { return hrW_; }
    const Goal& goal() const { return goal_; }
    double goalProgress() const;
    std::string goalRemaining() const;
    bool goalDone() const { return goalDone_; }
    std::optional<double> ghostGapS() const;
    std::optional<double> ghostDistance() const;
    int currentClimb() const;  // index or -1
    int nextClimb() const;
    std::optional<wk::TestResult> liveTestResult() const;
    bool testDone() const { return testDone_; }
    bool shiftingActive() const { return shiftingActive_; }
    int gear() const { return gearIdx_ + 1; }
    double gearRatio() const { return phys::VIRTUAL_GEARS[gearIdx_]; }
    double splitElapsed() const { return activeS_ - splitStartS_; }
    double splitDistance() const { return distance_ - splitStartD_; }
    double splitAvgPower() const;
    const std::vector<float>& ghostTrace() const { return setup_.ghost; }
    const std::vector<double>& workoutTSamples() const { return workoutTSamples_; }

private:
    void stepRide(double dt);
    std::optional<TrainerCommand> control(double dt);
    bool freeGradientActive() const;
    void push(const std::string& k, const std::string& m) { events_.push_back({k, m}); }
    void closeManualLap();
    std::optional<Split> makeSplit(size_t a, size_t b, const std::string& kind, const std::string& name, int idx) const;

    Profile profile_;
    phys::Params params_;
    RideSetup setup_;
    RouteProfile route_;
    std::vector<wk::Step> steps_;

    double activeS_ = 0, movingS_ = 0, offsetS_ = 0;
    bool paused_ = false, finished_ = false;
    double speed_ = 0, maxSpeed_ = 0, distance_ = 0, ele_ = 0, gain_ = 0, grade_ = 0, trainerGradePct_ = 0, difficulty_ = 1;
    double kj_ = 0, power_ = 0, cadence_ = 0, maxPower_ = 0, maxCadence_ = 0, np_ = 0;
    std::optional<double> hr_;
    bool connected_ = false;
    std::vector<std::pair<double, double>> recent_;
    struct Acc { double dt = 0, p = 0, c = 0, hr = 0, hrDt = 0, v = 0, target = 0, targetDt = 0; } acc_;
    Samples samples_;
    std::vector<double> workoutTSamples_;

    ControlMode mode_ = ControlMode::Sim;
    std::optional<double> targetW_;
    bool ergDisabled_ = false;
    double ergBias_ = 1.0;
    std::optional<TrainerCommand> lastCmd_;
    double lastCmdAt_ = -1e9, nowS_ = 0;
    bool forceCmd_ = true;

    FreeMode freeMode_ = FreeMode::Gradient;
    double freeGradePct_ = 0, freeWatts_ = 150, freeLevelPct_ = 30, hrTarget_ = 140, hrW_ = 120, hrCtrlT_ = 0;
    Goal goal_;
    bool goalDone_ = false;

    std::vector<Split> splits_;
    size_t splitStartIdx_ = 0, routeLapStartIdx_ = 0;
    double splitStartS_ = 0, splitStartD_ = 0;
    std::vector<RideEvent> events_;
    int lap_ = 1;
    std::optional<double> routeCompleteAt_;
    bool workoutComplete_ = false;
    std::optional<size_t> stepIdx_;
    std::set<int> announced_;
    double rampFailS_ = 0;
    bool testDone_ = false;
    int gearIdx_ = 9;
    double cadEma_ = 0;
    bool shiftingActive_ = false;
    std::vector<HrZone> hrZones_;
    double npTimer_ = 0;
};

std::string fmtDur(double s);
