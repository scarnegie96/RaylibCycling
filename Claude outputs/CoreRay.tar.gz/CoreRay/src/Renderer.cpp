#include "Renderer.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <thread>

#include "Shaders.h"
#include "raymath.h"
#include "rlgl.h"

static constexpr float PI_F = 3.14159265358979f;

const char* camModeName(CamMode m) {
    switch (m) {
        case CamMode::Chase: return "Chase";
        case CamMode::Close: return "Close chase";
        case CamMode::Side: return "Side";
        case CamMode::Overhead: return "Drone";
        case CamMode::FirstPerson: return "Rider view";
        case CamMode::Cinematic: return "Cinematic";
        default: return "";
    }
}

// ------------------------------------------------------------------ helpers
namespace {

struct MeshBuilder {
    std::vector<float> v, n, t;
    std::vector<unsigned char> c;
    std::vector<unsigned short> idx;
    unsigned short add(Vector3 p, Vector3 nn, Vector2 uv, Color col = WHITE) {
        v.insert(v.end(), {p.x, p.y, p.z});
        n.insert(n.end(), {nn.x, nn.y, nn.z});
        t.insert(t.end(), {uv.x, uv.y});
        c.insert(c.end(), {col.r, col.g, col.b, col.a});
        return (unsigned short)(v.size() / 3 - 1);
    }
    void tri(unsigned short a, unsigned short b, unsigned short d) { idx.insert(idx.end(), {a, b, d}); }
    Mesh build(bool colors = false) {
        Mesh m{};
        m.vertexCount = int(v.size() / 3);
        m.triangleCount = int(idx.size() / 3);
        m.vertices = (float*)MemAlloc(sizeof(float) * v.size());
        std::memcpy(m.vertices, v.data(), sizeof(float) * v.size());
        m.normals = (float*)MemAlloc(sizeof(float) * n.size());
        std::memcpy(m.normals, n.data(), sizeof(float) * n.size());
        m.texcoords = (float*)MemAlloc(sizeof(float) * t.size());
        std::memcpy(m.texcoords, t.data(), sizeof(float) * t.size());
        if (colors) {
            m.colors = (unsigned char*)MemAlloc(c.size());
            std::memcpy(m.colors, c.data(), c.size());
        }
        m.indices = (unsigned short*)MemAlloc(sizeof(unsigned short) * idx.size());
        std::memcpy(m.indices, idx.data(), sizeof(unsigned short) * idx.size());
        UploadMesh(&m, false);
        return m;
    }
};

// cone shell from y0..y1, radius r0 at y0 -> 0 at y1
void addCone(MeshBuilder& b, float r0, float y0, float y1, int slices, float wobble, uint32_t seed) {
    unsigned short tip = b.add({0, y1, 0}, {0, 1, 0}, {0.5f, 1});
    std::vector<unsigned short> ring;
    float slope = r0 / (y1 - y0);
    for (int i = 0; i <= slices; ++i) {
        float a = 2 * PI_F * i / slices;
        float r = r0 * (1.0f + wobble * (hash2(i % slices, 3, seed) - 0.5f));
        Vector3 p{std::cos(a) * r, y0, std::sin(a) * r};
        Vector3 nn = Vector3Normalize({std::cos(a), slope, std::sin(a)});
        ring.push_back(b.add(p, nn, {float(i) / slices, 0}));
    }
    for (int i = 0; i < slices; ++i) b.tri(tip, ring[i + 1], ring[i]);
    // underside
    unsigned short bc = b.add({0, y0, 0}, {0, -1, 0}, {0.5f, 0});
    std::vector<unsigned short> ring2;
    for (int i = 0; i <= slices; ++i) {
        float a = 2 * PI_F * i / slices;
        ring2.push_back(b.add({std::cos(a) * r0 * 0.95f, y0, std::sin(a) * r0 * 0.95f}, {0, -1, 0}, {0, 0}));
    }
    for (int i = 0; i < slices; ++i) b.tri(bc, ring2[i], ring2[i + 1]);
}

void addCylinder(MeshBuilder& b, float r, float y0, float y1, int slices) {
    std::vector<unsigned short> lo, hi;
    for (int i = 0; i <= slices; ++i) {
        float a = 2 * PI_F * i / slices;
        Vector3 nn{std::cos(a), 0, std::sin(a)};
        lo.push_back(b.add({nn.x * r, y0, nn.z * r}, nn, {float(i) / slices, 0}));
        hi.push_back(b.add({nn.x * r * 0.8f, y1, nn.z * r * 0.8f}, nn, {float(i) / slices, 1}));
    }
    for (int i = 0; i < slices; ++i) { b.tri(lo[i], hi[i + 1], lo[i + 1]); b.tri(lo[i], hi[i], hi[i + 1]); }
}

// lumpy sphere (broadleaf crowns, rocks)
void addBlob(MeshBuilder& b, Vector3 c, Vector3 r, int rings, int slices, float lump, uint32_t seed) {
    std::vector<std::vector<unsigned short>> grid(rings + 1);
    for (int i = 0; i <= rings; ++i) {
        float th = PI_F * i / rings;
        for (int j = 0; j <= slices; ++j) {
            float ph = 2 * PI_F * j / slices;
            Vector3 d{std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph)};
            float k = 1.0f + lump * (vnoise(d.x * 2.3f + 5, d.z * 2.3f + d.y * 1.7f + 3, seed) - 0.5f) * 2.f;
            Vector3 p{c.x + d.x * r.x * k, c.y + d.y * r.y * k, c.z + d.z * r.z * k};
            grid[i].push_back(b.add(p, d, {float(j) / slices, float(i) / rings}));
        }
    }
    for (int i = 0; i < rings; ++i)
        for (int j = 0; j < slices; ++j) {
            b.tri(grid[i][j], grid[i][j + 1], grid[i + 1][j]);
            b.tri(grid[i][j + 1], grid[i + 1][j + 1], grid[i + 1][j]);
        }
}

// torus around the X axis (bike wheels)
Mesh genTorusX(float R, float r, int seg, int sides) {
    MeshBuilder b;
    for (int i = 0; i <= seg; ++i) {
        float a = 2 * PI_F * i / seg;
        Vector3 dir{0, std::cos(a), std::sin(a)};
        for (int j = 0; j <= sides; ++j) {
            float t = 2 * PI_F * j / sides;
            Vector3 nn{std::sin(t), dir.y * std::cos(t), dir.z * std::cos(t)};
            Vector3 p{nn.x * r, dir.y * R + nn.y * r, dir.z * R + nn.z * r};
            b.add(p, nn, {float(i) / seg, float(j) / sides});
        }
    }
    for (int i = 0; i < seg; ++i)
        for (int j = 0; j < sides; ++j) {
            unsigned short a = i * (sides + 1) + j, bb = (i + 1) * (sides + 1) + j;
            b.tri(a, bb, a + 1);
            b.tri(a + 1, bb, bb + 1);
        }
    return b.build();
}

Shader loadShader(const char* vs, const std::string& fs, const char* label) {
    Shader s = LoadShaderFromMemory(vs, fs.c_str());
    if (s.id == rlGetShaderIdDefault()) std::fprintf(stderr, "[render] shader '%s' failed to compile\n", label);
    return s;
}

void setF(Shader s, const char* n, float v) { int l = GetShaderLocation(s, n); if (l >= 0) SetShaderValue(s, l, &v, SHADER_UNIFORM_FLOAT); }
void setI(Shader s, const char* n, int v) { int l = GetShaderLocation(s, n); if (l >= 0) SetShaderValue(s, l, &v, SHADER_UNIFORM_INT); }
void setV2(Shader s, const char* n, Vector2 v) { int l = GetShaderLocation(s, n); if (l >= 0) SetShaderValue(s, l, &v, SHADER_UNIFORM_VEC2); }
void setV3(Shader s, const char* n, Vector3 v) { int l = GetShaderLocation(s, n); if (l >= 0) SetShaderValue(s, l, &v, SHADER_UNIFORM_VEC3); }
void setM(Shader s, const char* n, Matrix m) { int l = GetShaderLocation(s, n); if (l >= 0) SetShaderValueMatrix(s, l, m); }

RenderTexture2D loadRT(int w, int h, int format, bool depth) {
    RenderTexture2D t{};
    t.id = rlLoadFramebuffer();
    rlEnableFramebuffer(t.id);
    t.texture.id = rlLoadTexture(nullptr, w, h, format, 1);
    t.texture.width = w; t.texture.height = h; t.texture.format = format; t.texture.mipmaps = 1;
    rlFramebufferAttach(t.id, t.texture.id, RL_ATTACHMENT_COLOR_CHANNEL0, RL_ATTACHMENT_TEXTURE2D, 0);
    if (depth) {
        t.depth.id = rlLoadTextureDepth(w, h, true);
        t.depth.width = w; t.depth.height = h;
        rlFramebufferAttach(t.id, t.depth.id, RL_ATTACHMENT_DEPTH, RL_ATTACHMENT_RENDERBUFFER, 0);
    }
    if (!rlFramebufferComplete(t.id)) std::fprintf(stderr, "[render] framebuffer %dx%d incomplete\n", w, h);
    rlDisableFramebuffer();
    SetTextureFilter(t.texture, TEXTURE_FILTER_BILINEAR);
    SetTextureWrap(t.texture, TEXTURE_WRAP_CLAMP);
    return t;
}

RenderTexture2D loadShadowRT(int res) {
    RenderTexture2D t{};
    t.id = rlLoadFramebuffer();
    t.texture.width = res; t.texture.height = res;
    rlEnableFramebuffer(t.id);
    t.depth.id = rlLoadTextureDepth(res, res, false);
    t.depth.width = res; t.depth.height = res; t.depth.format = 19; t.depth.mipmaps = 1;
    rlFramebufferAttach(t.id, t.depth.id, RL_ATTACHMENT_DEPTH, RL_ATTACHMENT_TEXTURE2D, 0);
    if (!rlFramebufferComplete(t.id)) std::fprintf(stderr, "[render] shadow framebuffer incomplete\n");
    rlDisableFramebuffer();
    return t;
}

void unloadRT(RenderTexture2D& t) {
    if (t.id == 0) return;
    if (t.texture.id) rlUnloadTexture(t.texture.id);
    if (t.depth.id) rlUnloadTexture(t.depth.id);  // also handles renderbuffers in rlgl
    rlUnloadFramebuffer(t.id);
    t = RenderTexture2D{};
}

void blit(const RenderTexture2D& src, const RenderTexture2D& dst) {
    DrawTexturePro(src.texture, {0, 0, float(src.texture.width), -float(src.texture.height)},
                   {0, 0, float(dst.texture.width), float(dst.texture.height)}, {0, 0}, 0, WHITE);
}

float smooth(float a, float b, float x) { float t = std::clamp((x - a) / (b - a), 0.f, 1.f); return t * t * (3 - 2 * t); }

Vector3 toV(const V3& v) { return {v.x, v.y, v.z}; }
Vector3 fwdOf(float h) { return {std::sin(h), 0, std::cos(h)}; }
Vector3 rightOf(float h) { return {-std::cos(h), 0, std::sin(h)}; }

Material makeMat(Shader s) { Material m = LoadMaterialDefault(); m.shader = s; return m; }

// align +Y unit primitive between a and b
Matrix alignY(Vector3 a, Vector3 b, float rx, float rz) {
    Vector3 d = Vector3Subtract(b, a);
    float len = Vector3Length(d);
    if (len < 1e-5f) return MatrixTranslate(a.x, a.y, a.z);
    Vector3 dir = Vector3Scale(d, 1.f / len);
    Vector3 up{0, 1, 0};
    Matrix rot;
    float dt = Vector3DotProduct(up, dir);
    if (dt > 0.9999f) rot = MatrixIdentity();
    else if (dt < -0.9999f) rot = MatrixRotateX(PI_F);
    else rot = MatrixRotate(Vector3Normalize(Vector3CrossProduct(up, dir)), std::acos(dt));
    return MatrixMultiply(MatrixMultiply(MatrixScale(rx, len, rz), rot), MatrixTranslate(a.x, a.y, a.z));
}

// two-bone IK, returns joint position; pole = preferred bend direction
Vector3 ik(Vector3 root, Vector3 end, float l1, float l2, Vector3 pole) {
    Vector3 d = Vector3Subtract(end, root);
    float dist = std::clamp(Vector3Length(d), 0.05f, l1 + l2 - 0.001f);
    Vector3 dir = Vector3Normalize(d);
    float a = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist);
    float h = std::sqrt(std::max(0.f, l1 * l1 - a * a));
    Vector3 p = Vector3Subtract(pole, Vector3Scale(dir, Vector3DotProduct(pole, dir)));
    p = Vector3Normalize(p);
    return Vector3Add(Vector3Add(root, Vector3Scale(dir, a)), Vector3Scale(p, h));
}

}  // namespace

// ------------------------------------------------------------------ init
bool Renderer::init(const Course& course, int quality) {
    course_ = &course;
    quality_ = quality;
    shadowRes_ = quality >= 2 ? 4096 : quality == 1 ? 2048 : 1024;

    std::string head = shaders::FS_HEADER, common = shaders::FS_COMMON;
    terrainSh_ = loadShader(shaders::VS_STATIC, head + common + shaders::FS_TERRAIN, "terrain");
    roadSh_ = loadShader(shaders::VS_STATIC, head + common + shaders::FS_ROAD, "road");
    objectSh_ = loadShader(shaders::VS_STATIC, head + common + shaders::FS_OBJECT, "object");
    waterSh_ = loadShader(shaders::VS_STATIC, head + common + shaders::FS_WATER, "water");
    skySh_ = loadShader(shaders::VS_STATIC, head + common + shaders::FS_SKY, "sky");
    foliageSh_ = loadShader(shaders::VS_INSTANCED, head + common + shaders::FS_FOLIAGE, "foliage");
    foliageSh_.locs[SHADER_LOC_MATRIX_MODEL] = GetShaderLocationAttrib(foliageSh_, "instanceTransform");
    depthSh_ = loadShader(shaders::VS_DEPTH, shaders::FS_DEPTH, "depth");
    depthInstSh_ = loadShader(shaders::VS_DEPTH_INSTANCED, shaders::FS_DEPTH, "depth-inst");
    depthInstSh_.locs[SHADER_LOC_MATRIX_MODEL] = GetShaderLocationAttrib(depthInstSh_, "instanceTransform");
    std::string ph = shaders::FS_POST_HEADER;
    brightSh_ = loadShader(nullptr, ph + shaders::FS_BRIGHT, "bright");
    blurSh_ = loadShader(nullptr, ph + shaders::FS_BLUR, "blur");
    compositeSh_ = loadShader(nullptr, ph + shaders::FS_HASH + shaders::FS_COMPOSITE, "composite");
    fxaaSh_ = loadShader(nullptr, ph + shaders::FS_FXAA, "fxaa");

    terrainMat_ = makeMat(terrainSh_); roadMat_ = makeMat(roadSh_); objectMat_ = makeMat(objectSh_);
    waterMat_ = makeMat(waterSh_); skyMat_ = makeMat(skySh_); foliageMat_ = makeMat(foliageSh_);
    depthMat_ = makeMat(depthSh_); depthInstMat_ = makeMat(depthInstSh_);

    cyl_ = GenMeshCylinder(1, 1, 12);
    sphere_ = GenMeshSphere(1, 14, 18);
    cube_ = GenMeshCube(1, 1, 1);
    cone_ = GenMeshCone(1, 1, 12);
    wheelTire_ = genTorusX(0.333f, 0.0135f, 48, 8);
    wheelRim_ = genTorusX(0.30f, 0.02f, 48, 6);
    skyDome_ = GenMeshSphere(1, 24, 32);

    buildTerrain();
    buildRoad();
    buildVegetation();
    buildProps();
    for (int i = 0; i < 2; ++i) shadow_[i] = loadShadowRT(shadowRes_);
    setTimeOfDay(todIndex_);
    return true;
}

void Renderer::shutdown() {
    destroyTargets();
    for (auto& r : shadow_) unloadRT(r);
    for (auto& c : terrain_) UnloadMesh(c.mesh);
    for (auto& c : road_) UnloadMesh(c.mesh);
    terrain_.clear(); road_.clear();
    conifers_ = {}; broadleaf_ = {}; rocks_ = {}; signposts_.clear();
    camInit_ = false;
    for (Mesh* m : {&water_, &skyDome_, &cyl_, &sphere_, &cube_, &cone_, &wheelTire_, &wheelRim_, &treeCone_, &treeBlob_, &treeTrunk_, &rockMesh_})
        if (m->vaoId) UnloadMesh(*m);
    for (Shader s : {terrainSh_, roadSh_, objectSh_, foliageSh_, waterSh_, skySh_, depthSh_, depthInstSh_, brightSh_, blurSh_, compositeSh_, fxaaSh_})
        UnloadShader(s);
}

void Renderer::setQuality(int q) {
    if (q == quality_) return;
    quality_ = q;
    int res = q >= 2 ? 4096 : q == 1 ? 2048 : 1024;
    if (res != shadowRes_) {
        for (auto& r : shadow_) unloadRT(r);
        shadowRes_ = res;
        for (auto& r : shadow_) r = loadShadowRT(shadowRes_);
    }
}

void Renderer::setTimeOfDay(int p) {
    todIndex_ = ((p % 4) + 4) % 4;
    auto sunFrom = [](float elevDeg, float azDeg) {
        float e = elevDeg * DEG2RAD, a = azDeg * DEG2RAD;
        return Vector3Normalize({std::cos(e) * std::sin(a), std::sin(e), std::cos(e) * std::cos(a)});
    };
    switch (todIndex_) {
        case 0:  // morning
            tod_ = {sunFrom(16, 70), {2.9f, 2.35f, 1.75f}, {0.16f, 0.30f, 0.62f}, {0.78f, 0.80f, 0.82f}, {0.22f, 0.20f, 0.16f},
                    0.55f, 1.f / 3800.f, 0.9f, 0.35f};
            break;
        case 1:  // midday
            tod_ = {sunFrom(48, 140), {3.1f, 2.95f, 2.7f}, {0.14f, 0.30f, 0.68f}, {0.60f, 0.72f, 0.88f}, {0.24f, 0.22f, 0.17f},
                    0.55f, 1.f / 5200.f, 0.78f, 0.45f};
            break;
        case 2:  // golden hour
            tod_ = {sunFrom(8, 250), {3.4f, 2.1f, 1.05f}, {0.14f, 0.22f, 0.48f}, {0.95f, 0.66f, 0.45f}, {0.25f, 0.18f, 0.12f},
                    0.45f, 1.f / 3600.f, 0.95f, 0.4f};
            break;
        default:  // overcast
            tod_ = {sunFrom(38, 200), {1.3f, 1.3f, 1.35f}, {0.45f, 0.50f, 0.56f}, {0.70f, 0.72f, 0.75f}, {0.22f, 0.22f, 0.20f},
                    1.15f, 1.f / 2600.f, 1.0f, 0.85f};
            break;
    }
}

// ------------------------------------------------------------------ world building
static std::vector<float> g_heights;  // terrain height grid (shared by vegetation placement)
static int g_hn = 0;
static float g_hmin = 0, g_hstep = 1;

static float sampleGrid(float x, float z) {
    float fx = (x - g_hmin) / g_hstep, fz = (z - g_hmin) / g_hstep;
    int ix = std::clamp(int(fx), 0, g_hn - 2), iz = std::clamp(int(fz), 0, g_hn - 2);
    float tx = std::clamp(fx - ix, 0.f, 1.f), tz = std::clamp(fz - iz, 0.f, 1.f);
    auto H = [&](int a, int b) { return g_heights[size_t(b) * g_hn + a]; };
    return (H(ix, iz) * (1 - tx) + H(ix + 1, iz) * tx) * (1 - tz) + (H(ix, iz + 1) * (1 - tx) + H(ix + 1, iz + 1) * tx) * tz;
}

void Renderer::buildTerrain() {
    const int Q = quality_ >= 2 ? 768 : quality_ == 1 ? 576 : 384;  // quads per side (multiple of 32... 576=18*32)
    const int CH = 32;
    const float E = course_->extent();
    const float step = 2 * E / Q;
    const int N = Q + 1;
    g_hn = N; g_hmin = -E; g_hstep = step;
    g_heights.assign(size_t(N) * N, 0);
    std::vector<float> shoulder(size_t(N) * N, 0);

    unsigned nt = std::max(2u, std::thread::hardware_concurrency());
    std::vector<std::thread> th;
    for (unsigned t = 0; t < nt; ++t)
        th.emplace_back([&, t] {
            for (int z = int(t); z < N; z += int(nt))
                for (int x = 0; x < N; ++x) {
                    float wx = -E + x * step, wz = -E + z * step;
                    g_heights[size_t(z) * N + x] = course_->terrainHeight(wx, wz);
                    float d = course_->roadDistance(wx, wz);
                    shoulder[size_t(z) * N + x] = 1.f - smooth(course_->roadHalfWidth() + 1.f, 11.f, d);
                }
        });
    for (auto& t : th) t.join();

    auto H = [&](int x, int z) { x = std::clamp(x, 0, N - 1); z = std::clamp(z, 0, N - 1); return g_heights[size_t(z) * N + x]; };
    for (int cz = 0; cz < Q / CH; ++cz)
        for (int cx = 0; cx < Q / CH; ++cx) {
            MeshBuilder b;
            float minY = 1e9f, maxY = -1e9f;
            for (int z = 0; z <= CH; ++z)
                for (int x = 0; x <= CH; ++x) {
                    int gx = cx * CH + x, gz = cz * CH + z;
                    float y = H(gx, gz);
                    minY = std::min(minY, y); maxY = std::max(maxY, y);
                    Vector3 nn = Vector3Normalize({H(gx - 1, gz) - H(gx + 1, gz), 2 * step, H(gx, gz - 1) - H(gx, gz + 1)});
                    unsigned char sh = (unsigned char)(std::clamp(shoulder[size_t(gz) * N + gx], 0.f, 1.f) * 255);
                    b.add({-E + gx * step, y, -E + gz * step}, nn, {float(gx) / Q, float(gz) / Q}, {sh, 0, 0, 255});
                }
            for (int z = 0; z < CH; ++z)
                for (int x = 0; x < CH; ++x) {
                    unsigned short a = z * (CH + 1) + x, bb = (z + 1) * (CH + 1) + x;
                    b.tri(a, bb, a + 1);
                    b.tri(a + 1, bb, bb + 1);
                }
            Chunk c;
            c.mesh = b.build(true);
            float half = CH * step * 0.5f;
            c.center = {-E + (cx * CH) * step + half, (minY + maxY) * 0.5f, -E + (cz * CH) * step + half};
            c.radius = std::sqrt(2 * half * half + (maxY - minY) * (maxY - minY) * 0.25f);
            terrain_.push_back(c);
        }
    water_ = GenMeshPlane(4 * E, 4 * E, 4, 4);
}

void Renderer::buildRoad() {
    const auto& P = course_->points();
    const int N = int(P.size());
    const float hw = course_->roadHalfWidth();
    const int per = 400;
    for (int start = 0; start < N; start += per) {
        MeshBuilder b;
        int end = std::min(N, start + per);
        Vector3 cmin{1e9f, 1e9f, 1e9f}, cmax{-1e9f, -1e9f, -1e9f};
        for (int i = start; i <= end; ++i) {
            const auto& p = P[i % N];
            Vector3 r = rightOf(p.heading);
            Vector3 f = Vector3Normalize({std::sin(p.heading), p.grade, std::cos(p.heading)});
            Vector3 nn = Vector3Normalize(Vector3CrossProduct(r, f));
            Vector3 c = toV(p.pos);
            c.y += 0.03f;
            float v = (i == N) ? course_->length() : p.dist;
            Vector3 L = Vector3Subtract(c, Vector3Scale(r, hw)), R = Vector3Add(c, Vector3Scale(r, hw));
            b.add(L, nn, {0, v});
            b.add(R, nn, {1, v});
            cmin = Vector3Min(cmin, c); cmax = Vector3Max(cmax, c);
        }
        int rows = end - start + 1;
        for (int i = 0; i < rows - 1; ++i) {
            unsigned short a = i * 2, bb = i * 2 + 1, c = (i + 1) * 2, d = (i + 1) * 2 + 1;
            b.tri(a, bb, c);
            b.tri(c, bb, d);
        }
        Chunk ch;
        ch.mesh = b.build();
        ch.center = Vector3Scale(Vector3Add(cmin, cmax), 0.5f);
        ch.radius = Vector3Distance(cmin, cmax) * 0.5f + hw;
        road_.push_back(ch);
    }
}

void Renderer::buildVegetation() {
    {   // conifer: 3 stacked cones + no trunk (trunk separate)
        MeshBuilder b;
        addCone(b, 0.42f, 0.12f, 0.62f, 9, 0.25f, 1);
        addCone(b, 0.34f, 0.38f, 0.84f, 9, 0.25f, 2);
        addCone(b, 0.24f, 0.62f, 1.0f, 8, 0.25f, 3);
        treeCone_ = b.build();
    }
    {
        MeshBuilder b;
        addBlob(b, {0, 0.62f, 0}, {0.42f, 0.36f, 0.42f}, 8, 12, 0.35f, 5);
        addBlob(b, {0.18f, 0.8f, 0.05f}, {0.25f, 0.22f, 0.25f}, 6, 10, 0.3f, 6);
        treeBlob_ = b.build();
    }
    {
        MeshBuilder b;
        addCylinder(b, 0.045f, 0.0f, 0.45f, 6);
        treeTrunk_ = b.build();
    }
    {
        MeshBuilder b;
        addBlob(b, {0, 0.25f, 0}, {1.0f, 0.55f, 0.85f}, 6, 9, 0.45f, 9);
        rockMesh_ = b.build();
    }

    const float E = course_->extent();
    const float water = course_->waterLevel();
    const float snow = course_->maxElevation() + 120.f;
    const float spacing = quality_ >= 2 ? 7.f : quality_ == 1 ? 9.f : 12.f;
    std::mt19937 rng(1234);
    std::uniform_real_distribution<float> U(0, 1);
    for (float z = -E + 50; z < E - 50; z += spacing)
        for (float x = -E + 50; x < E - 50; x += spacing) {
            float jx = x + (U(rng) - 0.5f) * spacing * 0.9f, jz = z + (U(rng) - 0.5f) * spacing * 0.9f;
            float forest = fbm(jx * 0.0035f, jz * 0.0035f, 4, 77);
            float p = smooth(0.48f, 0.62f, forest) * 0.8f + 0.015f;
            float roll = U(rng);
            bool rock = roll > 0.997f;
            if (roll > p && !rock) continue;
            float y = sampleGrid(jx, jz);
            if (y < water + 1.2f || y > snow - 30.f) continue;
            float sx = sampleGrid(jx + 3, jz) - sampleGrid(jx - 3, jz), sz = sampleGrid(jx, jz + 3) - sampleGrid(jx, jz - 3);
            float slope = std::sqrt(sx * sx + sz * sz) / 6.f;
            if (slope > (rock ? 1.2f : 0.75f)) continue;
            float rd = course_->roadDistance(jx, jz);
            if (rd < course_->roadHalfWidth() + (rock ? 5.f : 6.5f)) continue;
            float rot = U(rng) * 2 * PI_F;
            if (rock) {
                float s = 0.6f + U(rng) * 2.2f;
                Matrix m = MatrixMultiply(MatrixMultiply(MatrixScale(s, s * (0.7f + U(rng) * 0.5f), s), MatrixRotateY(rot)),
                                          MatrixTranslate(jx, y - 0.25f * s, jz));
                rocks_.all.push_back(m); rocks_.pos.push_back({jx, y, jz});
                continue;
            }
            float alt = smooth(course_->minElevation() + 10.f, course_->maxElevation() + 40.f, y);
            bool conifer = U(rng) < 0.35f + alt * 0.6f;
            float hgt = conifer ? 9.f + U(rng) * 11.f : 6.f + U(rng) * 7.f;
            float wid = hgt * (conifer ? 0.75f + U(rng) * 0.3f : 0.9f + U(rng) * 0.4f);
            Matrix m = MatrixMultiply(MatrixMultiply(MatrixScale(wid, hgt, wid), MatrixRotateY(rot)), MatrixTranslate(jx, y - 0.2f, jz));
            auto& set = conifer ? conifers_ : broadleaf_;
            set.all.push_back(m);
            set.pos.push_back({jx, y, jz});
        }
    std::fprintf(stderr, "[render] vegetation: %zu conifers, %zu broadleaf, %zu rocks\n", conifers_.all.size(),
                 broadleaf_.all.size(), rocks_.all.size());
}

void Renderer::buildProps() {
    // km signposts on the right-hand verge
    const float L = course_->length();
    for (float d = 1000.f; d < L - 200.f; d += 1000.f) {
        auto p = course_->at(d);
        Vector3 pos = Vector3Add(toV(p.pos), Vector3Scale(rightOf(p.heading), course_->roadHalfWidth() + 1.6f));
        pos.y = course_->terrainHeight(pos.x, pos.z);
        signposts_.push_back(MatrixMultiply(MatrixRotateY(p.heading), MatrixTranslate(pos.x, pos.y, pos.z)));
    }
    auto p0 = course_->at(0);
    archBase_ = MatrixMultiply(MatrixRotateY(p0.heading), MatrixTranslate(p0.pos.x, p0.pos.y, p0.pos.z));
}

// ------------------------------------------------------------------ targets
void Renderer::createTargets() {
    rtW_ = std::max(16, GetRenderWidth());
    rtH_ = std::max(16, GetRenderHeight());
    const int HDR = PIXELFORMAT_UNCOMPRESSED_R16G16B16A16;
    scene_ = loadRT(rtW_, rtH_, HDR, true);
    bright_ = loadRT(rtW_ / 2, rtH_ / 2, HDR, false);
    blurA_ = loadRT(rtW_ / 2, rtH_ / 2, HDR, false);
    blurB_ = loadRT(rtW_ / 2, rtH_ / 2, HDR, false);
    qA_ = loadRT(rtW_ / 8, rtH_ / 8, HDR, false);
    qB_ = loadRT(rtW_ / 8, rtH_ / 8, HDR, false);
    ldr_ = loadRT(rtW_, rtH_, PIXELFORMAT_UNCOMPRESSED_R8G8B8A8, false);
}

void Renderer::destroyTargets() {
    for (RenderTexture2D* r : {&scene_, &bright_, &blurA_, &blurB_, &qA_, &qB_, &ldr_}) unloadRT(*r);
    rtW_ = rtH_ = 0;
}

// ------------------------------------------------------------------ camera
void Renderer::updateCamera(const SceneState& s, float dt) {
    const Course& C = *course_;
    auto rp = C.at(s.dist);
    Vector3 rider = Vector3Add(toV(rp.pos), Vector3Scale(rightOf(rp.heading), 1.4f));
    Vector3 pos, target;
    float fov = 55.f;
    auto onRoad = [&](double d, float lateral, float up) {
        auto q = C.at(d);
        Vector3 v = Vector3Add(toV(q.pos), Vector3Scale(rightOf(q.heading), lateral));
        v.y += up;
        return v;
    };
    CamMode mode = s.cam;
    if (mode == CamMode::Cinematic) {
        cineTimer_ += dt;
        if (cineTimer_ > 9.f) { cineTimer_ = 0; cineShot_ = (cineShot_ + 1) % 4; camInit_ = false; }
        static const CamMode shots[4] = {CamMode::Side, CamMode::Overhead, CamMode::Close, CamMode::Chase};
        if (cineShot_ == 0) {
            // roadside tripod shot: fixed point ahead, rider rides past
            static double anchor = -1;
            if (cineTimer_ < dt * 1.5f || anchor < 0 || s.dist - anchor > 25) anchor = s.dist + 45;
            Vector3 a = onRoad(anchor, 9.f, 0);
            a.y = C.terrainHeight(a.x, a.z) + 1.6f;
            pos = a;
            target = Vector3Add(rider, {0, 1.0f, 0});
            fov = 38.f;
            camPosSmooth_ = pos; camTargetSmooth_ = target; camInit_ = true;
            cam_ = {pos, target, {0, 1, 0}, fov, CAMERA_PERSPECTIVE};
            return;
        }
        mode = shots[cineShot_];
        if (mode == CamMode::Overhead) {
            float a = float(s.time) * 0.12f;
            pos = Vector3Add(rider, {std::cos(a) * 18.f, 9.f, std::sin(a) * 18.f});
            target = Vector3Add(rider, {0, 1.0f, 0});
            float g = C.terrainHeight(pos.x, pos.z) + 2.f;
            pos.y = std::max(pos.y, g);
            camPosSmooth_ = pos; camTargetSmooth_ = target; camInit_ = true;
            cam_ = {pos, target, {0, 1, 0}, 50.f, CAMERA_PERSPECTIVE};
            return;
        }
    }
    switch (mode) {
        case CamMode::Close:
            pos = onRoad(s.dist - 3.0, 1.6f, 1.45f);
            target = Vector3Add(onRoad(s.dist + 2.5, 1.4f, 0), {0, 1.05f, 0});
            fov = 60.f;
            break;
        case CamMode::Side: {
            Vector3 r = rightOf(rp.heading);
            pos = Vector3Add(rider, Vector3Add(Vector3Scale(r, -4.2f), {0, 1.2f, 0}));
            pos = Vector3Add(pos, Vector3Scale(fwdOf(rp.heading), 0.6f));
            target = Vector3Add(rider, {0, 0.85f, 0});
            fov = 50.f;
            break;
        }
        case CamMode::Overhead:
            pos = onRoad(s.dist - 22, 1.4f, 20.f);
            target = Vector3Add(onRoad(s.dist + 6, 1.4f, 0), {0, 0.5f, 0});
            fov = 50.f;
            break;
        case CamMode::FirstPerson: {
            Vector3 f = fwdOf(rp.heading);
            pos = Vector3Add(rider, Vector3Add(Vector3Scale(f, 0.35f), {0, 1.62f, 0}));
            target = Vector3Add(onRoad(s.dist + 30, 1.4f, 0), {0, 1.2f, 0});
            fov = 70.f;
            break;
        }
        default:
            pos = onRoad(s.dist - 6.5, 1.3f, 2.3f);
            target = Vector3Add(onRoad(s.dist + 4, 1.4f, 0), {0, 1.0f, 0});
            fov = 55.f;
            break;
    }
    float ground = C.terrainHeight(pos.x, pos.z) + 0.9f;
    pos.y = std::max(pos.y, ground);
    if (!camInit_ || mode == CamMode::FirstPerson) { camPosSmooth_ = pos; camTargetSmooth_ = target; camInit_ = true; }
    float k = 1.f - std::exp(-dt * 6.f);
    camPosSmooth_ = Vector3Lerp(camPosSmooth_, pos, k);
    camTargetSmooth_ = Vector3Lerp(camTargetSmooth_, target, std::min(1.f, k * 1.6f));
    cam_.position = camPosSmooth_;
    cam_.target = camTargetSmooth_;
    cam_.up = {0, 1, 0};
    cam_.fovy = cam_.fovy > 1 ? cam_.fovy + (fov - cam_.fovy) * k : fov;
    cam_.projection = CAMERA_PERSPECTIVE;
}

// ------------------------------------------------------------------ uniforms
void Renderer::setCommonUniforms(Shader sh) {
    setV3(sh, "camPos", cam_.position);
    setV3(sh, "sunDir", tod_.sunDir);
    setV3(sh, "sunColor", tod_.sunColor);
    setV3(sh, "skyZenith", tod_.zenith);
    setV3(sh, "skyHorizon", tod_.horizon);
    setV3(sh, "groundColor", tod_.ground);
    setF(sh, "ambient", tod_.ambient);
    setF(sh, "fogDensity", tod_.fog);
    setF(sh, "time", time_);
    setI(sh, "shadowMap0", 10);
    setI(sh, "shadowMap1", 11);
    setM(sh, "lightVP0", lightVP_[0]);
    setM(sh, "lightVP1", lightVP_[1]);
    setV2(sh, "shadowTexel", {1.f / shadowRes_, 1.f / shadowRes_});
    setV2(sh, "cascadeRange", {cascadeRange_[0], cascadeRange_[1]});
    Vector3 f = Vector3Subtract(cam_.target, cam_.position);
    f.y = 0;
    f = Vector3Normalize(f);
    setV3(sh, "cascadeCenter0", Vector3Add(cam_.position, Vector3Scale(f, cascadeRange_[0] * 0.55f)));
    setV3(sh, "cascadeCenter1", Vector3Add(cam_.position, Vector3Scale(f, cascadeRange_[1] * 0.55f)));
    setI(sh, "shadowsOn", 1);
    setF(sh, "waterLevel", course_->waterLevel());
    setF(sh, "snowLine", course_->maxElevation() + 120.f);
    setF(sh, "cloudCover", tod_.clouds);
}

// ------------------------------------------------------------------ drawing
void Renderer::drawPart(const Mesh& m, Matrix local, const Matrix& base, Color c, float rough, float spec, bool shadowPass, int pattern, float emissive) {
    Matrix world = MatrixMultiply(local, base);
    if (shadowPass) { DrawMesh(m, depthMat_, world); return; }
    objectMat_.maps[MATERIAL_MAP_DIFFUSE].color = c;
    setF(objectSh_, "roughness", rough);
    setF(objectSh_, "specular", spec);
    setI(objectSh_, "pattern", pattern);
    setF(objectSh_, "emissive", emissive);
    DrawMesh(m, objectMat_, world);
}

void Renderer::drawLimb(Vector3 a, Vector3 b, float r, const Matrix& base, Color c, bool shadowPass, float rough, float spec) {
    drawPart(cyl_, alignY(a, b, r, r), base, c, rough, spec, shadowPass);
    drawPart(sphere_, MatrixMultiply(MatrixScale(r, r, r), MatrixTranslate(b.x, b.y, b.z)), base, c, rough, spec, shadowPass);
}

void Renderer::drawRider(const Matrix& base, const SceneState& s, bool ghost, bool sp) {
    const Color frame = ghost ? Color{90, 150, 255, 255} : Color{28, 30, 36, 255};
    const Color accent = ghost ? Color{120, 190, 255, 255} : Color{235, 70, 50, 255};
    const Color jersey = ghost ? Color{80, 160, 255, 255} : Color{232, 64, 48, 255};
    const Color jersey2 = ghost ? Color{60, 120, 220, 255} : Color{245, 245, 245, 255};
    const Color shorts{22, 22, 26, 255};
    const Color skin = ghost ? Color{120, 180, 255, 255} : Color{214, 160, 128, 255};
    const Color tire{18, 18, 18, 255};
    const Color metal{170, 172, 178, 255};
    const float em = ghost ? 0.35f : 0.f;

    // ---- bike
    Vector3 rearAxle{0, 0.335f, -0.405f}, frontAxle{0, 0.335f, 0.60f}, bb{0, 0.275f, 0};
    Vector3 seatTop{0, 0.83f, -0.155f}, headTop{0, 0.87f, 0.475f}, headBot{0, 0.71f, 0.515f};
    Vector3 saddle{0, 0.93f, -0.19f};
    float tr = 0.016f;
    drawLimb(bb, seatTop, tr * 1.2f, base, frame, sp, 0.35f, 0.6f);
    drawLimb(seatTop, headTop, tr, base, frame, sp, 0.35f, 0.6f);
    drawLimb(bb, headBot, tr * 1.4f, base, accent, sp, 0.35f, 0.6f);
    drawLimb(headBot, headTop, tr * 1.3f, base, frame, sp, 0.35f, 0.6f);
    for (float x : {-0.055f, 0.055f}) {
        drawLimb({x, bb.y, bb.z}, {x, rearAxle.y, rearAxle.z}, tr * 0.75f, base, frame, sp, 0.35f, 0.6f);
        drawLimb({x * 0.4f, 0.80f, -0.15f}, {x, rearAxle.y, rearAxle.z}, tr * 0.7f, base, frame, sp, 0.35f, 0.6f);
        drawLimb({x * 0.6f, headBot.y, headBot.z}, {x, frontAxle.y, frontAxle.z}, tr * 0.8f, base, frame, sp, 0.35f, 0.6f);
    }
    drawLimb(seatTop, {0, saddle.y - 0.02f, saddle.z + 0.01f}, 0.012f, base, frame, sp);
    drawPart(cube_, MatrixMultiply(MatrixScale(0.13f, 0.035f, 0.27f), MatrixTranslate(saddle.x, saddle.y, saddle.z)), base, {15, 15, 15, 255}, 0.6f, 0.3f, sp);
    // stem + bars
    Vector3 stemEnd{0, 0.91f, 0.57f};
    drawLimb(headTop, stemEnd, 0.014f, base, frame, sp);
    drawPart(cyl_, alignY({-0.21f, stemEnd.y, stemEnd.z}, {0.21f, stemEnd.y, stemEnd.z}, 0.012f, 0.012f), base, frame, 0.5f, 0.4f, sp);
    for (float x : {-0.21f, 0.21f}) {
        drawLimb({x, stemEnd.y, stemEnd.z}, {x, 0.93f, 0.66f}, 0.013f, base, frame, sp);       // hood
        drawLimb({x, stemEnd.y, stemEnd.z}, {x, 0.80f, 0.62f}, 0.012f, base, frame, sp);       // drop
        drawLimb({x, 0.80f, 0.62f}, {x, 0.78f, 0.53f}, 0.012f, base, frame, sp);
    }
    // wheels
    for (Vector3 axle : {rearAxle, frontAxle}) {
        Matrix spin = MatrixMultiply(MatrixRotateX(-float(s.wheelAngle)), MatrixTranslate(axle.x, axle.y, axle.z));
        drawPart(wheelTire_, spin, base, tire, 0.8f, 0.1f, sp);
        drawPart(wheelRim_, spin, base, ghost ? accent : Color{40, 40, 46, 255}, 0.3f, 0.7f, sp, 0, em);
        if (!sp) {
            for (int k = 0; k < 10; ++k) {
                float a = k * 2 * PI_F / 10;
                Vector3 e{(k % 2 ? 0.02f : -0.02f), std::cos(a) * 0.29f, std::sin(a) * 0.29f};
                drawPart(cyl_, MatrixMultiply(alignY({0, 0, 0}, e, 0.0022f, 0.0022f), spin), base, metal, 0.3f, 0.8f, false);
            }
        }
        drawPart(cyl_, MatrixMultiply(alignY({-0.05f, 0, 0}, {0.05f, 0, 0}, 0.02f, 0.02f), MatrixTranslate(axle.x, axle.y, axle.z)), base, metal, 0.3f, 0.8f, sp);
    }
    // drivetrain
    Matrix crankM = MatrixMultiply(MatrixRotateX(-float(s.crankAngle)), MatrixTranslate(bb.x, bb.y, bb.z));
    Matrix ring = MatrixMultiply(MatrixMultiply(MatrixScale(1, 0.33f, 0.33f), MatrixRotateX(-float(s.crankAngle))), MatrixTranslate(-0.065f, bb.y, bb.z));
    drawPart(wheelRim_, ring, base, metal, 0.3f, 0.8f, sp);
    if (!sp) drawLimb({-0.064f, bb.y, bb.z}, {-0.06f, rearAxle.y, rearAxle.z}, 0.004f, base, {60, 60, 60, 255}, false);

    // pedals (crank angle 0 = right pedal at bottom)
    Vector3 pedal[2];
    for (int side = 0; side < 2; ++side) {
        float a = float(s.crankAngle) + side * PI_F;
        float x = side == 0 ? -0.095f : 0.095f;  // right side is -X
        pedal[side] = {x, bb.y - std::cos(a) * 0.17f, bb.z + std::sin(a) * 0.17f};
        drawLimb({x * 0.75f, bb.y, bb.z}, pedal[side], 0.011f, base, metal, sp, 0.3f, 0.8f);
        (void)crankM;
    }

    // ---- rider
    float rock = std::sin(float(s.crankAngle) * 2.f) * 0.012f * (0.3f + s.effort);
    Vector3 hip = Vector3Lerp({0, 0.985f, -0.165f}, {0, 1.12f, 0.06f}, s.stand);
    Vector3 shoulder = Vector3Lerp({rock, 1.37f, 0.27f}, {rock * 2, 1.43f, 0.36f}, s.stand);
    shoulder = Vector3Lerp(shoulder, {rock, 1.21f, 0.37f}, s.tuck * (1 - s.stand));
    float hipW = 0.095f, shW = 0.19f;
    for (int side = 0; side < 2; ++side) {
        float sx = side == 0 ? -1.f : 1.f;
        Vector3 h{sx * hipW, hip.y, hip.z};
        Vector3 ankle = Vector3Add(pedal[side], {sx * 0.01f, 0.075f, -0.035f});
        Vector3 knee = ik(h, ankle, 0.43f, 0.43f, {sx * 0.12f, 0.1f, 1.f});
        drawLimb(h, knee, 0.068f, base, shorts, sp, 0.7f, 0.15f);
        drawLimb(knee, ankle, 0.048f, base, skin, sp, 0.6f, 0.2f);
        // shoe
        Vector3 toe = Vector3Add(pedal[side], {0, 0.03f, 0.10f});
        drawLimb(Vector3Add(ankle, {0, -0.02f, -0.04f}), toe, 0.04f, base, ghost ? accent : Color{240, 240, 240, 255}, sp, 0.4f, 0.4f);
    }
    // torso: ellipsoid along hip->shoulder
    Vector3 mid = Vector3Lerp(hip, shoulder, 0.5f);
    Vector3 td = Vector3Subtract(shoulder, hip);
    float tlen = Vector3Length(td);
    {
        Matrix tm = alignY(Vector3Subtract(mid, Vector3Scale(td, 0.5f)), Vector3Add(mid, Vector3Scale(td, 0.5f)), 1, 1);
        // replace cylinder alignment with sphere: scale unit sphere then translate along
        Vector3 dir = Vector3Scale(td, 1.f / tlen);
        float ang = std::acos(std::clamp(Vector3DotProduct({0, 1, 0}, dir), -1.f, 1.f));
        Matrix rot = MatrixRotate(Vector3Normalize(Vector3CrossProduct({0, 1, 0}, dir)), ang);
        tm = MatrixMultiply(MatrixMultiply(MatrixScale(0.185f, tlen * 0.56f, 0.13f), rot), MatrixTranslate(mid.x, mid.y, mid.z));
        drawPart(sphere_, tm, base, jersey, 0.75f, 0.2f, sp, 0, em);
        // jersey side panel stripe
        Matrix tm2 = MatrixMultiply(MatrixMultiply(MatrixScale(0.19f, tlen * 0.3f, 0.12f), rot), MatrixTranslate(mid.x, mid.y + 0.02f, mid.z + 0.01f));
        drawPart(sphere_, tm2, base, jersey2, 0.75f, 0.2f, sp, 0, em);
        // glutes
        drawPart(sphere_, MatrixMultiply(MatrixScale(0.17f, 0.1f, 0.13f), MatrixTranslate(hip.x, hip.y + 0.02f, hip.z - 0.01f)), base, shorts, 0.7f, 0.15f, sp);
    }
    // arms
    for (int side = 0; side < 2; ++side) {
        float sx = side == 0 ? -1.f : 1.f;
        Vector3 sh{shoulder.x + sx * shW, shoulder.y - 0.03f, shoulder.z - 0.02f};
        Vector3 hand = Vector3Lerp({sx * 0.21f, 0.955f, 0.645f}, {sx * 0.21f, 0.80f, 0.575f}, s.tuck * (1 - s.stand));
        Vector3 elbow = ik(sh, hand, 0.29f, 0.29f, {sx * 0.6f, -0.6f, -0.4f});
        drawLimb(sh, elbow, 0.05f, base, jersey, sp, 0.75f, 0.2f);
        drawLimb(elbow, hand, 0.038f, base, skin, sp, 0.6f, 0.2f);
        drawPart(sphere_, MatrixMultiply(MatrixScale(0.075f, 0.075f, 0.075f), MatrixTranslate(sh.x, sh.y, sh.z)), base, jersey, 0.75f, 0.2f, sp, 0, em);
    }
    // neck + head + helmet
    Vector3 neck{shoulder.x, shoulder.y + 0.06f, shoulder.z + 0.06f};
    Vector3 head{shoulder.x, shoulder.y + 0.17f, shoulder.z + 0.15f};
    drawLimb(Vector3Add(shoulder, {0, -0.02f, 0}), neck, 0.05f, base, skin, sp);
    drawPart(sphere_, MatrixMultiply(MatrixScale(0.088f, 0.1f, 0.1f), MatrixTranslate(head.x, head.y, head.z)), base, skin, 0.6f, 0.2f, sp);
    Matrix helm = MatrixMultiply(MatrixMultiply(MatrixScale(0.105f, 0.085f, 0.145f), MatrixRotateX(-0.35f)), MatrixTranslate(head.x, head.y + 0.05f, head.z - 0.01f));
    drawPart(sphere_, helm, base, ghost ? accent : Color{248, 248, 248, 255}, 0.3f, 0.6f, sp, 0, em);
    drawPart(sphere_, MatrixMultiply(MatrixScale(0.09f, 0.028f, 0.03f), MatrixTranslate(head.x, head.y + 0.01f, head.z + 0.085f)), base, {10, 10, 14, 255}, 0.1f, 1.0f, sp);
}

void Renderer::drawWorld(bool sp, int cascade, const Vector3& focus, float radius) {
    Vector3 camF = Vector3Normalize(Vector3Subtract(cam_.target, cam_.position));
    float cosLimit = std::cos((cam_.fovy * 0.5f * 1.9f + 8.f) * DEG2RAD);
    auto visible = [&](Vector3 c, float r) {
        if (sp) return std::fabs(c.x - focus.x) < radius + r && std::fabs(c.z - focus.z) < radius + r;
        Vector3 v = Vector3Subtract(c, cam_.position);
        float d = Vector3Length(v);
        if (d < r) return true;
        if (d - r > 8500.f) return false;
        return Vector3DotProduct(v, camF) / d > cosLimit - r / d;
    };

    // terrain
    for (auto& c : terrain_)
        if (visible(c.center, c.radius)) DrawMesh(c.mesh, sp ? depthMat_ : terrainMat_, MatrixIdentity());
    // road (no shadow casting needed: it's flat on the terrain)
    if (!sp)
        for (auto& c : road_)
            if (visible(c.center, c.radius)) DrawMesh(c.mesh, roadMat_, MatrixIdentity());

    // vegetation (instanced)
    auto drawSet = [&](Instances& set, const Mesh& top, int kind, float maxDist, bool trunk) {
        set.visible.clear();
        float md2 = maxDist * maxDist;
        for (size_t i = 0; i < set.pos.size(); ++i) {
            const Vector3& p = set.pos[i];
            if (sp) {
                if (std::fabs(p.x - focus.x) > radius + 12 || std::fabs(p.z - focus.z) > radius + 12) continue;
            } else {
                Vector3 v = Vector3Subtract(p, cam_.position);
                float d2 = v.x * v.x + v.z * v.z;
                if (d2 > md2) continue;
                float d = std::sqrt(d2) + 1e-3f;
                if (d > 25.f && Vector3DotProduct(v, camF) / d < cosLimit - 20.f / d) continue;
            }
            set.visible.push_back(set.all[i]);
        }
        if (set.visible.empty()) return;
        Material& m = sp ? depthInstMat_ : foliageMat_;
        Shader sh = m.shader;
        setF(sh, "time", time_);
        setF(sh, "windAmount", kind == 3 ? 0.f : 1.f);
        if (!sp) setI(sh, "kind", kind);
        DrawMeshInstanced(top, m, set.visible.data(), int(set.visible.size()));
        if (trunk) {
            if (!sp) setI(sh, "kind", 2);
            setF(sh, "windAmount", 0.f);
            DrawMeshInstanced(treeTrunk_, m, set.visible.data(), int(set.visible.size()));
        }
    };
    float vegDist = quality_ >= 2 ? 3200.f : quality_ == 1 ? 2200.f : 1400.f;
    drawSet(conifers_, treeCone_, 0, vegDist, true);
    drawSet(broadleaf_, treeBlob_, 1, vegDist, true);
    drawSet(rocks_, rockMesh_, 3, vegDist * 0.6f, false);

    // props
    const float hw = course_->roadHalfWidth();
    for (auto& m : signposts_) {
        Vector3 p{m.m12, m.m13, m.m14};
        if (sp ? (std::fabs(p.x - focus.x) > radius || std::fabs(p.z - focus.z) > radius) : Vector3Distance(p, cam_.position) > 900.f) continue;
        drawPart(cyl_, MatrixScale(0.06f, 2.2f, 0.06f), m, {200, 200, 200, 255}, 0.4f, 0.5f, sp);
        drawPart(cube_, MatrixMultiply(MatrixScale(0.08f, 0.6f, 0.9f), MatrixTranslate(0, 2.0f, 0)), m, {250, 200, 40, 255}, 0.5f, 0.3f, sp, 2);
    }
    {   // start / finish arch
        Vector3 p{archBase_.m12, archBase_.m13, archBase_.m14};
        bool near = sp ? (std::fabs(p.x - focus.x) < radius + 10 && std::fabs(p.z - focus.z) < radius + 10) : Vector3Distance(p, cam_.position) < 2500.f;
        if (near) {
            for (float x : {-(hw + 1.0f), hw + 1.0f}) {
                drawPart(cube_, MatrixMultiply(MatrixScale(0.5f, 6.5f, 0.5f), MatrixTranslate(x, 3.0f, 0)), archBase_, {30, 30, 36, 255}, 0.5f, 0.3f, sp);
            }
            drawPart(cube_, MatrixMultiply(MatrixScale(2 * hw + 2.5f, 1.2f, 0.3f), MatrixTranslate(0, 6.0f, 0)), archBase_, WHITE, 0.6f, 0.2f, sp, 1);
            drawPart(cube_, MatrixMultiply(MatrixScale(2 * hw + 2.6f, 0.25f, 0.35f), MatrixTranslate(0, 6.7f, 0)), archBase_, {232, 64, 48, 255}, 0.5f, 0.3f, sp, 0, 0.3f);
        }
    }
}

void Renderer::renderShadowMaps(const SceneState& s) {
    Vector3 f = Vector3Subtract(cam_.target, cam_.position);
    f.y = 0;
    f = Vector3Normalize(f);
    for (int c = 0; c < 2; ++c) {
        float range = cascadeRange_[c];
        Vector3 focus = Vector3Add(cam_.position, Vector3Scale(f, range * 0.55f));
        focus.y = course_->at(s.dist).pos.y;
        // stabilise: snap focus to shadow texel grid in light space
        Vector3 L = tod_.sunDir;
        Vector3 fwd = Vector3Negate(L);
        Vector3 r = Vector3Normalize(Vector3CrossProduct(fwd, {0, 1, 0}));
        Vector3 u = Vector3CrossProduct(r, fwd);
        float texel = 2 * range / shadowRes_;
        float cr = Vector3DotProduct(focus, r), cu = Vector3DotProduct(focus, u);
        focus = Vector3Add(focus, Vector3Add(Vector3Scale(r, std::floor(cr / texel) * texel - cr), Vector3Scale(u, std::floor(cu / texel) * texel - cu)));

        Camera3D lc{};
        lc.position = Vector3Add(focus, Vector3Scale(L, 900.f));
        lc.target = focus;
        lc.up = {0, 1, 0};
        lc.fovy = range * 2.f;
        lc.projection = CAMERA_ORTHOGRAPHIC;

        BeginTextureMode(shadow_[c]);
        ClearBackground(WHITE);
        rlClearScreenBuffers();
        rlSetClipPlanes(10.0, 2200.0);
        BeginMode3D(lc);
        Matrix v = rlGetMatrixModelview(), p = rlGetMatrixProjection();
        lightVP_[c] = MatrixMultiply(v, p);
        time_ = float(s.time);
        drawWorld(true, c, focus, range);
        // rider casts shadows in both cascades
        auto rp = course_->at(s.dist);
        Vector3 pos = Vector3Add(toV(rp.pos), Vector3Scale(rightOf(rp.heading), 1.4f));
        Matrix base = MatrixMultiply(MatrixMultiply(MatrixMultiply(MatrixRotateX(-std::atan(rp.grade)), MatrixRotateZ(s.lean + std::sin(float(s.crankAngle)) * 0.09f * s.stand)), MatrixRotateY(rp.heading)), MatrixTranslate(pos.x, pos.y, pos.z));
        drawRider(base, s, false, true);
        EndMode3D();
        EndTextureMode();
    }
}

void Renderer::postProcess() {
    // bright pass (half res)
    BeginTextureMode(bright_);
    BeginShaderMode(brightSh_);
    setV2(brightSh_, "texel", {1.f / rtW_, 1.f / rtH_});
    setF(brightSh_, "threshold", 1.6f);
    blit(scene_, bright_);
    EndShaderMode();
    EndTextureMode();
    // blur half res
    auto blurPass = [&](RenderTexture2D& src, RenderTexture2D& dst, Vector2 dir) {
        BeginTextureMode(dst);
        BeginShaderMode(blurSh_);
        setV2(blurSh_, "dir", dir);
        blit(src, dst);
        EndShaderMode();
        EndTextureMode();
    };
    float hw = 1.f / bright_.texture.width, hh = 1.f / bright_.texture.height;
    blurPass(bright_, blurB_, {hw, 0});
    blurPass(blurB_, blurA_, {0, hh});
    blurPass(blurA_, blurB_, {hw * 2, 0});
    blurPass(blurB_, blurA_, {0, hh * 2});
    // wide blur (1/8 res)
    BeginTextureMode(qA_);
    blit(blurA_, qA_);
    EndTextureMode();
    float qw = 1.f / qA_.texture.width, qh = 1.f / qA_.texture.height;
    blurPass(qA_, qB_, {qw, 0});
    blurPass(qB_, qA_, {0, qh});
    blurPass(qA_, qB_, {qw * 2, 0});
    blurPass(qB_, qA_, {0, qh * 2});

    // composite + tonemap
    Vector3 sunWorld = Vector3Add(cam_.position, Vector3Scale(tod_.sunDir, 3000.f));
    Vector2 sp = GetWorldToScreenEx(sunWorld, cam_, rtW_, rtH_);
    Vector3 camF = Vector3Normalize(Vector3Subtract(cam_.target, cam_.position));
    float facing = Vector3DotProduct(camF, tod_.sunDir);
    Vector2 suv{sp.x / rtW_, 1.f - sp.y / rtH_};
    float onScreen = 1.f - smooth(0.6f, 1.1f, std::max(std::fabs(suv.x - 0.5f), std::fabs(suv.y - 0.5f)) * 2.f * 0.5f + 0.25f);
    float sunVis = facing > 0 ? smooth(0.0f, 0.5f, facing) * onScreen : 0.f;

    BeginTextureMode(ldr_);
    BeginShaderMode(compositeSh_);
    SetShaderValueTexture(compositeSh_, GetShaderLocation(compositeSh_, "bloomA"), blurA_.texture);
    SetShaderValueTexture(compositeSh_, GetShaderLocation(compositeSh_, "bloomB"), qA_.texture);
    setV2(compositeSh_, "sunUV", suv);
    setF(compositeSh_, "sunVisible", sunVis * (todIndex_ == 3 ? 0.f : 1.f));
    setF(compositeSh_, "exposure", tod_.exposure);
    setF(compositeSh_, "bloomStrength", 0.35f);
    setF(compositeSh_, "shaftStrength", todIndex_ == 2 ? 0.9f : 0.5f);
    setF(compositeSh_, "saturation", 1.08f);
    blit(scene_, ldr_);
    EndShaderMode();
    EndTextureMode();

    // FXAA to backbuffer
    BeginShaderMode(fxaaSh_);
    setV2(fxaaSh_, "texel", {1.f / rtW_, 1.f / rtH_});
    DrawTexturePro(ldr_.texture, {0, 0, float(rtW_), -float(rtH_)}, {0, 0, float(GetScreenWidth()), float(GetScreenHeight())}, {0, 0}, 0, WHITE);
    EndShaderMode();
}

void Renderer::render(const SceneState& s, float dt) {
    if (rtW_ != GetRenderWidth() || rtH_ != GetRenderHeight()) {
        destroyTargets();
        createTargets();
    }
    time_ = float(s.time);
    updateCamera(s, dt);
    cascadeRange_[0] = 40.f;
    cascadeRange_[1] = quality_ >= 1 ? 380.f : 250.f;

    renderShadowMaps(s);

    // ---------------- main HDR pass
    BeginTextureMode(scene_);
    ClearBackground(BLACK);
    rlSetClipPlanes(0.3, 9500.0);
    BeginMode3D(cam_);

    rlActiveTextureSlot(10);
    rlEnableTexture(shadow_[0].depth.id);
    rlActiveTextureSlot(11);
    rlEnableTexture(shadow_[1].depth.id);
    rlActiveTextureSlot(0);

    for (Shader sh : {terrainSh_, roadSh_, objectSh_, foliageSh_, waterSh_, skySh_}) setCommonUniforms(sh);

    // sky dome
    rlDisableBackfaceCulling();
    rlDisableDepthMask();
    DrawMesh(skyDome_, skyMat_, MatrixMultiply(MatrixScale(5000, 5000, 5000), MatrixTranslate(cam_.position.x, cam_.position.y, cam_.position.z)));
    rlEnableDepthMask();
    rlEnableBackfaceCulling();

    drawWorld(false, 0, cam_.position, 0);
    // water
    DrawMesh(water_, waterMat_, MatrixTranslate(0, course_->waterLevel(), 0));

    // rider
    auto rp = course_->at(s.dist);
    Vector3 pos = Vector3Add(toV(rp.pos), Vector3Scale(rightOf(rp.heading), 1.4f));
    Matrix base = MatrixMultiply(MatrixMultiply(MatrixMultiply(MatrixRotateX(-std::atan(rp.grade)), MatrixRotateZ(s.lean + std::sin(float(s.crankAngle)) * 0.09f * s.stand)), MatrixRotateY(rp.heading)), MatrixTranslate(pos.x, pos.y, pos.z));
    if (s.cam != CamMode::FirstPerson) drawRider(base, s, false, false);
    else {
        // keep the bars/front wheel visible in rider view? just skip body
    }
    if (s.pacerDist >= 0) {
        auto pp = course_->at(s.pacerDist);
        Vector3 ppos = Vector3Add(toV(pp.pos), Vector3Scale(rightOf(pp.heading), -0.2f));
        Matrix pb = MatrixMultiply(MatrixMultiply(MatrixRotateX(-std::atan(pp.grade)), MatrixRotateY(pp.heading)), MatrixTranslate(ppos.x, ppos.y, ppos.z));
        SceneState ps = s;
        ps.crankAngle = s.time * 9.0;
        ps.wheelAngle = s.pacerDist / 0.335;
        drawRider(pb, ps, true, false);
    }

    rlActiveTextureSlot(10);
    rlDisableTexture();
    rlActiveTextureSlot(11);
    rlDisableTexture();
    rlActiveTextureSlot(0);
    EndMode3D();
    EndTextureMode();

    postProcess();
}
