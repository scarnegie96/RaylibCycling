#include "Course.h"

#include <algorithm>
#include <cmath>
#include <random>

static constexpr float PI = 3.14159265358979f;

float hash2(int x, int y, uint32_t seed) {
    uint32_t h = uint32_t(x) * 374761393u + uint32_t(y) * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return (h & 0xFFFFFF) / float(0x1000000);
}

float vnoise(float x, float y, uint32_t seed) {
    int xi = int(std::floor(x)), yi = int(std::floor(y));
    float fx = x - xi, fy = y - yi;
    float ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
    float a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
    float c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
    return (a + (b - a) * ux) + ((c + (d - c) * ux) - (a + (b - a) * ux)) * uy;
}

float fbm(float x, float y, int oct, uint32_t seed) {
    float sum = 0, amp = 0.5f, norm = 0;
    for (int i = 0; i < oct; ++i) {
        sum += vnoise(x, y, seed + i * 17) * amp;
        norm += amp;
        // rotate + scale each octave to hide grid artifacts
        float nx = x * 1.6f - y * 1.2f, ny = x * 1.2f + y * 1.6f;
        x = nx; y = ny;
        amp *= 0.5f;
    }
    return sum / norm;
}

static float smoothstepf(float a, float b, float x) {
    float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f);
    return t * t * (3 - 2 * t);
}

void Course::generate(int seed) {
    seed_ = uint32_t(seed) * 2654435761u + 12345u;
    std::mt19937 rng(seed_);
    std::uniform_real_distribution<float> U(0.f, 1.f);
    static const char* names[] = {"Ridgeback Loop", "Lakeside Circuit", "Pine Valley Ring", "Highland Ramble",
                                  "Granite Gap Loop", "Meadow Run", "Summit Circuit", "Foothill Figure"};
    name_ = names[((seed % 8) + 8) % 8];

    const float R = 1350.f + U(rng) * 350.f;
    const float a2 = 0.07f + U(rng) * 0.08f, a3 = 0.04f + U(rng) * 0.06f, a5 = 0.015f + U(rng) * 0.03f;
    const float p2 = U(rng) * 6.28f, p3 = U(rng) * 6.28f, p5 = U(rng) * 6.28f;
    // Elevation: a few proper climbs (asymmetric raised-cosine hills) plus small rollers.
    struct Hill { float c, up, down, h; };
    std::vector<Hill> hills;
    int nh = 2 + int(U(rng) * 2.0f);  // 2..3 climbs
    for (int j = 0; j < nh; ++j) {
        float len = 900.f + U(rng) * 2300.f;            // metres of climbing
        float g = 0.04f + U(rng) * 0.045f;              // average gradient
        float c = (j + 0.25f + U(rng) * 0.5f) / nh * 2 * PI;
        hills.push_back({c, len / R, len * (0.6f + U(rng) * 0.5f) / R, len * g});
    }
    float A[16], P[16];
    for (int k = 1; k < 16; ++k) { A[k] = (k >= 6 ? 2.5f : 6.f) * (0.3f + U(rng)) / std::pow(float(k), 0.6f); P[k] = U(rng) * 6.28f; }
    auto hillH = [&](float t) {
        float h = 0;
        for (auto& hl : hills) {
            float d = t - hl.c;
            while (d > PI) d -= 2 * PI;
            while (d < -PI) d += 2 * PI;
            // rise over `up` before the summit, fall over `down` after it
            float x = d < 0 ? -d / hl.up : d / hl.down;
            if (x < 1) h += hl.h * 0.5f * (1 + std::cos(PI * x));
        }
        for (int k = 1; k < 16; ++k) h += A[k] * std::sin(k * t + P[k]);
        return h;
    };

    // raw loop in theta
    const int M = 12000;
    std::vector<float> rx(M + 1), rz(M + 1), rh(M + 1), rs(M + 1);
    for (int i = 0; i <= M; ++i) {
        float t = 2 * PI * i / M;
        float r = R * (1 + a2 * std::sin(2 * t + p2) + a3 * std::sin(3 * t + p3) + a5 * std::sin(5 * t + p5));
        rx[i] = r * std::cos(t);
        rz[i] = r * std::sin(t);
        rh[i] = hillH(t);
        rs[i] = i == 0 ? 0 : rs[i - 1] + std::hypot(rx[i] - rx[i - 1], rz[i] - rz[i - 1]);
    }
    length_ = rs[M];

    // uniform resample every 2 m
    const float ds = 2.f;
    int N = int(length_ / ds);
    pts_.assign(N, {});
    int j = 0;
    for (int i = 0; i < N; ++i) {
        float s = i * length_ / N;
        while (j < M - 1 && rs[j + 1] < s) ++j;
        float f = (s - rs[j]) / std::max(1e-6f, rs[j + 1] - rs[j]);
        pts_[i].pos = {rx[j] + (rx[j + 1] - rx[j]) * f, rh[j] + (rh[j + 1] - rh[j]) * f, rz[j] + (rz[j + 1] - rz[j]) * f};
        pts_[i].dist = s;
    }
    // keep the steepest 100 m section under ~13 %
    const float maxGrade = 0.13f;
    auto wrap = [N](int i) { return ((i % N) + N) % N; };
    const int W = 25;  // +-50 m
    float steep = 1e-6f;
    for (int i = 0; i < N; ++i)
        steep = std::max(steep, std::fabs(pts_[wrap(i + W)].pos.y - pts_[wrap(i - W)].pos.y) / (2 * W * ds));
    float scale = std::min(1.0f, maxGrade / steep);
    for (auto& p : pts_) p.pos.y *= scale;
    minEle_ = 1e9f; maxEle_ = -1e9f;
    for (auto& p : pts_) { minEle_ = std::min(minEle_, p.pos.y); maxEle_ = std::max(maxEle_, p.pos.y); }
    for (auto& p : pts_) p.pos.y += 40.f - minEle_;
    maxEle_ += 40.f - minEle_;
    minEle_ = 40.f;

    ascent_ = 0;
    const int G = 5;  // grade over +-10 m
    for (int i = 0; i < N; ++i) {
        auto& a = pts_[wrap(i - G)].pos; auto& b = pts_[wrap(i + G)].pos;
        pts_[i].grade = (b.y - a.y) / (2 * G * ds);
        auto& n = pts_[wrap(i + 1)].pos; auto& c = pts_[i].pos;
        pts_[i].heading = std::atan2(n.x - c.x, n.z - c.z);
        if (i > 0) ascent_ += std::max(0.f, c.y - pts_[i - 1].pos.y);
    }

    // spatial grid
    float maxR = 0;
    for (auto& p : pts_) maxR = std::max(maxR, std::hypot(p.pos.x, p.pos.z));
    extent_ = maxR + 1600.f;
    gridMin_ = -extent_;
    gridCell_ = 40.f;
    gridN_ = int(std::ceil(2 * extent_ / gridCell_));
    grid_.assign(size_t(gridN_) * gridN_, {});
    for (int i = 0; i < N; ++i) {
        int gx = int((pts_[i].pos.x - gridMin_) / gridCell_), gz = int((pts_[i].pos.z - gridMin_) / gridCell_);
        grid_[size_t(gz) * gridN_ + gx].push_back(i);
    }
    coarse_.clear();
    for (int i = 0; i < N; i += 20) coarse_.push_back(i);
    water_ = minEle_ - 7.f;
}

CoursePoint Course::at(double dist) const {
    if (pts_.empty()) return {};
    double L = length_;
    dist = std::fmod(dist, L);
    if (dist < 0) dist += L;
    double fi = dist / L * pts_.size();
    size_t i = size_t(fi) % pts_.size(), k = (i + 1) % pts_.size();
    float f = float(fi - std::floor(fi));
    const auto& a = pts_[i]; const auto& b = pts_[k];
    CoursePoint c;
    c.pos = {a.pos.x + (b.pos.x - a.pos.x) * f, a.pos.y + (b.pos.y - a.pos.y) * f, a.pos.z + (b.pos.z - a.pos.z) * f};
    float dh = b.heading - a.heading;
    while (dh > PI) dh -= 2 * PI;
    while (dh < -PI) dh += 2 * PI;
    c.heading = a.heading + dh * f;
    c.grade = a.grade + (b.grade - a.grade) * f;
    c.dist = float(dist);
    return c;
}

float Course::roadDistance(float x, float z, float* roadY) const {
    int gx = int((x - gridMin_) / gridCell_), gz = int((z - gridMin_) / gridCell_);
    float best = 1e9f, by = 0;
    const int N = int(pts_.size());
    for (int dz = -2; dz <= 2; ++dz)
        for (int dx = -2; dx <= 2; ++dx) {
            int cx = gx + dx, cz = gz + dz;
            if (cx < 0 || cz < 0 || cx >= gridN_ || cz >= gridN_) continue;
            for (int i : grid_[size_t(cz) * gridN_ + cx]) {
                const V3& a = pts_[i].pos; const V3& b = pts_[(i + 1) % N].pos;
                float ex = b.x - a.x, ez = b.z - a.z;
                float t = ((x - a.x) * ex + (z - a.z) * ez) / std::max(1e-6f, ex * ex + ez * ez);
                t = std::clamp(t, 0.f, 1.f);
                float px = a.x + ex * t - x, pz = a.z + ez * t - z;
                float d2 = px * px + pz * pz;
                if (d2 < best) { best = d2; by = a.y + (b.y - a.y) * t; }
            }
        }
    if (roadY) *roadY = by;
    return best > 1e8f ? 1e4f : std::sqrt(best);
}

float Course::regionalHeight(float x, float z, float* coarseDist) const {
    double sw = 0, sh = 0;
    float dmin = 1e9f;
    for (int i : coarse_) {
        const V3& p = pts_[i].pos;
        float d2 = (p.x - x) * (p.x - x) + (p.z - z) * (p.z - z);
        dmin = std::min(dmin, d2);
        double w = 1.0 / (double(d2) + 400.0);
        w *= w;
        sw += w; sh += w * p.y;
    }
    if (coarseDist) *coarseDist = std::sqrt(dmin);
    return float(sh / sw);
}

float Course::baseNoise(float x, float z) const {
    float n = fbm(x * 0.0022f, z * 0.0022f, 5, seed_) - 0.5f;
    return n;
}

float Course::terrainHeight(float x, float z) const {
    float dC;
    float reg = regionalHeight(x, z, &dC);
    float ry;
    float d = roadDistance(x, z, &ry);
    float amp = 8.f + std::min(dC, 1800.f) * 0.10f;
    float n = baseNoise(x, z);
    // ridged mountains far from the road
    float rn = 1.f - std::fabs(2.f * fbm(x * 0.0011f + 13.f, z * 0.0011f - 7.f, 5, seed_ + 99) - 1.f);
    float mountains = smoothstepf(450.f, 1500.f, dC) * rn * rn * 420.f;
    // gentle mid-frequency undulation near the road
    float detail = (fbm(x * 0.012f, z * 0.012f, 3, seed_ + 7) - 0.5f) * 4.f;
    float base = reg + n * amp * 2.f + mountains + detail;
    if (d > 90.f) return base;
    float blend = smoothstepf(14.f, 80.f, d);
    float carved = ry - 0.30f;
    // shoulders: slightly lower than the road, like a ditch
    carved -= smoothstepf(5.f, 9.f, d) * (1.f - smoothstepf(10.f, 16.f, d)) * 0.35f;
    return carved + (base - carved) * blend;
}
