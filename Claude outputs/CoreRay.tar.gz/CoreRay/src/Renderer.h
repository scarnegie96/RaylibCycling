#pragma once
#include <vector>

#include "Course.h"
#include "raylib.h"

enum class CamMode { Chase, Close, Side, Overhead, FirstPerson, Cinematic, COUNT };
const char* camModeName(CamMode m);

struct SceneState {
    double dist = 0;         // rider distance along course (m)
    double speed = 0;        // m/s
    double crankAngle = 0;   // radians
    double wheelAngle = 0;   // radians
    double time = 0;         // seconds (animation)
    float effort = 0;        // 0..1 for body rocking
    CamMode cam = CamMode::Chase;
    double pacerDist = -1;   // <0 = no pacer
    float lean = 0;          // smoothed lean angle from curvature
    float stand = 0;         // 0..1 out of the saddle
    float tuck = 0;          // 0..1 aero tuck / drops
};

struct TimeOfDay {
    Vector3 sunDir, sunColor, zenith, horizon, ground;
    float ambient, fog, exposure, clouds;
};

class Renderer {
public:
    bool init(const Course& course, int quality);
    void shutdown();
    void setQuality(int q);
    void setTimeOfDay(int preset);   // 0 morning, 1 midday, 2 golden hour, 3 overcast
    int timeOfDay() const { return todIndex_; }
    void render(const SceneState& s, float dt);   // draws full frame (3D + post) to the screen
    Camera3D camera() const { return cam_; }

private:
    struct Chunk { Mesh mesh; Vector3 center; float radius; };
    struct Instances { std::vector<Matrix> all; std::vector<Vector3> pos; std::vector<Matrix> visible; };

    void buildTerrain();
    void buildRoad();
    void buildVegetation();
    void buildProps();
    void createTargets();
    void destroyTargets();
    void updateCamera(const SceneState& s, float dt);
    void setCommonUniforms(Shader sh);
    void drawWorld(bool shadowPass, int cascade, const Vector3& focus, float radius);
    void drawRider(const Matrix& base, const SceneState& s, bool ghost, bool shadowPass);
    void drawPart(const Mesh& m, Matrix local, const Matrix& base, Color c, float rough, float spec, bool shadowPass, int pattern = 0, float emissive = 0);
    void drawLimb(Vector3 a, Vector3 b, float r, const Matrix& base, Color c, bool shadowPass, float rough = 0.7f, float spec = 0.2f);
    void renderShadowMaps(const SceneState& s);
    void postProcess();

    const Course* course_ = nullptr;
    int quality_ = 2;
    int todIndex_ = 1;
    TimeOfDay tod_{};

    // shaders
    Shader terrainSh_{}, roadSh_{}, objectSh_{}, foliageSh_{}, waterSh_{}, skySh_{};
    Shader depthSh_{}, depthInstSh_{};
    Shader brightSh_{}, blurSh_{}, compositeSh_{}, fxaaSh_{};
    Material terrainMat_{}, roadMat_{}, objectMat_{}, foliageMat_{}, waterMat_{}, skyMat_{}, depthMat_{}, depthInstMat_{};

    std::vector<Chunk> terrain_, road_;
    Mesh water_{}, skyDome_{};
    Mesh cyl_{}, sphere_{}, cube_{}, cone_{}, wheelTire_{}, wheelRim_{};
    Mesh treeCone_{}, treeBlob_{}, treeTrunk_{}, rockMesh_{};
    Instances conifers_, broadleaf_, rocks_;
    std::vector<Matrix> signposts_;
    Matrix archBase_{};

    // render targets
    int rtW_ = 0, rtH_ = 0, shadowRes_ = 2048;
    RenderTexture2D scene_{}, bright_{}, blurA_{}, blurB_{}, qA_{}, qB_{}, ldr_{};
    RenderTexture2D shadow_[2]{};
    Matrix lightVP_[2]{};
    float cascadeRange_[2] = {45.f, 420.f};

    Camera3D cam_{};
    Vector3 camPosSmooth_{}, camTargetSmooth_{};
    bool camInit_ = false;
    float time_ = 0;
    int cineShot_ = 0;
    float cineTimer_ = 0;
};
