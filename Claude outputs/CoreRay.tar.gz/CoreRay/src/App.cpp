#include "App.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>

#include "Audio.h"
#include "core/Export.h"
#include "core/Metrics.h"
#include "raylib.h"
#include "raymath.h"

using namespace ui;

void App::toast(const std::string& s, Color c) {
    toasts_.push_back({s, GetTime(), c});
    while (toasts_.size() > 4) toasts_.pop_front();
}

void App::newCourse(int seed) {
    prefs_.courseSeed = seed;
    course_.generate(seed);
    route_ = RouteProfile{};
    route_.step = 10;
    route_.length = course_.length();
    route_.loop = true;
    int n = int(route_.length / route_.step);
    for (int i = 0; i < n; ++i) route_.ele.push_back(course_.elevationAt(i * route_.step));
    route_.length = n * route_.step;
    route_.detectClimbs();
}

void App::rebuildWorld() {
    renderer_.shutdown();
    renderer_.init(course_, prefs_.quality);
    renderer_.setTimeOfDay(prefs_.timeOfDay);
}

bool App::simActive() const { return prefs_.simEnabled; }

std::vector<const wk::Workout*> App::allWorkouts() const {
    std::vector<const wk::Workout*> v;
    for (auto& w : builtin_) v.push_back(&w);
    for (auto& w : custom_) v.push_back(&w);
    return v;
}

const wk::Workout* App::findWorkout(const std::string& id) const {
    for (auto* w : allWorkouts()) if (w->id == id) return w;
    return builtin_.empty() ? nullptr : &builtin_[0];
}

int App::run(int argc, char** argv) {
    std::string shotPath;
    int shotFrames = 90, forceCam = -1, forceTod = -1, forceTab = -1;
    bool autoRide = false, force2d = false, autoSummary = false;
    std::string forceKind;
    store::load(prof_, prefs_);
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--sim") prefs_.simEnabled = true;
        else if (a == "--ride") autoRide = true;
        else if (a == "--2d") force2d = true;
        else if (a == "--summary") autoSummary = true;
        else if (a == "--screenshot" && i + 1 < argc) shotPath = argv[++i];
        else if (a == "--frames" && i + 1 < argc) shotFrames = std::atoi(argv[++i]);
        else if (a == "--cam" && i + 1 < argc) forceCam = std::atoi(argv[++i]);
        else if (a == "--tod" && i + 1 < argc) forceTod = std::atoi(argv[++i]);
        else if (a == "--tab" && i + 1 < argc) forceTab = std::atoi(argv[++i]);
        else if (a == "--quality" && i + 1 < argc) prefs_.quality = std::atoi(argv[++i]);
        else if (a == "--kind" && i + 1 < argc) forceKind = argv[++i];
        else if (a == "--workout" && i + 1 < argc) selWorkout_ = argv[++i];
    }
    if (forceKind == "route") setupKind_ = RideKind::Route;
    else if (forceKind == "workout") setupKind_ = RideKind::Workout;
    else if (forceKind == "test") setupKind_ = RideKind::Test;
    if (forceTab >= 0) tab_ = forceTab;

    SetConfigFlags(FLAG_WINDOW_RESIZABLE | FLAG_WINDOW_HIGHDPI | FLAG_VSYNC_HINT | FLAG_MSAA_4X_HINT);
    InitWindow(1600, 900, "CoreRay");
    SetWindowMinSize(1180, 700);
    SetExitKey(KEY_NULL);
    ui::loadFonts();
    sfx::init();

    builtin_ = wk::builtinWorkouts();
    custom_ = store::loadCustomWorkouts();
    sim_ = std::make_unique<sim::SimTrainer>(prof_);
    sim_->set(prefs_.sim);
    hrAlertsOn_ = prof_.hrAlerts;
    cam_ = CamMode(std::clamp(prefs_.camera, 0, int(CamMode::COUNT) - 1));
    view3d_ = prefs_.startIn3d && !force2d;

    newCourse(prefs_.courseSeed);
    BeginDrawing();
    ClearBackground(BG);
    textCentered("Building world...", {0, 0, float(GetScreenWidth()), float(GetScreenHeight())}, F::Title, TEXT);
    EndDrawing();
    renderer_.init(course_, prefs_.quality);
    renderer_.setTimeOfDay(forceTod >= 0 ? forceTod : prefs_.timeOfDay);
    if (forceCam >= 0) cam_ = CamMode(forceCam % int(CamMode::COUNT));

    ble_.setAutoConnect(prefs_.trainerId, prefs_.hrId);
    ble_.startScan(45);
    if (autoRide) startRide();

    int frame = 0;
    while (!WindowShouldClose()) {
        float dt = std::min(GetFrameTime(), 0.1f);
        if (!shotPath.empty()) dt = 1.f / 30.f;
        ui::beginFrame();
        SetMouseCursor(MOUSE_CURSOR_DEFAULT);
        handleDroppedFiles();
        frameUpdate(dt);
        if (autoSummary && screen_ == Screen::Ride && frame == shotFrames - 3) endRide(true);

        BeginDrawing();
        ClearBackground(BG);
        bool draw3d = screen_ != Screen::Ride || view3d_;
        if (draw3d) {
            SceneState s;
            s.time = animTime_;
            if (screen_ == Screen::Ride && eng_) {
                s.dist = eng_->distance();
                s.speed = eng_->speedMps();
                s.crankAngle = crank_;
                s.wheelAngle = eng_->distance() / 0.335;
                s.effort = float(std::clamp(eng_->power3s() / std::max(1.0, prof_.ftp), 0.0, 1.5));
                s.cam = cam_;
                if (auto g = eng_->ghostDistance()) s.pacerDist = *g;
                s.lean = float(lean_);
                s.stand = float(stand_);
                s.tuck = float(tuck_);
            } else {
                s.dist = homeDist_;
                s.speed = 9;
                s.crankAngle = animTime_ * 9.0;
                s.wheelAngle = homeDist_ / 0.335;
                s.effort = 0.4f;
                s.cam = forceCam >= 0 ? cam_ : CamMode::Cinematic;
            }
            renderer_.render(s, dt);
        }
        if (screen_ == Screen::Home) drawHome();
        else if (screen_ == Screen::Ride) {
            if (!view3d_) drawDashboard2d();
            else if (!hudHidden_) drawRideHud();
            if (drawerOpen_) drawEditDrawer();
            if (testPanel_ && simActive()) {
                float W = float(GetScreenWidth());
                Rectangle r{W - 400, 140, 380, 470};
                panel(r, Color{12, 14, 22, 245});
                drawSimPanel({r.x + 16, r.y + 12, r.width - 32, r.height - 24}, true);
                if (CheckCollisionPointRec(GetMousePosition(), r)) ui::setInputBlocked(false);
            }
            if (pauseMenu_) drawPauseMenu();
            if (helpOpen_) drawHelp();
        } else drawSummary();
        drawToasts();
        EndDrawing();

        ++frame;
        if (!shotPath.empty() && frame >= shotFrames) {
            TakeScreenshot(shotPath.c_str());
            break;
        }
    }
    if (screen_ == Screen::Ride && eng_ && eng_->elapsedS() > 60) endRide(true);  // never lose a ride on quit
    prefs_.camera = int(cam_);
    prefs_.timeOfDay = renderer_.timeOfDay();
    prefs_.sim = sim_->settings();
    store::save(prof_, prefs_);
    renderer_.shutdown();
    sfx::shutdown();
    ui::unloadFonts();
    CloseWindow();
    return 0;
}

// ------------------------------------------------------------------ files dropped on the window
void App::handleDroppedFiles() {
    if (!IsFileDropped()) return;
    FilePathList list = LoadDroppedFiles();
    for (unsigned i = 0; i < list.count; ++i) {
        std::string path = list.paths[i];
        std::ifstream f(path);
        std::stringstream ss;
        ss << f.rdbuf();
        wk::Workout w;
        std::string err;
        std::string name = path.substr(path.find_last_of("/\\") + 1);
        if (wk::importFile(name, ss.str(), prof_.ftp, w, err)) {
            w.id.clear();
            if (store::saveCustomWorkout(w, err)) {
                custom_ = store::loadCustomWorkouts();
                for (auto& c : custom_) if (c.name == w.name) wkSelected_ = c.id;
                tab_ = TabWorkouts;
                toast("Imported workout: " + w.name, GOOD);
            } else toast(err, BAD);
        } else toast(name + ": " + err, BAD);
    }
    UnloadDroppedFiles(list);
}

// ------------------------------------------------------------------ ride flow
void App::startRide() {
    RideSetup su;
    su.kind = setupKind_;
    switch (setupKind_) {
        case RideKind::Route:
            su.name = course_.name();
            su.laps = setupLaps_;
            if (raceGhost_) su.ghost = store::loadGhost(prefs_.courseSeed, setupLaps_);
            break;
        case RideKind::Workout: {
            const wk::Workout* w = findWorkout(selWorkout_);
            su.workout = *w;
            su.name = w->name;
            break;
        }
        case RideKind::Test:
            su.test = selTest_;
            for (auto& t : wk::testCatalogue()) if (t.kind == selTest_) su.name = t.name;
            break;
        case RideKind::Free:
            su.name = "Free ride";
            su.freeMode = setupFreeMode_;
            su.goal = setupGoal_;
            break;
    }
    eng_ = std::make_unique<RideEngine>(prof_, su, route_);
    if (setupKind_ == RideKind::Workout && workoutResistance_) eng_->toggleErg();
    eng_->drainEvents();
    rideStart_ = std::time(nullptr);
    screen_ = Screen::Ride;
    drawerOpen_ = pauseMenu_ = helpOpen_ = false;
    crank_ = 0; lean_ = 0; stand_ = 0; tuck_ = 0;
    lastAlertT_ = -1e9; lastHrState_ = 0; lastStepIdx_ = -1;
    store::save(prof_, prefs_);
    toast(su.name, TEXT);
    if (ble_.trainer().state != LinkState::Connected && !simActive())
        toast("No trainer connected - Devices tab, or turn on the simulator", WARN);
}

void App::endRide(bool save) {
    if (!eng_) return;
    ble_.send(TrainerCommand::sim(0, prof_.crr, 0.5 * phys::airDensity(0) * prof_.cda));
    summary_ = eng_->finish();
    summaryName_ = eng_->setup().name;
    const Samples& sm = eng_->samples();
    sumPower_ = sm.power; sumHr_ = sm.hr; sumCad_ = sm.cadence; sumSpeed_ = sm.speed; sumEle_ = sm.ele;
    savedDir_.clear(); savedBase_.clear();
    newPb_ = false; ftpApplied_ = false;
    if (save && sm.size() >= 10) {
        savedDir_ = exporter::saveRide(summary_, sm, rideStart_, summaryName_, &savedBase_);
        if (eng_->setup().kind == RideKind::Route && summary_.routeComplete)
            newPb_ = store::saveGhostIfBest(prefs_.courseSeed, eng_->setup().laps, sm.distance);
    }
    screen_ = save ? Screen::Summary : Screen::Home;
    if (save) sfx::play(sfx::Done);
}

TrainerInput App::currentInput(float dt) {
    if (simActive()) return sim_->update(dt, prof_);
    return ble_.input();
}

void App::frameUpdate(float dt) {
    animTime_ += dt;
    // remember devices that connected so they auto-connect next launch
    Link t = ble_.trainer(), h = ble_.hrm();
    if (t.state == LinkState::Connected && t.id != prefs_.trainerId) {
        prefs_.trainerId = t.id; prefs_.trainerName = t.name;
        ble_.setAutoConnect(prefs_.trainerId, prefs_.hrId);
        store::save(prof_, prefs_);
        toast("Trainer connected: " + t.name, GOOD);
    }
    if (h.state == LinkState::Connected && h.id != prefs_.hrId) {
        prefs_.hrId = h.id; prefs_.hrName = h.name;
        ble_.setAutoConnect(prefs_.trainerId, prefs_.hrId);
        store::save(prof_, prefs_);
        toast("Heart rate connected: " + h.name, GOOD);
    }

    if (screen_ != Screen::Ride || !eng_) {
        homeDist_ += 9.0 * dt;
        if (screen_ == Screen::Home && !anyTextActive()) {
            if (IsKeyPressed(KEY_T)) renderer_.setTimeOfDay(renderer_.timeOfDay() + 1);
        }
        if (simActive()) sim_->update(dt, prof_);  // keep the sim warm for the device readout
        return;
    }

    handleRideKeys(dt);
    TrainerInput in = currentInput(dt);
    if (auto cmd = eng_->tick(dt, in)) {
        if (simActive()) sim_->command(*cmd);
        else ble_.send(*cmd);
    }
    handleEvents();
    hrAlerts();

    // ---- rider animation from real effort
    double cad = eng_->cadence();
    if (cad > 5) crank_ += cad / 60.0 * 2 * PI * dt;
    else {  // freewheeling: pedals level
        double target = std::round((crank_ - PI / 2) / PI) * PI + PI / 2;
        crank_ += (target - crank_) * std::min(1.0, double(dt) * 3);
    }
    double g = eng_->gradePct(), p3 = eng_->power3s(), ftp = std::max(prof_.ftp, 50.0);
    double v = eng_->speedMps();
    bool wantStand = (g > 7 && p3 > 0.8 * ftp) || (p3 > 1.4 * ftp && cad > 70) || (cad > 0 && cad < 62 && p3 > 0.9 * ftp);
    standTimer_ += dt;
    if (!wantStand && g > 3 && p3 > 0.5 * ftp && std::fmod(standTimer_, 180.0) < 9) wantStand = true;  // stretch the legs now and then
    bool wantTuck = (v > 13 && p3 < 0.4 * ftp && g < -2) || (p3 > 1.05 * ftp && std::fabs(g) < 2 && !wantStand);
    if (eng_->paused()) wantStand = wantTuck = false;
    stand_ += ((wantStand ? 1.0 : 0.0) - stand_) * std::min(1.0, double(dt) * 3);
    tuck_ += ((wantTuck ? 1.0 : 0.0) - tuck_) * std::min(1.0, double(dt) * 2);
    {
        auto a = course_.at(eng_->distance() - 6), b = course_.at(eng_->distance() + 6);
        double dh = b.heading - a.heading;
        while (dh > PI) dh -= 2 * PI;
        while (dh < -PI) dh += 2 * PI;
        double target = -std::atan(v * v * (dh / 12.0) / 9.81);
        lean_ += (target - lean_) * std::min(1.0, double(dt) * 3.0);
    }
}

void App::handleEvents() {
    for (auto& e : eng_->drainEvents()) {
        Color c = TEXT;
        if (e.kind == "step") sfx::play(sfx::StepChange);
        else if (e.kind == "lap" || e.kind == "sector") { sfx::play(sfx::Lap); c = SKY; }
        else if (e.kind == "climb") c = WARN;
        else if (e.kind == "goal" || e.kind == "route_complete" || e.kind == "workout_complete" || e.kind == "test_complete") {
            sfx::play(sfx::Done);
            c = GOOD;
        }
        toast(e.message, c);
    }
    // 3-2-1 countdown beeps before ERG step changes
    if (auto cs = eng_->currentStep()) {
        const auto& st = eng_->steps()[cs->first];
        double rem = st.durationS - cs->second;
        static int lastBeep = -1;
        int sec = int(std::ceil(rem));
        if (sec <= 3 && sec >= 1 && sec != lastBeep && st.durationS > 20) { sfx::play(sfx::Countdown); lastBeep = sec; }
        if (sec > 3) lastBeep = -1;
    }
}

void App::hrAlerts() {
    if (!hrAlertsOn_ || !eng_->heartRate() || eng_->paused()) { lastHrState_ = 0; return; }
    if (eng_->elapsedS() < prof_.hrAlertGraceS) return;
    int z = eng_->hrZone();
    int state = z > prof_.hrAlertHi ? 1 : z < prof_.hrAlertLo ? -1 : 0;
    if (state == 1 && !prof_.hrAlertHigh) state = 0;
    if (state == -1 && !prof_.hrAlertLow) state = 0;
    double now = eng_->elapsedS();
    if (state != 0 && (state != lastHrState_ || now - lastAlertT_ >= prof_.hrAlertRepeatS)) {
        sfx::play(state > 0 ? sfx::HrHigh : sfx::HrLow);
        toast(state > 0 ? "Heart rate above Z" + std::to_string(prof_.hrAlertHi) + " - ease off" : "Heart rate below Z" + std::to_string(prof_.hrAlertLo) + " - push on",
              state > 0 ? BAD : SKY);
        lastAlertT_ = now;
    }
    lastHrState_ = state;
}

void App::handleRideKeys(float dt) {
    (void)dt;
    if (anyTextActive()) return;
    bool shift = IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT);
    bool alt = IsKeyDown(KEY_LEFT_ALT) || IsKeyDown(KEY_RIGHT_ALT);
    if (IsKeyPressed(KEY_ESCAPE)) {
        if (helpOpen_) helpOpen_ = false;
        else if (drawerOpen_) drawerOpen_ = false;
        else { pauseMenu_ = !pauseMenu_; if (pauseMenu_) eng_->pause(); }
    }
    if (IsKeyPressed(KEY_SPACE)) {
        if (eng_->paused()) { eng_->resume(); pauseMenu_ = false; } else eng_->pause();
    }
    if (IsKeyPressed(KEY_L)) eng_->lap();
    if (IsKeyPressed(KEY_H)) { hrAlertsOn_ = !hrAlertsOn_; toast(hrAlertsOn_ ? "Heart-rate alerts on" : "Heart-rate alerts off"); }
    if (IsKeyPressed(KEY_E)) drawerOpen_ = !drawerOpen_;
    if (IsKeyPressed(KEY_D)) {
        if (simActive()) testPanel_ = !testPanel_;
        else toast("Test data needs the simulator (Devices tab)", WARN);
    }
    if (IsKeyPressed(KEY_V)) view3d_ = !view3d_;
    if (IsKeyPressed(KEY_TAB)) hudHidden_ = !hudHidden_;
    if (IsKeyPressed(KEY_SLASH) || IsKeyPressed(KEY_F1)) helpOpen_ = !helpOpen_;
    if (IsKeyPressed(KEY_C)) { cam_ = CamMode((int(cam_) + 1) % int(CamMode::COUNT)); toast(std::string("Camera: ") + camModeName(cam_)); }
    if (IsKeyPressed(KEY_T)) {
        renderer_.setTimeOfDay(renderer_.timeOfDay() + 1);
        static const char* n[] = {"Morning", "Midday", "Golden hour", "Overcast"};
        toast(std::string("Time of day: ") + n[renderer_.timeOfDay()]);
    }
    if (IsKeyPressed(KEY_LEFT_BRACKET) || IsKeyPressed(KEY_PAGE_DOWN)) eng_->shift(-1);
    if (IsKeyPressed(KEY_RIGHT_BRACKET) || IsKeyPressed(KEY_PAGE_UP)) eng_->shift(1);
    if (IsKeyPressed(KEY_RIGHT)) eng_->skipStep();
    for (int dir : {1, -1}) {
        int key = dir > 0 ? KEY_UP : KEY_DOWN;
        if (!(IsKeyPressed(key) || IsKeyPressedRepeat(key))) continue;
        if (shift && simActive()) {
            auto s = sim_->settings();
            if (s.powerSource == sim::PowerSource::Fixed) s.powerW += 10 * dir; else s.effortW += 10 * dir;
            sim_->set(s);
            prefs_.sim = sim_->settings();
        } else if (alt && simActive()) {
            auto s = sim_->settings();
            s.hrSource = sim::HrSource::Fixed;
            s.hrBpm += 2 * dir;
            sim_->set(s);
            prefs_.sim = sim_->settings();
        } else eng_->nudge(dir);
    }
}

// ------------------------------------------------------------------ toasts
void App::drawToasts() {
    const float W = float(GetScreenWidth());
    double now = GetTime();
    while (!toasts_.empty() && now - toasts_.front().t > 4.0) toasts_.pop_front();
    float y = screen_ == Screen::Ride ? 150 : 110;
    for (auto& t : toasts_) {
        float a = float(std::clamp((4.0 - (now - t.t)) / 0.4, 0.0, 1.0)) * float(std::clamp((now - t.t) / 0.15, 0.0, 1.0));
        Vector2 m = measure(t.text, F::Body);
        Rectangle r{(W - m.x - 44) / 2, y, m.x + 44, 40};
        DrawRectangleRounded(r, 0.5f, 8, Color{14, 17, 26, (unsigned char)(225 * a)});
        DrawRectangleRounded({r.x + 8, r.y + 12, 4, 16}, 1, 4, Color{t.c.r, t.c.g, t.c.b, (unsigned char)(255 * a)});
        textCentered(t.text, r, F::Body, Color{238, 242, 248, (unsigned char)(255 * a)});
        y += 48;
    }
}
