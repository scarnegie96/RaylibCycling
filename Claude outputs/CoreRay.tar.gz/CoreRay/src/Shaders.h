#pragma once
// GLSL 330 sources for the CoreRay renderer. Fragment shaders are assembled as
// HEADER + COMMON + body so lighting, shadows and fog are identical everywhere.

namespace shaders {

static const char* VS_STATIC = R"(#version 330
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
in vec4 vertexColor;
uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 matNormal;
out vec3 fragPos;
out vec2 fragUV;
out vec3 fragNormal;
out vec4 fragColor;
out float fragVar;
void main() {
    fragPos = (matModel * vec4(vertexPosition, 1.0)).xyz;
    fragUV = vertexTexCoord;
    fragNormal = normalize((matNormal * vec4(vertexNormal, 0.0)).xyz);
    fragColor = vertexColor;
    fragVar = 0.0;
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)";

// Instanced: vegetation & rocks, with wind sway proportional to height
static const char* VS_INSTANCED = R"(#version 330
in vec3 vertexPosition;
in vec2 vertexTexCoord;
in vec3 vertexNormal;
layout(location = 10) in mat4 instanceTransform;
uniform mat4 mvp;
uniform float time;
uniform float windAmount;
out vec3 fragPos;
out vec2 fragUV;
out vec3 fragNormal;
out vec4 fragColor;
out float fragVar;
float h11(float n) { return fract(sin(n) * 43758.5453); }
void main() {
    vec3 origin = instanceTransform[3].xyz;
    float seed = origin.x * 0.137 + origin.z * 0.071;
    vec4 wp = instanceTransform * vec4(vertexPosition, 1.0);
    float hgt = max(vertexPosition.y, 0.0);
    float sway = sin(time * 1.3 + seed * 6.0) * 0.6 + sin(time * 2.7 + seed * 11.0) * 0.25;
    wp.xz += vec2(sway, sway * 0.6) * windAmount * hgt * hgt * 0.35;
    fragPos = wp.xyz;
    fragUV = vertexTexCoord;
    fragNormal = normalize(mat3(instanceTransform) * vertexNormal);
    fragColor = vec4(1.0, 1.0, 1.0, clamp(vertexPosition.y, 0.0, 1.0));
    fragVar = h11(seed);
    gl_Position = mvp * wp;
}
)";

static const char* VS_DEPTH = R"(#version 330
in vec3 vertexPosition;
uniform mat4 mvp;
void main() { gl_Position = mvp * vec4(vertexPosition, 1.0); }
)";

static const char* VS_DEPTH_INSTANCED = R"(#version 330
in vec3 vertexPosition;
layout(location = 10) in mat4 instanceTransform;
uniform mat4 mvp;
uniform float time;
uniform float windAmount;
void main() {
    vec3 origin = instanceTransform[3].xyz;
    float seed = origin.x * 0.137 + origin.z * 0.071;
    vec4 wp = instanceTransform * vec4(vertexPosition, 1.0);
    float hgt = max(vertexPosition.y, 0.0);
    float sway = sin(time * 1.3 + seed * 6.0) * 0.6 + sin(time * 2.7 + seed * 11.0) * 0.25;
    wp.xz += vec2(sway, sway * 0.6) * windAmount * hgt * hgt * 0.35;
    gl_Position = mvp * wp;
}
)";

static const char* FS_DEPTH = R"(#version 330
out vec4 finalColor;
void main() { finalColor = vec4(1.0); }
)";

static const char* FS_HEADER = R"(#version 330
in vec3 fragPos;
in vec2 fragUV;
in vec3 fragNormal;
in vec4 fragColor;
in float fragVar;
out vec4 finalColor;
)";

static const char* FS_COMMON = R"(
uniform vec3 camPos;
uniform vec3 sunDir;
uniform vec3 sunColor;
uniform vec3 skyZenith;
uniform vec3 skyHorizon;
uniform vec3 groundColor;
uniform float ambient;
uniform float fogDensity;
uniform float time;
uniform sampler2D shadowMap0;
uniform sampler2D shadowMap1;
uniform mat4 lightVP0;
uniform mat4 lightVP1;
uniform vec2 shadowTexel;     // 1/res for cascade 0 and 1 (same res)
uniform vec2 cascadeRange;    // world-space half extents of cascade 0 / 1
uniform vec3 cascadeCenter0;
uniform vec3 cascadeCenter1;
uniform int shadowsOn;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i), b = hash12(i + vec2(1, 0)), c = hash12(i + vec2(0, 1)), d = hash12(i + vec2(1, 1));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
float fbm3(vec2 p) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 3; i++) { s += vnoise(p) * a; p = mat2(1.6, 1.2, -1.2, 1.6) * p; a *= 0.5; }
    return s / 0.875;
}

const vec2 poisson[12] = vec2[](
    vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696, 0.457), vec2(-0.203, 0.621),
    vec2(0.962, -0.195), vec2(0.473, -0.480), vec2(0.519, 0.767), vec2(0.185, -0.893),
    vec2(0.507, 0.064), vec2(0.896, 0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598));

float shadowSample(sampler2D sm, mat4 vp, vec3 wp, float bias, float radius) {
    vec4 lp = vp * vec4(wp, 1.0);
    vec3 p = lp.xyz / lp.w * 0.5 + 0.5;
    if (p.x <= 0.001 || p.x >= 0.999 || p.y <= 0.001 || p.y >= 0.999 || p.z >= 1.0) return 1.0;
    float rot = hash12(gl_FragCoord.xy) * 6.2831;
    mat2 R = mat2(cos(rot), sin(rot), -sin(rot), cos(rot));
    float lit = 0.0;
    for (int i = 0; i < 12; i++) {
        float d = texture(sm, p.xy + R * poisson[i] * shadowTexel * radius).r;
        lit += (p.z - bias > d) ? 0.0 : 1.0;
    }
    return lit / 12.0;
}

float shadowFactor(vec3 wp, vec3 n) {
    if (shadowsOn == 0) return 1.0;
    float ndl = clamp(dot(n, sunDir), 0.0, 1.0);
    vec3 d = abs(wp - cascadeCenter0);
    vec3 d1 = abs(wp - cascadeCenter1);
    float r0 = cascadeRange.x * 0.92;
    // normal offset scaled by cascade texel size in world units
    float t0 = cascadeRange.x * 2.0 * shadowTexel.x;
    float t1 = cascadeRange.y * 2.0 * shadowTexel.x;
    float slope = sqrt(max(0.0, 1.0 - ndl * ndl)) / max(ndl, 0.15);
    if (max(d.x, d.z) < r0) {
        float s = shadowSample(shadowMap0, lightVP0, wp + n * t0 * 1.5, 0.0004 + 0.0006 * slope, 1.6);
        float edge = smoothstep(r0 * 0.8, r0, max(d.x, d.z));
        if (edge > 0.0) s = mix(s, shadowSample(shadowMap1, lightVP1, wp + n * t1 * 1.5, 0.0006 + 0.001 * slope, 1.2), edge);
        return s;
    }
    float r1 = cascadeRange.y * 0.95;
    float m = max(d1.x, d1.z);
    if (m < r1) {
        float s = shadowSample(shadowMap1, lightVP1, wp + n * t1 * 1.5, 0.0006 + 0.001 * slope, 1.2);
        return mix(s, 1.0, smoothstep(r1 * 0.75, r1, m));
    }
    return 1.0;
}

vec3 skyColor(vec3 d) {
    float y = d.y;
    float sd = max(dot(d, sunDir), 0.0);
    vec3 c = mix(skyHorizon, skyZenith, pow(clamp(y, 0.0, 1.0), 0.45));
    c += sunColor * (pow(sd, 5.0) * 0.10 + pow(sd, 48.0) * 0.25);
    // horizon haze band
    c = mix(c, skyHorizon * 1.08 + sunColor * 0.03, exp(-abs(y) * 18.0) * 0.6);
    if (y < 0.0) c = mix(c, groundColor * 0.7 + skyHorizon * 0.3, smoothstep(0.0, -0.25, y));
    return c;
}

vec3 applyFog(vec3 col, vec3 wp) {
    vec3 v = wp - camPos;
    float dist = length(v);
    vec3 dir = v / max(dist, 1e-3);
    // height-attenuated exponential fog: valleys are hazier than ridges
    float hf = exp(-max(wp.y - 30.0, 0.0) * 0.0035);
    float f = 1.0 - exp(-pow(dist * fogDensity, 1.25) * (0.35 + 0.65 * hf));
    float sunAmt = pow(max(dot(dir, sunDir), 0.0), 8.0);
    vec3 fc = skyColor(normalize(vec3(dir.x, max(dir.y, 0.02), dir.z)));
    fc = mix(fc, fc + sunColor * 0.25, sunAmt);
    return mix(col, fc, clamp(f, 0.0, 1.0));
}

vec3 shade(vec3 albedo, vec3 n, vec3 wp, float rough, float spec, float shadow, float ao) {
    vec3 V = normalize(camPos - wp);
    float ndl = max(dot(n, sunDir), 0.0);
    vec3 H = normalize(V + sunDir);
    float shin = mix(300.0, 6.0, rough);
    float nh = max(dot(n, H), 0.0);
    float fres = 0.04 + 0.96 * pow(1.0 - max(dot(n, V), 0.0), 5.0);
    float s = pow(nh, shin) * (shin + 8.0) / 25.13 * spec * mix(0.25, 1.0, fres);
    vec3 hemi = mix(groundColor, skyZenith, n.y * 0.5 + 0.5);
    vec3 direct = sunColor * ndl * shadow;
    vec3 col = albedo * (direct + hemi * ambient * ao);
    col += direct * s;
    col += skyColor(reflect(-V, n)) * fres * spec * 0.35 * ao;
    return col;
}
)";

// ---------------------------------------------------------------- terrain
static const char* FS_TERRAIN = R"(
uniform float waterLevel;
uniform float snowLine;
void main() {
    vec3 n = normalize(fragNormal);
    vec2 xz = fragPos.xz;
    float n1 = vnoise(xz * 0.06), n2 = vnoise(xz * 0.45), n3 = vnoise(xz * 2.7);
    float dn = n1 * 0.55 + n2 * 0.3 + n3 * 0.15;
    // detail normal from noise gradient
    float e = 0.35;
    float hx = vnoise((xz + vec2(e, 0)) * 0.45) - n2, hz = vnoise((xz + vec2(0, e)) * 0.45) - n2;
    n = normalize(n + vec3(-hx, 0.0, -hz) * 0.9);
    float slope = 1.0 - n.y;
    float h = fragPos.y;

    vec3 grassA = vec3(0.13, 0.24, 0.05), grassB = vec3(0.26, 0.33, 0.09), dry = vec3(0.45, 0.42, 0.22);
    vec3 grass = mix(grassA, grassB, dn);
    float meadow = smoothstep(0.55, 0.85, vnoise(xz * 0.006));
    grass = mix(grass, dry, meadow * 0.55);
    grass = mix(grass, vec3(0.20, 0.29, 0.10), smoothstep(0.6, 0.9, vnoise(xz * 0.02 + 7.0)) * 0.5);
    vec3 rock = mix(vec3(0.30, 0.29, 0.28), vec3(0.50, 0.47, 0.43), n2 * 0.7 + n3 * 0.3);
    vec3 snow = vec3(0.90, 0.93, 0.98);
    vec3 sand = vec3(0.60, 0.55, 0.40);
    vec3 dirt = vec3(0.36, 0.29, 0.20);

    vec3 albedo = grass;
    float rockAmt = smoothstep(0.22, 0.40, slope + (dn - 0.5) * 0.2);
    albedo = mix(albedo, rock, rockAmt);
    float snowAmt = smoothstep(snowLine, snowLine + 60.0, h + dn * 40.0) * smoothstep(0.55, 0.25, slope);
    albedo = mix(albedo, snow, snowAmt);
    albedo = mix(albedo, sand, 1.0 - smoothstep(waterLevel + 0.3, waterLevel + 2.5, h + dn * 0.8));
    albedo = mix(albedo, dirt, clamp(fragColor.r * (0.55 + 0.6 * dn), 0.0, 1.0));
    albedo *= albedo * 1.6;  // to linear-ish

    float sh = shadowFactor(fragPos, normalize(fragNormal));
    float ao = mix(0.75, 1.0, n1);
    vec3 col = shade(albedo, n, fragPos, mix(0.95, 0.6, snowAmt), mix(0.04, 0.3, snowAmt), sh, ao);
    finalColor = vec4(applyFog(col, fragPos), 1.0);
}
)";

// ---------------------------------------------------------------- road
static const char* FS_ROAD = R"(
void main() {
    vec3 n = normalize(fragNormal);
    float u = fragUV.x, v = fragUV.y;
    float g = vnoise(fragPos.xz * 6.0) * 0.5 + vnoise(fragPos.xz * 40.0) * 0.5;
    float patch = smoothstep(0.55, 0.75, vnoise(fragPos.xz * 0.15));
    vec3 asphalt = vec3(0.075, 0.075, 0.08) * (0.75 + 0.5 * g);
    asphalt = mix(asphalt, vec3(0.05, 0.05, 0.055), patch * 0.6);
    // wheel tracks are slightly polished
    float track = exp(-pow((abs(u - 0.5) - 0.2) * 22.0, 2.0)) + exp(-pow((abs(u - 0.5) - 0.32) * 22.0, 2.0));
    float aa = fwidth(u) * 1.5;
    float edgeL = smoothstep(0.03 - aa, 0.03, u) - smoothstep(0.05, 0.05 + aa, u);
    float edgeR = smoothstep(0.95 - aa, 0.95, u) - smoothstep(0.97, 0.97 + aa, u);
    float dash = smoothstep(0.45, 0.47, fract(v / 9.0)) * (1.0 - smoothstep(0.93, 0.95, fract(v / 9.0)));
    float center = (smoothstep(0.494 - aa, 0.494, u) - smoothstep(0.506, 0.506 + aa, u)) * dash;
    float paint = clamp(edgeL + edgeR + center, 0.0, 1.0) * (0.75 + 0.25 * g);
    vec3 albedo = mix(asphalt, vec3(0.82, 0.82, 0.78), paint);
    float sh = shadowFactor(fragPos, n);
    vec3 col = shade(albedo, n, fragPos, mix(0.55, 0.4, track), 0.35 + track * 0.25, sh, 1.0);
    finalColor = vec4(applyFog(col, fragPos), 1.0);
}
)";

// ---------------------------------------------------------------- generic objects
static const char* FS_OBJECT = R"(
uniform vec4 colDiffuse;
uniform float roughness;
uniform float specular;
uniform int pattern;      // 0 plain, 1 checker, 2 vertical stripes
uniform float emissive;
void main() {
    vec3 n = normalize(fragNormal);
    if (!gl_FrontFacing) n = -n;
    vec3 albedo = colDiffuse.rgb * colDiffuse.rgb;
    if (pattern == 1) {
        vec2 c = floor(fragUV * vec2(16.0, 2.0));
        albedo = mod(c.x + c.y, 2.0) < 1.0 ? vec3(0.02) : vec3(0.85);
    } else if (pattern == 2) {
        albedo *= 0.7 + 0.3 * step(0.5, fract(fragUV.x * 6.0));
    }
    float sh = shadowFactor(fragPos, n);
    vec3 col = shade(albedo, n, fragPos, roughness, specular, sh, 1.0) + albedo * emissive;
    finalColor = vec4(applyFog(col, fragPos), 1.0);
}
)";

// ---------------------------------------------------------------- vegetation (instanced)
static const char* FS_FOLIAGE = R"(
uniform int kind;    // 0 conifer, 1 broadleaf, 2 trunk, 3 rock
void main() {
    vec3 n = normalize(fragNormal);
    float v = fragVar;
    vec3 albedo;
    float rough = 0.9, spec = 0.05;
    if (kind == 0) albedo = mix(vec3(0.07, 0.17, 0.08), vec3(0.12, 0.22, 0.09), v);
    else if (kind == 1) albedo = mix(vec3(0.20, 0.32, 0.08), vec3(0.36, 0.38, 0.10), v);
    else if (kind == 2) albedo = vec3(0.25, 0.18, 0.12);
    else { albedo = mix(vec3(0.36, 0.35, 0.33), vec3(0.50, 0.48, 0.44), v); rough = 0.8; spec = 0.1; }
    if (kind <= 1) {
        // leafy breakup + fake translucency + height AO
        float leaf = vnoise(fragPos.xz * 3.0 + fragPos.y * 2.0);
        albedo *= 0.75 + 0.5 * leaf;
        n = normalize(n + (vec3(vnoise(fragPos.yz * 4.0), 0.0, vnoise(fragPos.xy * 4.0)) - 0.5) * 0.8);
    }
    albedo *= albedo * 1.5;
    float sh = shadowFactor(fragPos, normalize(fragNormal));
    float ao = kind <= 1 ? mix(0.55, 1.0, fragColor.a) : 1.0;
    vec3 col = shade(albedo, n, fragPos, rough, spec, sh, ao);
    if (kind <= 1) {
        vec3 V = normalize(camPos - fragPos);
        float trans = pow(max(dot(-V, sunDir), 0.0), 4.0) * 0.6;
        col += albedo * sunColor * trans * sh;
    }
    finalColor = vec4(applyFog(col, fragPos), 1.0);
}
)";

// ---------------------------------------------------------------- water
static const char* FS_WATER = R"(
void main() {
    vec2 p = fragPos.xz;
    float t = time;
    float e = 0.15;
    float h0 = fbm3(p * 0.08 + vec2(t * 0.05, t * 0.03)) + 0.5 * vnoise(p * 0.6 - vec2(t * 0.25, -t * 0.1));
    float hx = fbm3((p + vec2(e, 0)) * 0.08 + vec2(t * 0.05, t * 0.03)) + 0.5 * vnoise((p + vec2(e, 0)) * 0.6 - vec2(t * 0.25, -t * 0.1));
    float hz = fbm3((p + vec2(0, e)) * 0.08 + vec2(t * 0.05, t * 0.03)) + 0.5 * vnoise((p + vec2(0, e)) * 0.6 - vec2(t * 0.25, -t * 0.1));
    vec3 n = normalize(vec3(-(hx - h0) / e * 0.35, 1.0, -(hz - h0) / e * 0.35));
    vec3 V = normalize(camPos - fragPos);
    float fres = 0.02 + 0.98 * pow(1.0 - max(dot(n, V), 0.0), 5.0);
    vec3 refl = skyColor(reflect(-V, n));
    vec3 deep = vec3(0.01, 0.04, 0.05);
    float sh = shadowFactor(fragPos, vec3(0, 1, 0));
    vec3 H = normalize(V + sunDir);
    float sp = pow(max(dot(n, H), 0.0), 600.0) * 60.0 * sh;
    vec3 col = mix(deep + skyZenith * 0.04, refl, fres) + sunColor * sp;
    finalColor = vec4(applyFog(col, fragPos), 1.0);
}
)";

// ---------------------------------------------------------------- sky dome
static const char* FS_SKY = R"(
uniform float cloudCover;
void main() {
    vec3 d = normalize(fragPos - camPos);
    vec3 c = skyColor(d);
    float sd = dot(d, sunDir);
    // clouds on a virtual plane
    if (d.y > 0.0) {
        vec2 p = d.xz / (d.y + 0.08) * 1400.0 + camPos.xz * 0.3 + vec2(time * 6.0, time * 2.0);
        vec2 q = p * 0.00055;
        float n = fbm3(q) * 0.65 + fbm3(q * 3.1 + 5.0) * 0.35;
        float cov = smoothstep(1.0 - cloudCover, 1.0 - cloudCover + 0.3, n);
        float ns = fbm3((p + sunDir.xz * 120.0) * 0.00055) * 0.65 + fbm3((p + sunDir.xz * 120.0) * 0.00055 * 3.1 + 5.0) * 0.35;
        float selfShadow = clamp((n - ns) * 2.5 + 0.6, 0.25, 1.0);
        vec3 cloudCol = mix(skyHorizon * 0.7 + vec3(0.12), sunColor * 0.55 + skyZenith * 0.2, selfShadow);
        cloudCol += sunColor * pow(max(sd, 0.0), 12.0) * 0.6 * (1.0 - cov * 0.5);
        float fade = smoothstep(0.0, 0.18, d.y);
        c = mix(c, cloudCol, cov * fade * 0.92);
    }
    // sun disk (HDR, drives bloom + shafts)
    c += sunColor * smoothstep(0.99955, 0.99975, sd) * 30.0;
    finalColor = vec4(c, 1.0);
}
)";

// ---------------------------------------------------------------- post processing
static const char* FS_POST_HEADER = R"(#version 330
in vec2 fragTexCoord;
in vec4 fragColor;
uniform sampler2D texture0;
out vec4 finalColor;
)";

static const char* FS_BRIGHT = R"(
uniform vec2 texel;
uniform float threshold;
void main() {
    vec3 c = texture(texture0, fragTexCoord + texel * vec2(-0.5, -0.5)).rgb
           + texture(texture0, fragTexCoord + texel * vec2(0.5, -0.5)).rgb
           + texture(texture0, fragTexCoord + texel * vec2(-0.5, 0.5)).rgb
           + texture(texture0, fragTexCoord + texel * vec2(0.5, 0.5)).rgb;
    c *= 0.25;
    c = min(c, vec3(60.0));
    float l = max(c.r, max(c.g, c.b));
    float knee = threshold * 0.5;
    float soft = clamp(l - threshold + knee, 0.0, 2.0 * knee);
    soft = soft * soft / (4.0 * knee + 1e-4);
    float contrib = max(soft, l - threshold) / max(l, 1e-4);
    finalColor = vec4(c * contrib, 1.0);
}
)";

static const char* FS_BLUR = R"(
uniform vec2 dir;   // texel-scaled direction
void main() {
    vec3 c = texture(texture0, fragTexCoord).rgb * 0.2270270270;
    c += texture(texture0, fragTexCoord + dir * 1.3846153846).rgb * 0.3162162162;
    c += texture(texture0, fragTexCoord - dir * 1.3846153846).rgb * 0.3162162162;
    c += texture(texture0, fragTexCoord + dir * 3.2307692308).rgb * 0.0702702703;
    c += texture(texture0, fragTexCoord - dir * 3.2307692308).rgb * 0.0702702703;
    finalColor = vec4(c, 1.0);
}
)";

static const char* FS_COMPOSITE = R"(
uniform sampler2D bloomA;
uniform sampler2D bloomB;
uniform vec2 sunUV;
uniform float sunVisible;
uniform float exposure;
uniform float bloomStrength;
uniform float shaftStrength;
uniform float saturation;
vec3 aces(vec3 x) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}
void main() {
    vec2 uv = fragTexCoord;
    vec3 c = texture(texture0, uv).rgb;
    vec3 b = texture(bloomA, uv).rgb * 0.55 + texture(bloomB, uv).rgb * 0.45;
    c += b * bloomStrength;
    if (sunVisible > 0.001) {
        vec2 delta = (uv - sunUV) * (0.9 / 48.0);
        vec2 tc = uv;
        float illum = 1.0;
        vec3 acc = vec3(0.0);
        for (int i = 0; i < 48; i++) {
            tc -= delta;
            acc += texture(bloomA, tc).rgb * illum;
            illum *= 0.955;
        }
        c += acc / 48.0 * shaftStrength * sunVisible;
    }
    c *= exposure;
    c = aces(c);
    c = pow(c, vec3(1.0 / 2.2));
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, saturation);
    c = (c - 0.5) * 1.04 + 0.5;
    vec2 vv = uv - 0.5;
    c *= mix(1.0, smoothstep(0.85, 0.25, length(vv * vec2(1.1, 1.0))), 0.35);
    c += (hash(uv * 1000.0) - 0.5) / 255.0;  // dither against banding
    finalColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
)";

static const char* FS_HASH = R"(
float hash(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
)";

static const char* FS_FXAA = R"(
uniform vec2 texel;
void main() {
    vec2 uv = fragTexCoord;
    const vec3 L = vec3(0.299, 0.587, 0.114);
    vec3 rgbNW = texture(texture0, uv + vec2(-1.0, -1.0) * texel).rgb;
    vec3 rgbNE = texture(texture0, uv + vec2(1.0, -1.0) * texel).rgb;
    vec3 rgbSW = texture(texture0, uv + vec2(-1.0, 1.0) * texel).rgb;
    vec3 rgbSE = texture(texture0, uv + vec2(1.0, 1.0) * texel).rgb;
    vec3 rgbM = texture(texture0, uv).rgb;
    float lNW = dot(rgbNW, L), lNE = dot(rgbNE, L), lSW = dot(rgbSW, L), lSE = dot(rgbSE, L), lM = dot(rgbM, L);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
    float reduce = max((lNW + lNE + lSW + lSE) * (0.25 / 8.0), 1.0 / 128.0);
    float rcpMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + reduce);
    dir = clamp(dir * rcpMin, vec2(-8.0), vec2(8.0)) * texel;
    vec3 a = 0.5 * (texture(texture0, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture(texture0, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(texture0, uv + dir * -0.5).rgb + texture(texture0, uv + dir * 0.5).rgb);
    float lB = dot(b, L);
    finalColor = vec4((lB < lMin || lB > lMax) ? a : b, 1.0);
}
)";

}  // namespace shaders
