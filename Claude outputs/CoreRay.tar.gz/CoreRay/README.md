# CoreRay

A native **C++ / raylib** indoor-cycling app for the **Wahoo KICKR CORE** (and any Bluetooth **FTMS** smart trainer) plus a heart-rate strap or watch.

CoreRay is a sibling of CoreKick, rebuilt as one native binary. The ride engine is a faithful C++ port of CoreKick's Rust core: physics, workouts, FTP tests, the simulator, the FIT encoder and the FTMS control behaviour. It runs the same unit tests. On top of that, CoreRay has its own HDR 3D renderer and a CoreKick-style 2D dashboard.

---

## Build & run (macOS)

Prerequisites: Xcode Command Line Tools (`xcode-select --install`) and CMake (`brew install cmake`).

```bash
cd ~/CoreRay
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/CoreRay
```

The first configure downloads raylib 5.5 and SimpleBLE 1.4.0 (about a minute). After that, rebuilds are incremental.

**Bluetooth permission.** macOS asks the first time CoreRay scans. CoreRay is a plain executable with an embedded `Info.plist`, so the request is made for the app you launched it from (Terminal, iTerm, VS Code). If scanning finds nothing, allow that app under *System Settings → Privacy & Security → Bluetooth*.

**No bike handy?** Go to *Devices* and turn on **Use the simulator**, or run `./build/CoreRay --sim`.

Tests:

```bash
ctest --test-dir build --output-on-failure    # 900+ checks ported from CoreKick's Rust tests + FTMS parsing
```

## What's in it

### Ride modes (Home → Ride)

- **Route.** Ride the course for 1–20 laps. The trainer gets the real gradient, scaled by your difficulty setting, with lookahead and smoothing. Ride against a **ghost** of your personal best on that course and lap count.
- **Workout.** Any of the **31 built-in sessions** ported from CoreKick, or your own. Ride them in ERG or in resistance mode.
- **Test.** Ramp (auto-detects failure, FTP = 75 % of your best minute), 20-minute (95 %), or 2 × 8-minute (90 %). The summary offers to apply the new FTP.
- **Free ride.** Choose gradient (SIM), fixed power (ERG), resistance level, or **heart-rate-controlled** ERG. Optionally set a goal: time, distance, kJ, kcal or climbing.

### Workouts

The library can be filtered by category and sorted by duration or TSS. Each workout shows TSS, IF, NP, work and time in zone at your FTP.

- **Editor.** Uses CoreKick's text format with a live preview:
  ```
  10m 50-75%                   ramp
  20m @90% 85rpm               steady with a cadence target
  5x 1m @120% / 1m @50%        intervals
  3x (30s @150%, 30s @50%)     repeat set (nestable)
  2m free · 30s effort @2%     rider-controlled
  1:30 @250w · 1h @65%         mm:ss, hours, absolute watts
  ```
- **Import.** Drag `.zwo`, `.erg`, `.mrc` or `.txt` files onto the window.
- **Export.** Save any workout as `.zwo`.
- **Your own workouts** live in `~/.coreray/workouts/*.txt` (plain text, easy to edit).

### Riding

- 3-second power with zone and W/kg, heart rate with live zone, cadence, speed, mode chip (SIM % / ERG W / level / HR→W / gear).
- Workout step panel: target, time left, next step, cadence target, a compliance bar and 3-2-1 beeps.
- Current or next climb (category, distance to the top, metres left to climb), goal progress, ghost gap, laps.
- Next 2 km profile with gradients, the full route profile, and a rolling 5-minute power / HR / cadence chart.
- **V** switches between the 3D world and a full **2D dashboard** in CoreKick's style.
- **E** opens the edit drawer:
  - **Intervals:** lengthen or shorten the step, nudge its target or the overall intensity, add one more rep, skip, skip to cool-down, switch ERG / resistance, end the workout.
  - **Ride:** free-ride mode, goal, difficulty, laps, gears.
  - **Insert:** add interval sets to any ride in the text format.
- **Heart-rate alerts:** a tone when you leave your zone range, with a warm-up grace period.
- **Virtual shifting** for single-speed setups (KICKR CORE + Zwift Cog): 24 gears, using CoreKick's cadence × gear → speed → ERG-watts model.

| Key | Action |
| --- | --- |
| `Space` | Pause / resume |
| `L` | Lap |
| `E` | Edit drawer |
| `↑` / `↓` | Nudge target (intensity, watts, gradient, level, HR or difficulty) |
| `→` | Skip to the next workout step |
| `[` `]` / PgUp PgDn | Virtual gears |
| `H` | Heart-rate alerts on / off |
| `V` | 2D dashboard / 3D world |
| `C` | Camera: chase, close, side, drone, rider, cinematic |
| `T` | Time of day: morning, midday, golden hour, overcast |
| `D` | Simulator test-data panel |
| `Shift+↑/↓`, `Alt+↑/↓` | Simulator power ±10 W, heart rate ±2 bpm |
| `Tab` | Hide the HUD |
| `?` | Help |
| `Esc` | Menu (resume, 2D/3D, end & save, discard) |

### After the ride

The summary shows time, distance, climbing, average / NP / max power, IF, VI, TSS, kJ, kcal (from work, and from heart rate), heart rate, cadence and W/kg. It also shows time in power zones and heart-rate zones, power bests (1 s → 90 min), laps and route-lap splits, and power / HR / cadence / elevation / speed charts.

Rides are saved to `~/CoreRay Rides/` as:
- **`.fit`**: a Virtual Ride, encoder ported from CoreKick's (validated against Garmin's SDK there). Upload it to Strava, Garmin Connect, TrainingPeaks or intervals.icu.
- **`.tcx`** and **`.csv`**.

### Devices

Scan, then pick **Use as trainer** / **Use as HRM**. Both auto-reconnect on the next launch. The Bluetooth layer follows CoreKick's `ble.rs`:
- A supervisor thread per device.
- FTMS *Request Control → Start* handshake.
- **Serialised control-point writes**: one outstanding request, 2 s timeout.
- Coalescing, so only the newest SIM/ERG target is sent.
- Re-request on *control not permitted* or *control permission lost*.
- Reconnect with back-off, re-sending the current target.
- Heart rate falls back to the trainer's own HR field if no strap is connected.

The **simulator** is CoreKick's test mode:
- A simulated rider shaped by ERG / grade / level, or fixed watts.
- Patterns: steady, surges, wave, fade.
- Heart rate: modelled, fixed or off; cadence auto or fixed.
- A noise level, and a trainer-dropout switch.

### Profile

- FTP, weight, bike weight, age, sex.
- HR max / rest, and zone model (% max, reserve, or Friel's 7 LTHR zones).
- HR alerts.
- CdA from riding position, Crr from road surface, trainer difficulty and gradient clamps, gross efficiency.
- Virtual shifting, and graphics quality.
- A live "250 W = x km/h flat / y km/h up 6 %" readout.
- **Import from CoreKick** reads your profile and custom workouts straight from `~/Library/Application Support/com.corekick.app/corekick.db` (read-only).

## The 3D engine

- **HDR pipeline.** Scene rendered to an RGBA16F target → soft-knee bright pass → two-scale Gaussian bloom → screen-space **sun shafts** → ACES tone mapping → FXAA.
- **Cascaded shadow maps.** Two cascades, up to 4096², texel-snapped so they don't shimmer, with 12-tap rotated Poisson PCF and normal-offset bias.
- **Procedural sky.** Rayleigh-ish gradient, sun glow and HDR sun disk, drifting self-shadowed clouds.
- **Atmosphere.** Height-attenuated aerial-perspective fog tinted towards the sun.
- **Terrain.** Carved around the road with gravel shoulders. Shading blends grass, dry meadow, rock on slopes, snow on high ground and sand at the waterline, with procedural detail normals.
- **Water.** Animated normals, Fresnel sky reflections and sun glints.
- **Vegetation.** Instanced trees (conifers + lumpy broadleaf) and rocks, about 50–140 k depending on quality. Wind sway and leaf translucency.
- **The rider is animated from your real data.**
  - Cranks turn at your cadence, with two-bone IK legs and arms.
  - Out of the saddle on steep or hard efforts, with bike rock.
  - Tucks on fast descents and drops into the drops on hard flat efforts.
  - Pedals level when freewheeling, and leans into bends.
- **Ghost rider** for your personal best.
- **Cameras:** chase, close, side, drone, rider-eye, cinematic.
- **Courses:** procedural 10 km loops with real categorised climbs (Cat 4 / Cat 3), rollers, lakes and snowy peaks. *New course* reseeds.

## Project layout

```
src/core/       pure C++ (no UI/BLE) – ported from CoreKick's corekick-core, unit-tested
  Physics       forces, air density, steady-state solver, momentum, virtual gears
  Metrics       NP / IF / TSS, bests, zones, calories (work + Keytel HR)
  Workout       blocks → steps, text format, ZWO/ERG/MRC, 31 built-ins, FTP tests
  Sim           virtual trainer + rider, test mode
  Engine        ride engine: SIM/ERG/level/HR control, workouts, tests, goals, laps, climbs, ghost
  Export        FIT / TCX / CSV
src/Protocol    FTMS / HRS byte protocol
src/Ble         SimpleBLE supervisor (trainer + HRM)
src/Course      procedural loop course + terrain height field
src/Renderer    HDR renderer, Shaders.h holds the GLSL
src/App, HomeUi, RideUi, SummaryUi, Ui   app + UI
src/Store       ~/.coreray persistence, ghosts, CoreKick import
tests/          core_tests (ported from CoreKick), protocol_tests
```

## Not ported yet (CoreKick has these)

- Ride history, stats and fitness / fatigue / form (CTL/ATL/TSB).
- Automatic FTP (eFTP).
- Recurring events.
- Strava upload (export the `.fit` and upload by hand for now).
- GPX import and the route builder / generator UI.
- In-ride road editing (splicing sectors).
- Weather, dusk lanterns and the moon, and wildlife in 3D.

## Licences

- raylib: zlib.
- SimpleBLE 1.4: Business Source License 1.1. Free for personal / non-commercial use; check its terms before any commercial use.
- Barlow font: SIL OFL.
